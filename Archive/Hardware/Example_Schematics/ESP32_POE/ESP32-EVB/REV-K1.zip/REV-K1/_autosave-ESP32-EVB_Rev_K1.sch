(kicad_sch
	(version 20231120)
	(generator "eeschema")
	(generator_version "8.0")
	(uuid "25974a83-530b-41f8-bec2-856ac522261d")
	(paper "A2")
	(title_block
		(title "ESP32-EVB")
		(date "2023-04-14")
		(rev "K1")
		(company "OLIMEX LTD.")
		(comment 1 "https://www.olimex.com")
	)
	(lib_symbols
		(symbol "ESP32-EVB_Rev_K1:+3.3V"
			(power)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "+3.3V"
				(at 0 3.556 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "+3.3V_0_1"
				(polyline
					(pts
						(xy -0.762 1.27) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0.762 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "+3.3V_1_1"
				(pin power_in line
					(at 0 0 90)
					(length 0) hide
					(name "+3.3V"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:+3.3VLAN"
			(power)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "+3.3VLAN"
				(at 0 3.556 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "+3.3VLAN_0_1"
				(polyline
					(pts
						(xy -0.762 1.27) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0.762 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "+3.3VLAN_1_1"
				(pin power_in line
					(at 0 0 90)
					(length 0) hide
					(name "+3.3VLAN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:+5V"
			(power)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "+5V"
				(at 0 3.556 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "+5V_0_1"
				(polyline
					(pts
						(xy -0.762 1.27) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy 0.762 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "+5V_1_1"
				(pin power_in line
					(at 0 0 90)
					(length 0) hide
					(name "+5V"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BAT54A(SOT23-3)"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "D"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "BAT54A(SOT23-3)"
				(at 0 3.81 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BAT54A(SOT23-3)_0_1"
				(polyline
					(pts
						(xy -2.54 0) (xy 2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 -0.635) (xy -2.159 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 0.635) (xy -1.905 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.651 0.635) (xy -1.905 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -1.905) (xy 0 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 -1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 -0.635) (xy 1.651 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 0.635) (xy 1.905 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.159 0.635) (xy 1.905 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.635 0.635) (xy -0.635 -0.635) (xy -1.905 0) (xy -0.635 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 0.635 0.635) (xy 0.635 -0.635) (xy 1.905 0) (xy 0.635 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -2.54 2.54) (xy 2.54 2.54) (xy 2.54 -2.54) (xy -2.54 -2.54) (xy -2.54 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(circle
					(center 0 0)
					(radius 0.127)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "BAT54A(SOT23-3)_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 2.54)
					(name "C1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.54)
					(name "C2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -5.08 90)
					(length 2.54)
					(name "CA"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BAT54C(SOT23-3)"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "D"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "BAT54C(SOT23-3)"
				(at 0 3.81 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BAT54C(SOT23-3)_0_1"
				(polyline
					(pts
						(xy -2.54 0) (xy 2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.889 0.635) (xy -0.635 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.635 -0.635) (xy -0.381 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.635 0.635) (xy -0.635 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -1.905) (xy 0 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy 0 -1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.381 0.635) (xy 0.635 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 -0.635) (xy 0.889 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 0.635) (xy 0.635 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 0.635) (xy -1.905 -0.635) (xy -0.635 0) (xy -1.905 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.905 0.635) (xy 1.905 -0.635) (xy 0.635 0) (xy 1.905 0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -2.54 2.54) (xy 2.54 2.54) (xy 2.54 -2.54) (xy -2.54 -2.54) (xy -2.54 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(circle
					(center 0 0)
					(radius 0.127)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "BAT54C(SOT23-3)_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 2.54)
					(name "A1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.54)
					(name "A2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -5.08 90)
					(length 2.54)
					(name "CC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BAT_CON"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "BAT_CON"
				(at 0.635 5.08 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "BAT_CON"
				(at 0 -5.334 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BAT_CON_0_0"
				(rectangle
					(start -2.0066 4.064)
					(end 1.9812 -4.0132)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.905 3.9116)
					(end 1.8796 -3.8608)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.1684 -0.9652)
					(end 0.762 -1.524)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.1684 1.5748)
					(end 0.762 1.016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -1.0414 1.3716)
					(end 0.635 1.1684)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.9398 -1.143)
					(end 0.7366 -1.3462)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 -1.27) (xy -1.143 -1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 1.27) (xy -1.143 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.6858 1.2446)
					(end -0.9652 1.3462)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.7112 -1.3208)
					(end -0.9398 -1.2192)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.7112 1.1176)
					(end -1.0668 1.4732)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.7366 -1.4224)
					(end -1.0414 -1.0668)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "+"
					(at 0 2.794 0)
					(effects
						(font
							(size 1.524 1.524)
						)
					)
				)
				(text "-"
					(at 0 -2.286 0)
					(effects
						(font
							(size 1.524 1.524)
						)
					)
				)
			)
			(symbol "BAT_CON_1_1"
				(pin passive line
					(at -5.08 1.27 0)
					(length 2.9972)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 -1.27 0)
					(length 2.9972)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BD5230G-TR(SSOP5_SOT-23-5)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "BD5230G-TR(SSOP5_SOT-23-5)"
				(at 0 -6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BD5230G-TR(SSOP5_SOT-23-5)_0_1"
				(rectangle
					(start -5.08 3.81)
					(end 5.08 -3.81)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "BD5230G-TR(SSOP5_SOT-23-5)_1_1"
				(pin open_collector line
					(at -7.62 2.54 0)
					(length 2.54)
					(name "#RST"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at 7.62 2.54 180)
					(length 2.54)
					(name "VDD"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at 7.62 -2.54 180)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -2.54 0)
					(length 2.54)
					(name "CT"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BH10S"
			(pin_names
				(offset 1.016) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "CON"
				(at 0.0508 8.9154 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "BH10S"
				(at 0.3048 -9.4234 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at -0.2032 -1.1938 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -0.2032 -1.1938 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BH10S_0_0"
				(rectangle
					(start -3.1242 -4.8514)
					(end -0.5588 -5.3086)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -3.1242 -2.3368)
					(end -0.5588 -2.794)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -3.0988 0.254)
					(end -0.5334 -0.2032)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -3.0734 2.7686)
					(end -0.508 2.3114)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -3.048 5.334)
					(end -0.4826 4.8768)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.0226 -5.0038) (xy -0.5842 -5.0038) (xy -0.5842 -5.2324) (xy -2.9972 -5.2578) (xy -3.0226 -5.08)
						(xy -0.7112 -5.08) (xy -0.7112 -5.1562) (xy -2.9972 -5.1054)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.0226 0.1016) (xy -0.5842 0.1016) (xy -0.5842 -0.127) (xy -2.9972 -0.1524) (xy -3.0226 0.0254)
						(xy -0.7112 0.0254) (xy -0.7112 -0.0508) (xy -2.9972 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.9972 -2.4638) (xy -0.5588 -2.4638) (xy -0.5588 -2.6924) (xy -2.9718 -2.7178) (xy -2.9972 -2.54)
						(xy -0.6858 -2.54) (xy -0.6858 -2.6162) (xy -2.9718 -2.5654)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.9718 2.667) (xy -0.5334 2.667) (xy -0.5334 2.4384) (xy -2.9464 2.413) (xy -2.9718 2.5908)
						(xy -0.6604 2.5908) (xy -0.6604 2.5146) (xy -2.9464 2.5654)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.9464 5.2324) (xy -0.508 5.2324) (xy -0.508 5.0038) (xy -2.921 4.9784) (xy -2.9464 5.1562)
						(xy -0.635 5.1562) (xy -0.635 5.08) (xy -2.921 5.1308)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.5588 0.1016) (xy 2.9972 0.1016) (xy 2.9972 -0.127) (xy 0.5842 -0.1524) (xy 0.5588 0.0254)
						(xy 2.8702 0.0254) (xy 2.8702 -0.0508) (xy 0.5842 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.5842 -2.4384) (xy 3.0226 -2.4384) (xy 3.0226 -2.667) (xy 0.6096 -2.6924) (xy 0.5842 -2.5146)
						(xy 2.8956 -2.5146) (xy 2.8956 -2.5908) (xy 0.6096 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.5842 2.667) (xy 3.0226 2.667) (xy 3.0226 2.4384) (xy 0.6096 2.413) (xy 0.5842 2.5908) (xy 2.8956 2.5908)
						(xy 2.8956 2.5146) (xy 0.6096 2.5654)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 -4.953) (xy 3.0734 -4.953) (xy 3.0734 -5.1816) (xy 0.6604 -5.207) (xy 0.635 -5.0292)
						(xy 2.9464 -5.0292) (xy 2.9464 -5.1054) (xy 0.6604 -5.0546)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.6858 5.2324) (xy 3.1242 5.2324) (xy 3.1242 5.0038) (xy 0.7112 4.9784) (xy 0.6858 5.1562)
						(xy 2.9972 5.1562) (xy 2.9972 5.08) (xy 0.7112 5.1308)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.508 -2.3114)
					(end 3.0734 -2.7686)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.508 0.2286)
					(end 3.0734 -0.2286)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.5334 2.7686)
					(end 3.0988 2.3114)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.5588 -4.8514)
					(end 3.1242 -5.3086)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.5588 5.334)
					(end 3.1242 4.8768)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "BH10S_0_1"
				(rectangle
					(start -3.81 7.62)
					(end 3.81 -7.62)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -5.08) (xy -3.048 -5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -2.54) (xy -3.048 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 0) (xy -3.048 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 2.54) (xy -3.048 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 5.08) (xy -3.048 5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.81 -5.08) (xy 3.048 -5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.81 -2.54) (xy 3.048 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.81 0) (xy 3.048 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.81 2.54) (xy 3.048 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.81 5.08) (xy 3.048 5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "BH10S_1_1"
				(pin passive line
					(at -7.62 5.08 0)
					(length 3.7084)
					(name "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -5.08 180)
					(length 3.7084)
					(name "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 5.08 180)
					(length 3.7084)
					(name "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 2.54 0)
					(length 3.7084)
					(name "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 2.54 180)
					(length 3.7084)
					(name "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 0 0)
					(length 3.7084)
					(name "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 0 180)
					(length 3.7084)
					(name "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -2.54 0)
					(length 3.7084)
					(name "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 7.62 -2.54 180)
					(length 3.7084)
					(name "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -5.08 0)
					(length 3.7084)
					(name "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BH40S"
			(pin_numbers hide)
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "GPIO"
				(at -4.445 27.305 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "BH40S"
				(at -4.445 -26.035 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at -0.762 -1.27 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 2.54 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_locked" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "ki_fp_filters" "*YA-V36P-2X20-LF*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "BH40S_1_0"
				(rectangle
					(start 2.54 -24.13)
					(end -5.08 26.67)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "BH40S_1_1"
				(pin passive line
					(at -7.62 25.4 0)
					(length 2.4892)
					(name "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 15.24 180)
					(length 2.4892)
					(name "10"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 12.7 0)
					(length 2.4892)
					(name "11"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "11"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 12.7 180)
					(length 2.4892)
					(name "12"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "12"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 10.16 0)
					(length 2.4892)
					(name "13"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "13"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 10.16 180)
					(length 2.4892)
					(name "14"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "14"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 7.62 0)
					(length 2.4892)
					(name "15"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "15"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 7.62 180)
					(length 2.4892)
					(name "16"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "16"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 5.08 0)
					(length 2.4892)
					(name "17"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "17"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 5.08 180)
					(length 2.4892)
					(name "18"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "18"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 2.54 0)
					(length 2.4892)
					(name "19"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "19"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 25.4 180)
					(length 2.4892)
					(name "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 2.54 180)
					(length 2.4892)
					(name "20"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "20"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 0 0)
					(length 2.4892)
					(name "21"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "21"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.4892)
					(name "22"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "22"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -2.54 0)
					(length 2.4892)
					(name "23"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "23"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -2.54 180)
					(length 2.4892)
					(name "24"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "24"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -5.08 0)
					(length 2.4892)
					(name "25"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "25"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -5.08 180)
					(length 2.4892)
					(name "26"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "26"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -7.62 0)
					(length 2.4892)
					(name "27"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "27"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -7.62 180)
					(length 2.4892)
					(name "28"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "28"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -10.16 0)
					(length 2.4892)
					(name "29"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "29"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 22.86 0)
					(length 2.4892)
					(name "3"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -10.16 180)
					(length 2.4892)
					(name "30"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "30"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -12.7 0)
					(length 2.4892)
					(name "31"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "31"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -12.7 180)
					(length 2.4892)
					(name "32"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "32"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -15.24 0)
					(length 2.4892)
					(name "33"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "33"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -15.24 180)
					(length 2.4892)
					(name "34"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "34"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -17.78 0)
					(length 2.4892)
					(name "35"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "35"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -17.78 180)
					(length 2.4892)
					(name "36"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "36"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -20.32 0)
					(length 2.4892)
					(name "37"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "37"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -20.32 180)
					(length 2.4892)
					(name "38"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "38"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 -22.86 0)
					(length 2.4892)
					(name "39"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "39"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 22.86 180)
					(length 2.4892)
					(name "4"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -22.86 180)
					(length 2.4892)
					(name "40"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "40"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 20.32 0)
					(length 2.4892)
					(name "5"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 20.32 180)
					(length 2.4892)
					(name "6"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 17.78 0)
					(length 2.4892)
					(name "7"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 17.78 180)
					(length 2.4892)
					(name "8"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -7.62 15.24 0)
					(length 2.4892)
					(name "9"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:BL4054B-42TPRN(SOT23-5)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 8.89 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "BL4054B-42TPRN(SOT23-5)"
				(at 0 -8.89 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" "OLIMEX_IC-FP:SOT-23-5"
				(at 0 -12.7 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0.635 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Note" "PB-Free"
				(at 0 -17.78 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(symbol "BL4054B-42TPRN(SOT23-5)_0_0"
				(text "Charge Current Up to 800mA"
					(at 4.953 0 900)
					(effects
						(font
							(size 0.3048 0.3048)
							(italic yes)
						)
					)
				)
				(text "R(PROG)=2 to 10kΩ"
					(at 0 -3.683 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(italic yes)
						)
					)
				)
				(text "VBAT final float voltage to 4.2V"
					(at 0 3.937 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(italic yes)
						)
					)
				)
				(text "VCC=4.5V to 6.5V(at least a 1 μF)"
					(at -4.953 0 900)
					(effects
						(font
							(size 0.3048 0.3048)
							(italic yes)
						)
					)
				)
			)
			(symbol "BL4054B-42TPRN(SOT23-5)_1_0"
				(rectangle
					(start -1.2192 1.7018)
					(end -1.6002 2.6416)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.5334 1.7018)
					(end -0.9144 2.6416)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.3368 1.6764) (xy -1.8796 1.6764)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.3368 1.7018) (xy -1.8796 1.7018)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.1336 2.5146) (xy -2.159 1.8288)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.1082 2.1336) (xy -2.1336 1.7272)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.0828 1.7272) (xy -2.0828 2.4638)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.0574 2.4892) (xy -1.905 2.4892)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.9304 1.8034) (xy -2.0066 1.8034)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.8796 1.7272) (xy -1.8796 1.8034)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.8796 2.6162) (xy -1.8796 2.5146)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.8636 2.5654) (xy -0.6858 1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.635 2.5654) (xy -0.635 1.8034)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0762 2.286) (xy 0.0254 1.8288)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0508 1.8288) (xy -0.0762 1.778)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0508 2.2098) (xy -0.0254 2.5908)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 1.8288) (xy -0.1016 1.9812)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.0762 1.8034) (xy 0.1016 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.5842 2.5146) (xy 0.5842 1.7018)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.4986 2.4638) (xy 1.4732 2.5654)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.7018 2.1336) (xy 1.7018 2.2098)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.032 1.778) (xy 1.8542 1.778)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.0574 2.5146) (xy 2.0574 1.8034)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.1082 2.5146) (xy 1.8542 2.5146)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.6858 1.8034) (xy -0.8128 1.8288) (xy -0.762 2.5146)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.4224 2.5146) (xy 1.397 2.5654) (xy 1.4732 2.5654)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.7874 2.5654) (xy 0.762 1.8288) (xy 0.635 1.8542) (xy 0.6604 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.3208 2.54) (xy 1.3208 1.8288) (xy 1.4732 1.8542) (xy 1.4478 2.4638)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.651 2.3114) (xy -1.8288 2.3114) (xy -1.8288 2.032) (xy -1.6764 2.032) (xy -1.7272 2.2352)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 1.778) (xy -1.3716 2.5654) (xy -1.4224 1.778) (xy -1.4478 2.5908) (xy -1.524 1.8288)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.6764 2.3114) (xy 1.8542 2.3114) (xy 1.8542 2.0066) (xy 1.651 2.0066) (xy 1.7526 2.1844)
						(xy 1.7526 2.159)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.8542 2.6416) (xy 2.2352 2.6416) (xy 2.2352 1.7272) (xy 1.8542 1.7272) (xy 2.1336 1.7272)
						(xy 2.1336 2.5908)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 2.6162) (xy -2.3368 2.6162) (xy -2.3368 1.7272) (xy -2.3368 1.6764) (xy -2.032 1.6764)
						(xy -2.032 1.778) (xy -2.2352 1.778) (xy -2.2606 2.54) (xy -1.9304 2.54) (xy -1.9304 2.5146) (xy -1.9304 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.2032 1.7018)
					(end -0.1778 2.6416)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.889 1.7018)
					(end 0.508 2.6416)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 1.6002 1.7018)
					(end 1.2192 2.6416)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "BATTERY"
					(at 0.0508 -1.397 0)
					(effects
						(font
							(size 0.762 0.762)
						)
					)
				)
				(text "CHARGER"
					(at 0.1016 -2.5654 0)
					(effects
						(font
							(size 0.762 0.762)
						)
					)
				)
			)
			(symbol "BL4054B-42TPRN(SOT23-5)_1_1"
				(polyline
					(pts
						(xy -5.715 6.35) (xy -5.715 -6.35) (xy 5.715 -6.35) (xy 5.715 6.35) (xy -5.715 6.35)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(pin open_collector line
					(at 10.16 0 180)
					(length 4.4958)
					(name "CHRGb"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -10.16 -5.08 0)
					(length 4.4958)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 10.16 5.08 180)
					(length 4.4958)
					(name "VBAT"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -10.16 5.08 0)
					(length 4.4958)
					(name "VCC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 10.16 -5.08 180)
					(length 4.4958)
					(name "PROG"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:C"
			(pin_numbers hide)
			(pin_names
				(offset 0.254) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "C"
				(at 0.254 1.778 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "C"
				(at 0.254 -2.032 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "C? C_????_* C_???? SMD*_c Capacitor*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "C_0_1"
				(polyline
					(pts
						(xy -1.524 -0.508) (xy 1.524 -0.508)
					)
					(stroke
						(width 0.3302)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.524 0.508) (xy 1.524 0.508)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "C_1_1"
				(pin passive line
					(at 0 2.54 270)
					(length 1.905)
					(name "~"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 0 -2.54 90)
					(length 2.032)
					(name "~"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:CH340T(SSOP20W)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 16.51 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "CH340T(SSOP20W)"
				(at 0 -16.51 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" "OLIMEX_IC-FP:SSOP-20W"
				(at 0 -20.32 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Note" "PB-Free"
				(at 0 -22.86 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "ki_fp_filters" "SSOP-20W"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "CH340T(SSOP20W)_0_1"
				(rectangle
					(start -7.62 15.24)
					(end 7.62 -15.24)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "CH340T(SSOP20W)_1_1"
				(pin output line
					(at -12.7 -12.7 0)
					(length 5.08)
					(name "XO"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 2.54 180)
					(length 5.08)
					(name "CTS#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 -2.54 180)
					(length 5.08)
					(name "DSR#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 -7.62 180)
					(length 5.08)
					(name "RI#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 -5.08 180)
					(length 5.08)
					(name "DCD#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 12.7 0 180)
					(length 5.08)
					(name "DTR#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 12.7 5.08 180)
					(length 5.08)
					(name "RTS#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 -12.7 180)
					(length 5.08)
					(name "IR#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -12.7 12.7 0)
					(length 5.08)
					(name "VCC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 -10.16 180)
					(length 5.08)
					(name "NOS#"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 12.7 12.7 180)
					(length 5.08)
					(name "TXD"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 12.7 10.16 180)
					(length 5.08)
					(name "RXD"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -12.7 10.16 0)
					(length 5.08)
					(name "V3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at -12.7 -2.54 0)
					(length 5.08)
					(name "UD+"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at -12.7 0 0)
					(length 5.08)
					(name "UD-"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -12.7 5.08 0)
					(length 5.08)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -12.7 -7.62 0)
					(length 5.08)
					(name "XI"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:CON2"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "CON"
				(at -1.27 4.445 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "CON2"
				(at -1.27 -6.985 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at -1.905 -1.27 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -1.905 -1.27 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "CON2_0_0"
				(rectangle
					(start -2.6416 -2.6924)
					(end -0.8636 -2.3368)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.6162 -2.5908)
					(end -0.9652 -2.4892)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.6162 -0.1524)
					(end -0.8382 0.2032)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.5908 -0.0254)
					(end -0.9398 0.0762)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.9652 -2.413)
					(end -2.6416 -2.6162)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.8636 0.1016)
					(end -2.54 -0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.7366 -2.2352)
					(end -2.667 -2.794)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.7366 0.3048)
					(end -2.667 -0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -2.54) (xy -0.762 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy -0.762 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0 2.6416)
					(end -3.7846 -5.1308)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 0.1016 2.794)
					(end -3.8862 -5.2832)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "CON2_1_1"
				(pin passive line
					(at 2.54 0 180)
					(length 2.54)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 -2.54 180)
					(length 2.54)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:CON3"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "CON"
				(at -1.27 5.08 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "CON3"
				(at -1.27 -5.08 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at -1.905 1.27 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -1.905 1.27 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "CON3_0_0"
				(rectangle
					(start -2.6416 -2.6924)
					(end -0.8636 -2.3368)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.6416 -0.1524)
					(end -0.8636 0.2032)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.6162 -2.5908)
					(end -0.9652 -2.4892)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.6162 -0.0508)
					(end -0.9652 0.0508)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.6162 2.3876)
					(end -0.8382 2.7432)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -2.5908 2.5146)
					(end -0.9398 2.6162)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.9652 -2.413)
					(end -2.6416 -2.6162)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.9652 0.127)
					(end -2.6416 -0.0762)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.8636 2.6416)
					(end -2.54 2.4384)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.7366 -2.2352)
					(end -2.667 -2.794)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.7366 0.3048)
					(end -2.667 -0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start -0.7366 2.8448)
					(end -2.667 2.286)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -2.54) (xy -0.762 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy -0.762 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 2.54) (xy -0.762 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "CON3_0_1"
				(rectangle
					(start -3.81 3.81)
					(end 0 -3.81)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "CON3_1_1"
				(pin passive line
					(at 2.54 2.54 180)
					(length 2.54)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 0 180)
					(length 2.54)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 -2.54 180)
					(length 2.54)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:Crystal"
			(pin_names
				(offset 1.016) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "Q"
				(at 0 3.175 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "Crystal"
				(at 0 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Crystal_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Crystal_0_1"
				(rectangle
					(start -0.508 1.143)
					(end 0.508 -1.143)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -1.27 -1.27) (xy -1.27 1.27)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.27) (xy 1.27 1.27)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "Crystal_1_1"
				(pin passive line
					(at -2.54 0 0)
					(length 1.27)
					(name "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 0 180)
					(length 1.27)
					(name "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:D_Schottky"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "D"
				(at 0 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "D_Schottky"
				(at 0 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "D-Pak_TO252AA Diode_* *SingleDiode *SingleDiode* *_Diode_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "D_Schottky_0_1"
				(polyline
					(pts
						(xy 1.27 -1.27) (xy -1.27 0) (xy 1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -0.635 1.27) (xy -1.27 1.27) (xy -1.27 -1.27) (xy -1.905 -1.27)
					)
					(stroke
						(width 0.2032)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 1.27 1.27)
					(end 1.27 -1.27)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "D_Schottky_1_1"
				(pin passive line
					(at -3.81 0 0)
					(length 2.54)
					(name "K"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 3.81 0 180)
					(length 2.54)
					(name "A"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:D_Schottky_Small"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "D"
				(at -1.27 3.175 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "D_Schottky_Small"
				(at -7.62 -3.175 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" ""
				(at 0 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Diode_* D-Pak_TO252AA *SingleDiode *SingleDiode* *_Diode_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "D_Schottky_Small_0_1"
				(polyline
					(pts
						(xy -0.762 -1.016) (xy -1.016 -1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.762 -1.016) (xy -0.762 1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.762 1.016) (xy -0.762 1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.762 1.016) (xy -0.508 1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 -1.016) (xy -0.762 0) (xy 0.762 1.016) (xy 0.762 -1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
			)
			(symbol "D_Schottky_Small_1_1"
				(pin passive line
					(at -2.54 0 0)
					(length 1.778)
					(name "K"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 0 180)
					(length 1.778)
					(name "A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:ESDS314DBVR(SOT-23-5)"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "TVS"
				(at -2.54 10.16 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Value" "ESDS314DBVR(SOT-23-5)"
				(at -12.7 -10.16 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left)
				)
			)
			(property "Footprint" "OLIMEX_Diodes-FP:SOT-23-5"
				(at 0 -12.7 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -2.54 5.08 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "Diode_* D-Pak_TO252AA *SingleDiode *SingleDiode* *_Diode_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "ESDS314DBVR(SOT-23-5)_0_1"
				(rectangle
					(start -5.08 7.62)
					(end 5.08 -7.62)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(circle
					(center 0 -5.08)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 0 -5.08)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -5.08 5.08) (xy 5.08 5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -6.096) (xy -3.81 -6.604)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -6.096) (xy -3.302 -4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -6.096) (xy -3.302 -4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -4.064) (xy -3.302 -4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -4.064) (xy -3.302 -4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -4.064) (xy -2.794 -3.556)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 -4.064) (xy -2.794 -3.556)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 4.064) (xy -3.81 3.556)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 4.064) (xy -3.302 6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 4.064) (xy -3.302 6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 6.096) (xy -3.302 6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 6.096) (xy -3.302 6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 6.096) (xy -2.794 6.604)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.302 6.096) (xy -2.794 6.604)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy -5.08 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 0) (xy -5.08 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 5.08) (xy 0 -5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -6.096) (xy 2.794 -6.604)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -6.096) (xy 2.794 -6.604)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -6.096) (xy 3.302 -6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -6.096) (xy 3.302 -6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -4.064) (xy 3.302 -6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -4.064) (xy 3.302 -6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -4.064) (xy 3.81 -3.556)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 4.064) (xy 2.794 3.556)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 4.064) (xy 2.794 3.556)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 4.064) (xy 3.302 4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 4.064) (xy 3.302 4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 6.096) (xy 3.302 4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 6.096) (xy 3.302 4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 6.096) (xy 3.81 6.604)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.08 -5.08) (xy -5.08 -5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.778 -6.096) (xy -3.302 -5.08) (xy -1.778 -4.064) (xy -1.778 -6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -1.778 -6.096) (xy -3.302 -5.08) (xy -1.778 -4.064) (xy -1.778 -6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -1.778 4.064) (xy -3.302 5.08) (xy -1.778 6.096) (xy -1.778 4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -1.778 4.064) (xy -3.302 5.08) (xy -1.778 6.096) (xy -1.778 4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.778 -4.064) (xy 3.302 -5.08) (xy 1.778 -6.096) (xy 1.778 -4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.778 -4.064) (xy 3.302 -5.08) (xy 1.778 -6.096) (xy 1.778 -4.064)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.778 6.096) (xy 3.302 5.08) (xy 1.778 4.064) (xy 1.778 6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.778 6.096) (xy 3.302 5.08) (xy 1.778 4.064) (xy 1.778 6.096)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 0 0)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 0 0)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 0 5.08)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 0 5.08)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
			)
			(symbol "ESDS314DBVR(SOT-23-5)_1_1"
				(pin passive line
					(at -10.16 5.08 0)
					(length 5.08)
					(name "I/O1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -10.16 5.08 0)
					(length 5.08)
					(name "I/O1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -10.16 0 0)
					(length 5.08)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -10.16 -5.08 0)
					(length 5.08)
					(name "I/O2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 10.16 -5.08 180)
					(length 5.08)
					(name "I/O3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 10.16 5.08 180)
					(length 5.08)
					(name "I/O4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:ESP-WROOM-32"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 43.18 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "ESP-WROOM-32"
				(at 0 -45.72 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at -22.86 5.08 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at -22.86 5.08 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "ESP-WROOM-32_0_0"
				(text "ESP-WROOM-32"
					(at -23.876 -12.446 0)
					(effects
						(font
							(size 2.4892 2.4892)
							(bold yes)
						)
					)
				)
				(text "MODULE"
					(at -23.876 -17.526 0)
					(effects
						(font
							(size 2.4892 2.4892)
							(bold yes)
						)
					)
				)
			)
			(symbol "ESP-WROOM-32_0_1"
				(rectangle
					(start -43.18 40.64)
					(end 45.72 -43.18)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "ESP-WROOM-32_1_1"
				(pin power_in line
					(at -45.72 35.56 0)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -20.32 180)
					(length 2.54)
					(name "GPIO25/DAC_1/ADC2_CH8/RTC_GPIO6/EMAC_RXD0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -22.86 180)
					(length 2.54)
					(name "GPIO26/DAC_2/ADC2_CH9/RTC_GPIO7/EMAC_RXD1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -25.4 180)
					(length 2.54)
					(name "GPIO27/ADC2_CH7/TOUCH7/RTC_GPIO17/EMAC_RX_DV"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 2.54 180)
					(length 2.54)
					(name "GPIO14/ADC2_CH6/TOUCH6/RTC_GPIO16/MTMS/HSPICLK/HS2_CLK/SD_CLK/EMAC_TXD2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 7.62 180)
					(length 2.54)
					(name "GPIO12/ADC2_CH5/TOUCH5/RTC_GPIO15/MTDI/HSPIQ/HS2_DATA2/SD_DATA2/EMAC_TXD3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -45.72 33.02 0)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 5.08 180)
					(length 2.54)
					(name "GPIO13/ADC2_CH4/TOUCH4/RTC_GPIO14/MTCK/HSPID/HS2_DATA3/SD_DATA3/EMAC_RX_ER"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 15.24 180)
					(length 2.54)
					(name "GPIO9/SD_DATA2/SPIHD/HS1_DATA2/U1RXD"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 12.7 180)
					(length 2.54)
					(name "GPIO10/SD_DATA3/SPIWP/HS1_DATA3/U1TXD"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 10.16 180)
					(length 2.54)
					(name "GPIO11/SD_CMD/SPICS0/HS1_CMD/U1RTS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -45.72 38.1 0)
					(length 2.54)
					(name "3V3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 22.86 180)
					(length 2.54)
					(name "GPIO6/SD_CLK/SPICLK/HS1_CLK/U1CTS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 20.32 180)
					(length 2.54)
					(name "GPIO7/SD_DATA0/SPIQ/HS1_DATA0/U2RTS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "21"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 17.78 180)
					(length 2.54)
					(name "GPIO8/SD_DATA1/SPID/HS1_DATA1/U2CTS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "22"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 0 180)
					(length 2.54)
					(name "GPIO15/ADC2_CH3/TOUCH3/MTDO/HSPICS0/RTC_GPIO13/HS2_CMD/SD_CMD/EMAC_RXD3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "23"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 33.02 180)
					(length 2.54)
					(name "GPIO2/ADC2_CH2/TOUCH2/RTC_GPIO12/HSPIWP/HS2_DATA0/SD_DATA0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "24"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 38.1 180)
					(length 2.54)
					(name "GPIO0/ADC2_CH1/TOUCH1/RTC_GPIO11/CLK_OUT1/EMAC_TX_CLK"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "25"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 27.94 180)
					(length 2.54)
					(name "GPIO4/ADC2_CH0/TOUCH0/RTC_GPIO10/HSPIHD/HS2_DATA1/SD_DATA1/EMAC_TX_ER"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "26"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -2.54 180)
					(length 2.54)
					(name "GPIO16/HS1_DATA4/U2RXD/EMAC_CLK_OUT"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "27"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -5.08 180)
					(length 2.54)
					(name "GPIO17/HS1_DATA5/U2TXD/EMAC_CLK_OUT_180"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "28"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 25.4 180)
					(length 2.54)
					(name "GPIO5/VSPICS0/HS1_DATA6/EMAC_RX_CLK"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "29"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -45.72 17.78 0)
					(length 2.54)
					(name "EN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -7.62 180)
					(length 2.54)
					(name "GPIO18/VSPICLK/HS1_DATA7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "30"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -10.16 180)
					(length 2.54)
					(name "GPIO19/VSPIQ/U0CTS/EMAC_TXD0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "31"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin no_connect line
					(at -45.72 12.7 0)
					(length 2.54)
					(name "NC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "32"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -12.7 180)
					(length 2.54)
					(name "GPIO21/VSPIHD/EMAC_TX_EN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "33"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 30.48 180)
					(length 2.54)
					(name "GPIO3/U0RXD/CLK_OUT2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "34"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 35.56 180)
					(length 2.54)
					(name "GPIO1/U0TXD/CLK_OUT3/EMAC_RXD2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "35"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -15.24 180)
					(length 2.54)
					(name "GPIO22/VSPIWP/U0RTS/EMAC_TXD1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "36"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -17.78 180)
					(length 2.54)
					(name "GPIO23/VSPID/HS1_STROBE"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "37"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -45.72 30.48 0)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "38"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -45.72 22.86 0)
					(length 2.54)
					(name "THERMAL_PAD"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "39"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 48.26 -38.1 180)
					(length 2.54)
					(name "GPI36/SENSOR_VP/ADC_H/ADC1_CH0/RTC_GPIO0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 48.26 -40.64 180)
					(length 2.54)
					(name "GPI39/SENSOR_VN/ADC1_CH3/ADC_H/RTC_GPIO3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 48.26 -33.02 180)
					(length 2.54)
					(name "GPI34/ADC1_CH6/RTC_GPIO4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 48.26 -35.56 180)
					(length 2.54)
					(name "GPI35/ADC1_CH7/RTC_GPIO5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -27.94 180)
					(length 2.54)
					(name "GPIO32/XTAL_32K_P/ADC1_CH4/TOUCH9/RTC_GPIO9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 48.26 -30.48 180)
					(length 2.54)
					(name "GPIO33/XTAL_32K_N/ADC1_CH5/TOUCH8/RTC_GPIO8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:GND"
			(power)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#PWR"
				(at 0 -6.35 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "GND"
				(at 0 -3.81 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "GND_0_1"
				(polyline
					(pts
						(xy 0 0) (xy 0 -1.27) (xy 1.27 -1.27) (xy 0 -2.54) (xy -1.27 -1.27) (xy 0 -1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "GND_1_1"
				(pin power_in line
					(at 0 0 270)
					(length 0) hide
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:L"
			(pin_numbers hide)
			(pin_names
				(offset 0) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "L"
				(at -1.27 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "L"
				(at -1.27 -1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at -1.27 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -1.27 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "L_0_1"
				(arc
					(start -1.27 0)
					(mid -2.54 1.27)
					(end -3.81 0)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(arc
					(start 1.27 0)
					(mid 0 1.27)
					(end -1.27 0)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(arc
					(start 3.81 0)
					(mid 2.54 1.27)
					(end 1.27 0)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "L_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 1.27)
					(name "1"
						(effects
							(font
								(size 0.762 0.762)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 0.762 0.762)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 1.27)
					(name "2"
						(effects
							(font
								(size 0.762 0.762)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 0.762 0.762)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:LAN8710A-EZC(QFN32)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at -9.906 37.084 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "LAN8710A-EZC(QFN32)"
				(at 0.254 -37.338 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 10.16 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 10.16 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "LAN8710A-EZC(QFN32)_0_1"
				(rectangle
					(start -12.7 35.56)
					(end 12.7 -35.56)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "LAN8710A-EZC(QFN32)_1_1"
				(pin power_in line
					(at -15.24 20.32 0)
					(length 2.4892)
					(name "VDD2A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 10.16 180)
					(length 2.4892)
					(name "RXD1/MODE1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "10"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 12.7 180)
					(length 2.4892)
					(name "RXD0/MODE0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "11"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -15.24 33.02 0)
					(length 2.4892)
					(name "VDDIO"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "12"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 -2.54 180)
					(length 2.4892)
					(name "RXER/RXD4/PHYAD0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "13"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 15.24 -17.78 180)
					(length 2.4892)
					(name "CRS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "14"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 -22.86 180)
					(length 2.4892)
					(name "COL/CRS_DV/MODE2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "15"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 -10.16 180)
					(length 2.4892)
					(name "MDIO"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "16"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input clock
					(at 15.24 -7.62 180)
					(length 2.4892)
					(name "MDC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "17"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 17.78 180)
					(length 2.4892)
					(name "NINT/TXER/TXD4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "18"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input inverted
					(at 15.24 -27.94 180)
					(length 2.4892)
					(name "NRST"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "19"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at -15.24 -17.78 0)
					(length 2.4892)
					(name "LED2/NINTSEL"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 15.24 20.32 180)
					(length 2.4892)
					(name "TXCLK"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "20"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 15.24 22.86 180)
					(length 2.4892)
					(name "TXEN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "21"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 15.24 33.02 180)
					(length 2.4892)
					(name "TXD0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "22"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 15.24 30.48 180)
					(length 2.4892)
					(name "TXD1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "23"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 15.24 27.94 180)
					(length 2.4892)
					(name "TXD2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "24"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 15.24 25.4 180)
					(length 2.4892)
					(name "TXD3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "25"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 15.24 2.54 180)
					(length 2.4892)
					(name "RXDV"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "26"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -15.24 25.4 0)
					(length 2.4892)
					(name "VDD1A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "27"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -15.24 -27.94 0)
					(length 2.4892)
					(name "TXN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "28"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -15.24 -25.4 0)
					(length 2.4892)
					(name "TXP"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "29"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at -15.24 -20.32 0)
					(length 2.4892)
					(name "LED1/REGOFF"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -15.24 -33.02 0)
					(length 2.4892)
					(name "RXN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "30"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -15.24 -30.48 0)
					(length 2.4892)
					(name "RXP"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "31"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 15.24 -33.02 180)
					(length 2.4892)
					(name "RBIAS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "32"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -15.24 2.54 0)
					(length 2.4892)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "33"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -15.24 -5.08 0)
					(length 2.4892)
					(name "XTAL2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -15.24 -10.16 0)
					(length 2.4892)
					(name "XTAL1/CLKIN"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -15.24 15.24 0)
					(length 2.4892)
					(name "VDDCR"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 0 180)
					(length 2.4892)
					(name "RXCLK/PHYAD1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 5.08 180)
					(length 2.4892)
					(name "RXD3/PHYAD2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 15.24 7.62 180)
					(length 2.4892)
					(name "RXD2/RMIISEL"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "9"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:LED"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "LED"
				(at 0 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "LED"
				(at 0 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "LED-3MM LED-5MM LED-10MM LED-0603 LED-0805 LED-1206 LEDV"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "LED_0_1"
				(polyline
					(pts
						(xy -3.302 1.397) (xy -3.302 0.889)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 1.905) (xy -2.032 1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 -1.27) (xy -1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.286 0.381) (xy -3.302 1.397) (xy -2.794 1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.651 1.016) (xy -2.54 1.905) (xy -2.54 1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.27) (xy -1.27 0) (xy 1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(rectangle
					(start 1.27 1.27)
					(end 1.27 -1.27)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "LED_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 3.81)
					(name "K"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 3.81)
					(name "A"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:LED_AK"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "LED"
				(at 0 2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "LED_AK"
				(at 0 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "LED-3MM LED-5MM LED-10MM LED-0603 LED-0805 LED-1206 LEDV"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "LED_AK_0_1"
				(rectangle
					(start -1.27 1.27)
					(end -1.27 -1.27)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.27) (xy 1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 1.905) (xy 2.032 1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 1.397) (xy 3.302 0.889)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 -1.27) (xy 1.27 0) (xy -1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy 1.651 1.016) (xy 2.54 1.905) (xy 2.54 1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.286 0.381) (xy 3.302 1.397) (xy 2.794 1.397)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "LED_AK_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 3.81)
					(name "A"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 3.81)
					(name "K"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:MCP2562-E_SN(SOIC-8_150mil)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "MCP2562-E_SN(SOIC-8_150mil)"
				(at 0 -8.89 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "MCP2562-E_SN(SOIC-8_150mil)_1_1"
				(rectangle
					(start -5.08 5.08)
					(end 5.08 -7.62)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(pin input line
					(at -7.62 2.54 0)
					(length 2.54)
					(name "TxD"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 0 0)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 -2.54 0)
					(length 2.54)
					(name "VDD"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at -7.62 -5.08 0)
					(length 2.54)
					(name "RxD"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at 7.62 -5.08 180)
					(length 2.54)
					(name "VIO"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 7.62 -2.54 180)
					(length 2.54)
					(name "CANL"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at 7.62 0 180)
					(length 2.54)
					(name "CANH"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at 7.62 2.54 180)
					(length 2.54)
					(name "STBY"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:MICRO_SD(TFC-WXCP11-08-LF)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "MICRO_SD"
				(at -8.89 13.97 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "MICRO_SD(TFC-WXCP11-08-LF)"
				(at -8.89 -17.78 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at 0.762 3.81 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_locked" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "ki_fp_filters" "*TFC-WXCP11-08-LF*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "MICRO_SD(TFC-WXCP11-08-LF)_0_1"
				(rectangle
					(start -10.16 12.7)
					(end 2.54 -15.24)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "MICRO_SD(TFC-WXCP11-08-LF)_1_1"
				(circle
					(center -10.16 -12.7)
					(radius 0.254)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin input line
					(at -12.7 -7.62 0)
					(length 2.54)
					(name "DAT2/RES"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at -12.7 10.16 0)
					(length 2.54)
					(name "CD/DAT3/CS"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at -12.7 7.62 0)
					(length 2.54)
					(name "CMD/DI"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin power_in line
					(at -12.7 5.08 0)
					(length 2.54)
					(name "VDD"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input clock
					(at -12.7 0 0)
					(length 2.54)
					(name "CLK/SCLK"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin power_in line
					(at -12.7 2.54 0)
					(length 2.54)
					(name "VSS"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin output line
					(at -12.7 -2.54 0)
					(length 2.54)
					(name "DAT0/DO"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at -12.7 -5.08 0)
					(length 2.54)
					(name "DAT1/RES"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at -12.7 -12.7 0)
					(length 2.54)
					(name "PACK1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "SH1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at -12.7 -12.7 0)
					(length 2.54)
					(name "PACK2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "SH2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:Mounting_hole_Shield_3.3mm"
			(pin_numbers hide)
			(pin_names
				(offset 0) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "Mount-Hole-3.3mm"
				(at -2.54 1.524 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "Mounting_hole_Shield_3.3mm"
				(at -2.54 -2.921 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
					(hide yes)
				)
			)
			(property "Footprint" ""
				(at -6.096 -1.905 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*TEST_PAD40/70/SQUARE* *TESTPAD50/80* *TESPAD28/40* *TESTPAD32/56* *TESTPAD34/60* *TESTPAD311_1* *TESTPAD40/66/SQUARE* *TESTPAD40/66* *TESTPAD* *TESTPAD2* *TESTPAD43/80* *SMD50/40* *TESTPAD50/80* *TESTPAD50/80_SQUARE* *TESTPAD60/110* *TESTPAD311* *SMD80/30* *SMD80/40* *SMD80/50* *TESTPAD80/130* *TESTPAD90/69* *SMD100/40* *TESTPAD100/150* *SMD250/80* *TESTPAD40/OBLONG* *TESTPAD_RPM* *TESTPAD60/90_WITHOUT_MASK*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Mounting_hole_Shield_3.3mm_1_0"
				(polyline
					(pts
						(xy 0 0) (xy 1.27 -1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.27) (xy 2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 1.27) (xy 0 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 0) (xy 1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "Mounting_hole_Shield_3.3mm_1_1"
				(circle
					(center 1.27 0)
					(radius 0.635)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at -2.54 0 0)
					(length 2.54)
					(name "GND1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "GND1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:N-MOS+DIOD"
			(pin_names
				(offset 1.016) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "FET"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "N-MOS+DIOD"
				(at 0 -6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at -1.27 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -1.27 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "N-MOS+DIOD_0_0"
				(circle
					(center -0.635 0)
					(radius 4.191)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 -2.413) (xy -2.54 2.54)
					)
					(stroke
						(width 0.508)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 3.556) (xy -1.27 -3.556)
					)
					(stroke
						(width 0.508)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.254 0.508) (xy -0.9906 0.0254)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.5334 0.762) (xy 2.3622 0.762)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.4986 -2.0828) (xy 1.4986 -2.4892)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.4986 0.8128) (xy 1.4986 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 -2.54) (xy -1.27 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 2.54) (xy -1.27 2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 0.0254) (xy 0.2032 0.0254) (xy 0.2032 -2.5146)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.254 -0.381) (xy -0.9906 0.0254) (xy -0.9398 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.4986 -2.0828) (xy 1.4986 -0.4826) (xy 0.5842 -0.4826) (xy 2.3622 -0.4826) (xy 1.4986 0.8382)
						(xy 0.5334 -0.4572)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 0.2032 -2.5146)
					(radius 0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 1.4732 2.54)
					(radius 0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 1.4986 -2.5146)
					(radius 0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "D"
					(at -0.3302 3.302 0)
					(effects
						(font
							(size 1.016 1.016)
						)
					)
				)
				(text "G"
					(at -3.429 0.3048 0)
					(effects
						(font
							(size 1.016 1.016)
						)
					)
				)
				(text "N-MOS"
					(at -1.905 -0.0254 900)
					(effects
						(font
							(size 0.4064 0.4064)
						)
					)
				)
				(text "S"
					(at -0.3048 -3.4036 0)
					(effects
						(font
							(size 1.016 1.016)
						)
					)
				)
			)
			(symbol "N-MOS+DIOD_1_1"
				(pin input line
					(at -5.08 -2.54 0)
					(length 2.54)
					(name "G"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -2.54 180)
					(length 2.54)
					(name "S"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 2.54 180)
					(length 2.54)
					(name "D"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:Oscillator-100MHZ_TXC-7W"
			(pin_names
				(offset 0) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "CR"
				(at -7.62 8.255 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "Oscillator-100MHZ_TXC-7W"
				(at -12.7 -10.16 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at 0.762 3.81 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*OSCILLATOR*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Oscillator-100MHZ_TXC-7W_1_0"
				(rectangle
					(start -7.62 7.62)
					(end 7.62 -7.62)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(polyline
					(pts
						(xy -7.62 7.62) (xy -7.62 -7.62)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.62 7.62) (xy 7.62 7.62)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
				(polyline
					(pts
						(xy -5.08 -1.016) (xy -3.81 -1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -5.08 1.016) (xy -2.54 1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.826 -0.381) (xy -4.826 0.381)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.826 -0.381) (xy -2.794 -0.381)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.826 0.381) (xy -2.794 0.381)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -3.175) (xy -3.81 -1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -3.175) (xy -1.27 -3.175)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -1.016) (xy -2.54 -1.016)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 1.016) (xy -3.81 3.175)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 3.175) (xy -1.27 3.175)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.794 0.381) (xy -2.794 -0.381)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 -5.08) (xy -1.27 -3.175)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 -3.175) (xy -1.27 3.175)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 3.175) (xy -1.27 5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 5.08) (xy 2.54 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 2.54) (xy 6.35 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 5.08) (xy 2.54 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.35 0) (xy -1.27 -5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.35 0) (xy 7.62 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 7.62 -7.62) (xy -7.62 -7.62)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 7.62 -7.62) (xy 7.62 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 7.62 0) (xy 7.62 5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 7.62 5.08) (xy 2.54 5.08)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 7.62 5.08) (xy 7.62 7.62)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "E/D"
					(at 4.826 6.35 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "OUT"
					(at 4.826 -5.08 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "VDD"
					(at -4.699 5.08 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "VSS"
					(at -4.699 -5.08 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
			)
			(symbol "Oscillator-100MHZ_TXC-7W_1_1"
				(pin input line
					(at 10.16 5.08 180)
					(length 2.54)
					(name "E/D"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin power_in line
					(at -10.16 -5.08 0)
					(length 2.54)
					(name "VSS"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin output line
					(at 10.16 0 180)
					(length 2.54)
					(name "OUT"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin power_in line
					(at -10.16 5.08 0)
					(length 2.54)
					(name "VDD"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:P-MOS+DIOD"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "FET"
				(at -6.35 -3.81 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "P-MOS+DIOD"
				(at -10.16 -6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "P-MOS+DIOD_0_0"
				(circle
					(center -2.54 3.3782)
					(radius 0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0254 1.7018) (xy 0.6604 0.7874)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.4318 4.3688) (xy 0.4318 2.4892)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.4572 3.4036) (xy 2.4892 3.4036)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0762 1.7018) (xy -0.7112 0.7874) (xy -0.6858 0.8382)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0254 0.254) (xy -0.0254 1.7272) (xy 2.5146 1.7272)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.5146 3.3782) (xy -0.9144 3.3782) (xy -0.9144 4.2926) (xy -0.9144 2.5146) (xy 0.4064 3.3782)
						(xy -0.889 4.3434)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 0.2286) (xy 4.4196 0.254) (xy 4.4196 0.0762) (xy -4.4196 0.0762) (xy -4.445 0.0762)
						(xy -4.445 0.1524) (xy 4.2926 0.1524)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.0988 -1.016) (xy 3.0988 -1.016) (xy 3.0988 -1.1938) (xy -3.0734 -1.2192) (xy -3.1242 -1.2192)
						(xy -3.1242 -1.0414) (xy -3.048 -1.143) (xy 2.9972 -1.1176)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 0 0)
					(radius 4.7752)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.5146 1.7272)
					(radius 0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.5146 3.4036)
					(radius 0.1016)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "D"
					(at -3.429 3.9878 900)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "G"
					(at 1.7272 -2.032 900)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "P-MOS"
					(at 0.0254 -0.381 0)
					(effects
						(font
							(size 0.4064 0.4064)
						)
					)
				)
				(text "S"
					(at 1.7526 4.1402 900)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
			)
			(symbol "P-MOS+DIOD_1_1"
				(pin input line
					(at 2.54 -6.35 90)
					(length 5.08)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 5.08 270)
					(length 5.08)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -2.54 5.08 270)
					(length 5.08)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:PWR-JAKPWR_JACK_UNI_MILLING"
			(pin_names
				(offset 1.016) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "PWR"
				(at 2.54 4.064 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "PWR-JAKPWR_JACK_UNI_MILLING"
				(at -15.24 -4.826 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at -0.762 3.81 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*PWR_JACK_UNI_MILLING*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "PWR-JAKPWR_JACK_UNI_MILLING_1_0"
				(polyline
					(pts
						(xy -1.524 -0.762) (xy -2.794 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -2.54) (xy -1.524 -0.762)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.508 -1.524) (xy 1.016 -1.524)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 -2.286) (xy 0.508 -1.524)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 0) (xy 0.762 -2.286)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.016 -1.524) (xy 0.762 -2.286)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 -2.54) (xy 0 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 0) (xy 0.762 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "PWR-JAKPWR_JACK_UNI_MILLING_1_1"
				(rectangle
					(start 2.54 2.032)
					(end -2.794 3.048)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(pin passive line
					(at 5.08 2.54 180)
					(length 2.54)
					(name "+"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "+"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 -2.54 180)
					(length 2.54)
					(name "-"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "-"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.54)
					(name "-"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "-"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:PWR_FLAG"
			(power)
			(pin_numbers hide)
			(pin_names
				(offset 0) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "#FLG"
				(at 0 2.413 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Value" "PWR_FLAG"
				(at 0 4.572 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "PWR_FLAG_0_0"
				(pin power_out line
					(at 0 0 90)
					(length 0)
					(name "pwr"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
				)
			)
			(symbol "PWR_FLAG_0_1"
				(polyline
					(pts
						(xy 0 0) (xy 0 1.27) (xy -1.905 2.54) (xy 0 3.81) (xy 1.905 2.54) (xy 0 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:Q_NPN_BEC"
			(pin_names
				(offset 0) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "Q"
				(at 7.62 1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify right)
				)
			)
			(property "Value" "Q_NPN_BEC"
				(at 15.24 -1.27 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify right)
				)
			)
			(property "Footprint" ""
				(at 5.08 2.54 0)
				(effects
					(font
						(size 0.7366 0.7366)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "Q_NPN_BEC_0_1"
				(polyline
					(pts
						(xy 0.635 0.635) (xy 2.54 2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 -0.635) (xy 2.54 -2.54) (xy 2.54 -2.54)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 1.905) (xy 0.635 -1.905) (xy 0.635 -1.905)
					)
					(stroke
						(width 0.508)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.778) (xy 1.778 -1.27) (xy 2.286 -2.286) (xy 1.27 -1.778) (xy 1.27 -1.778)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 1.27 0)
					(radius 2.8194)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "Q_NPN_BEC_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 5.715)
					(name "B"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 -5.08 90)
					(length 2.54)
					(name "E"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 5.08 270)
					(length 2.54)
					(name "C"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:R"
			(pin_numbers hide)
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "R"
				(at 0 2.032 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "R"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 -1.778 0)
				(effects
					(font
						(size 0.762 0.762)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 90)
				(effects
					(font
						(size 0.762 0.762)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "R_* Resistor_*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "R_0_1"
				(rectangle
					(start 2.54 -1.016)
					(end -2.54 1.016)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "R_1_1"
				(pin passive line
					(at -3.81 0 0)
					(length 1.27)
					(name "~"
						(effects
							(font
								(size 1.524 1.524)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.524 1.524)
							)
						)
					)
				)
				(pin passive line
					(at 3.81 0 180)
					(length 1.27)
					(name "~"
						(effects
							(font
								(size 1.524 1.524)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.524 1.524)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "RM"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "RA1206_(4x0603)_4B8_Smashed"
				(at 0.2032 1.016 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 1.27 -2.54 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 1.27 -2.54 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_0_0"
				(rectangle
					(start -1.2446 4.445)
					(end 1.2954 3.175)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_1_1"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_1_2"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_2_1"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "2.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "2.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_2_2"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_3_1"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "3.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "3.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_3_2"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_4_1"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "4.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "4.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
			(symbol "RA1206_(4x0603)_4B8_Smashed_4_2"
				(pin passive line
					(at -5.08 3.81 0)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.1"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 3.81 180)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "1.2"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:RJLBC-060TC1_GND"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "CON"
				(at -22.606 16.002 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "RJLBC-060TC1_GND"
				(at -22.86 -15.24 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at 0.762 3.81 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 0.9906 0.9906)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_locked" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "ki_fp_filters" "*RJLBC-060TC1* *RJLBC-060TC1_MILLING*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "RJLBC-060TC1_GND_1_0"
				(polyline
					(pts
						(xy -22.86 -12.7) (xy -15.24 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -22.86 -3.81) (xy -22.86 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -22.86 -3.81) (xy -15.24 -3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -22.86 6.35) (xy -22.86 -3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -22.86 6.35) (xy -15.24 6.35)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -22.86 15.24) (xy -22.86 6.35)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -22.86 15.24) (xy -15.24 15.24)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 -12.7) (xy 12.7 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 -10.16) (xy -15.24 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 -10.16) (xy -12.065 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 -5.08) (xy -15.24 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 -3.81) (xy -15.24 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 -2.54) (xy -15.24 -3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 0) (xy -15.24 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 2.54) (xy -15.24 0)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 5.08) (xy -15.24 2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 6.35) (xy -15.24 5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 10.16) (xy -15.24 6.35)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 15.24) (xy -15.24 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -15.24 15.24) (xy 12.7 15.24)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -13.97 -7.62) (xy -12.065 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -13.97 10.16) (xy -15.24 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -13.97 10.16) (xy -13.97 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 -7.62) (xy -12.065 -10.16)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 -5.08) (xy -15.24 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 -5.08) (xy -12.065 -7.62)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 7.62) (xy -15.24 7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 10.16) (xy -13.97 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 10.16) (xy -12.065 7.62)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 12.7) (xy -15.24 12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -12.065 12.7) (xy -12.065 10.16)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -10.795 -4.445) (xy -10.795 -10.795)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -10.795 13.335) (xy -10.795 6.985)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 -7.62) (xy -9.525 -10.16)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 -7.62) (xy -6.35 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 -5.08) (xy -9.525 -7.62)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 -5.08) (xy -3.81 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 10.16) (xy -9.525 7.62)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 10.16) (xy -7.62 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 12.7) (xy -9.525 10.16)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -9.525 12.7) (xy -4.445 12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.89 -1.905) (xy -8.255 -1.905)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.89 -0.635) (xy -8.255 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.89 3.175) (xy -8.255 3.175)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.89 4.445) (xy -8.255 4.445)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 -2.54) (xy -15.24 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 -1.905) (xy -8.89 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 -1.905) (xy -8.255 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 -1.905) (xy -7.62 -1.905)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 -0.635) (xy -8.255 0)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 -0.635) (xy -7.62 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 0) (xy -15.24 0)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 2.54) (xy -15.24 2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 3.175) (xy -8.89 4.445)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 3.175) (xy -8.255 2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 3.175) (xy -7.62 3.175)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 4.445) (xy -8.255 5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 4.445) (xy -7.62 4.445)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -8.255 5.08) (xy -15.24 5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.62 -0.635) (xy -8.255 -1.905)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.62 4.445) (xy -8.255 3.175)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.62 10.16) (xy -7.62 13.97)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.62 13.97) (xy 0 13.97)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.239 -1.778) (xy -6.731 -1.27)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.239 -1.016) (xy -6.731 -0.508)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.239 3.302) (xy -6.731 3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -7.239 4.064) (xy -6.731 4.572)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 -1.27) (xy -6.985 -1.27)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 -1.27) (xy -6.731 -1.524)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 -0.508) (xy -6.985 -0.508)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 -0.508) (xy -6.731 -0.762)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 3.81) (xy -6.985 3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 3.81) (xy -6.731 3.556)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 4.572) (xy -6.985 4.572)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.731 4.572) (xy -6.731 4.318)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.35 -7.62) (xy -6.35 -3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -6.35 -3.81) (xy 0.635 -3.81)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -5.08 10.16) (xy -1.905 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 -7.62) (xy -1.27 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 7.62) (xy -9.525 7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 8.89) (xy -4.445 7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 8.89) (xy -2.54 8.89)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 11.43) (xy -4.445 12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -4.445 11.43) (xy -2.54 11.43)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -10.16) (xy -9.525 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -10.16) (xy -3.81 -8.89)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -8.89) (xy -1.905 -8.89)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -6.35) (xy -3.81 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -3.81 -6.35) (xy -1.905 -6.35)
					)
					(stroke
						(width 0.9906)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 5.08) (xy 12.7 5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 8.89) (xy -2.54 5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 11.43) (xy -2.54 12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.54 12.7) (xy 12.7 12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 -8.89) (xy -1.905 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 -6.35) (xy -1.905 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 -2.54) (xy 12.7 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 10.16) (xy 1.905 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 13.97) (xy 0 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 -5.08) (xy 1.905 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 -3.81) (xy 0.635 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 -10.16) (xy -1.905 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 -7.62) (xy 1.905 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 -5.588) (xy 4.445 -5.588)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 -5.08) (xy 1.905 -5.588)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 -4.572) (xy 1.905 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 9.652) (xy 4.445 9.652)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 10.16) (xy 1.905 9.652)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.905 10.668) (xy 1.905 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.175 -11.43) (xy 8.255 -11.43)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.302 -12.319) (xy 3.81 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 3.937 -12.319) (xy 4.445 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 -12.319) (xy 4.953 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 -5.588) (xy 4.445 -4.572)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 -5.08) (xy 5.715 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 -4.572) (xy 1.905 -4.572)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 9.652) (xy 4.445 10.668)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 10.16) (xy 5.715 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.445 10.668) (xy 1.905 10.668)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 4.953 -12.319) (xy 5.461 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.08 -10.16) (xy 5.715 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.08 -9.525) (xy 6.35 -9.525)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.461 -12.319) (xy 5.969 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.715 -10.16) (xy 5.715 -11.43)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.715 -10.16) (xy 6.35 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.715 -5.08) (xy 5.715 -9.525)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.715 -5.08) (xy 6.985 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.715 10.16) (xy 5.715 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.715 10.16) (xy 6.985 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 5.969 -12.319) (xy 6.477 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.477 -12.319) (xy 6.985 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 -12.319) (xy 7.493 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 -5.588) (xy 9.525 -5.588)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 -5.08) (xy 6.985 -5.588)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 -4.572) (xy 6.985 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 9.652) (xy 9.525 9.652)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 10.16) (xy 6.985 9.652)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 6.985 10.668) (xy 6.985 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 7.62 -12.319) (xy 8.128 -11.811)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 -5.588) (xy 9.525 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 -5.08) (xy 9.525 -4.572)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 -5.08) (xy 11.43 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 -4.572) (xy 6.985 -4.572)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 9.652) (xy 9.525 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 10.16) (xy 9.525 10.668)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 10.16) (xy 11.43 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 9.525 10.668) (xy 6.985 10.668)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 10.16 -10.16) (xy 10.16 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 10.16 -7.62) (xy 1.905 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 11.43 -7.62) (xy 12.7 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 11.43 -5.08) (xy 11.43 -7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 11.43 -5.08) (xy 12.7 -5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 11.43 7.62) (xy 12.7 7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 11.43 10.16) (xy 11.43 7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 11.43 10.16) (xy 12.7 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 -12.7) (xy 20.32 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 -10.16) (xy 10.16 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 -10.16) (xy 12.7 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 -2.54) (xy 12.7 -10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 5.08) (xy 12.7 -2.54)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 7.62) (xy 12.7 5.08)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 10.16) (xy 12.7 7.62)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 12.7) (xy 12.7 10.16)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 15.24) (xy 12.7 12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 12.7 15.24) (xy 20.32 15.24)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 20.32 15.24) (xy 20.32 -12.7)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "1"
					(at 18.669 12.954 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "1:1"
					(at -10.795 -3.429 0)
					(effects
						(font
							(size 1.27 1.27)
							(bold yes)
						)
					)
				)
				(text "1:1"
					(at -10.795 14.351 0)
					(effects
						(font
							(size 1.27 1.27)
							(bold yes)
						)
					)
				)
				(text "1nF/2kV"
					(at -1.651 -11.43 0)
					(effects
						(font
							(size 1.27 1.27)
							(bold yes)
						)
					)
				)
				(text "2"
					(at 18.669 5.334 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "3"
					(at 18.669 -2.286 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "4"
					(at 18.669 10.414 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "5"
					(at 18.669 7.874 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "6"
					(at 18.669 -9.906 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "7"
					(at 18.669 -4.826 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "75"
					(at 3.429 -3.683 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "75"
					(at 3.429 11.557 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "75"
					(at 8.509 -3.683 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "75"
					(at 8.509 11.557 0)
					(effects
						(font
							(size 1.27 1.27)
						)
					)
				)
				(text "8"
					(at 18.669 -7.366 0)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "GND"
					(at 10.795 -11.43 0)
					(effects
						(font
							(size 1.27 1.27)
							(bold yes)
						)
					)
				)
				(text "GREEN"
					(at -2.54 3.81 0)
					(effects
						(font
							(size 1.27 1.27)
							(bold yes)
						)
					)
				)
				(text "RJ45 SIDE"
					(at 15.367 2.286 900)
					(effects
						(font
							(size 1.778 1.778)
							(bold yes)
						)
					)
				)
				(text "YELLOW"
					(at -1.905 -0.635 0)
					(effects
						(font
							(size 1.27 1.27)
							(bold yes)
						)
					)
				)
			)
			(symbol "RJLBC-060TC1_GND_1_1"
				(circle
					(center -13.97 10.16)
					(radius 0.254)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center -12.7 -4.445)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -12.7 13.335)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -8.89 -4.445)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -8.89 13.335)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -5.08 8.255)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -5.08 12.065)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -1.27 -9.525)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center -1.27 -5.715)
					(radius 0.127)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(circle
					(center 5.715 -5.08)
					(radius 0.254)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 5.715 10.16)
					(radius 0.254)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 11.43 -5.08)
					(radius 0.254)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 11.43 10.16)
					(radius 0.254)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin bidirectional line
					(at -25.4 12.7 0)
					(length 2.54)
					(name "TD+"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin bidirectional line
					(at -25.4 7.62 0)
					(length 2.54)
					(name "TD-"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin input line
					(at -25.4 10.16 0)
					(length 2.54)
					(name "COM"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin input line
					(at -25.4 -7.62 0)
					(length 2.54)
					(name "NC"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "6"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin bidirectional line
					(at -25.4 -5.08 0)
					(length 2.54)
					(name "RD+"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "7"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin bidirectional line
					(at -25.4 -10.16 0)
					(length 2.54)
					(name "RD-"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "8"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin passive line
					(at -25.4 5.08 0)
					(length 2.54)
					(name "AG"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "AG1"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin passive line
					(at -25.4 0 0)
					(length 2.54)
					(name "AY"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "AY1"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin input line
					(at 5.08 -15.24 90)
					(length 2.54)
					(name "GND1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "GND1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at 7.62 -15.24 90)
					(length 2.54)
					(name "GND2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "GND2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -25.4 2.54 0)
					(length 2.54)
					(name "KG"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "KG1"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
				(pin passive line
					(at -25.4 -2.54 0)
					(length 2.54)
					(name "KY"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
					(number "KY1"
						(effects
							(font
								(size 1.2954 1.2954)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:RPM7236-H8"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 6.35 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "RPM7236-H8"
				(at 0 -6.35 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" ""
				(at 0 1.27 0)
				(effects
					(font
						(size 2.9972 2.9972)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 1.27 0)
				(effects
					(font
						(size 2.9972 2.9972)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "RPM7236-H8_0_1"
				(rectangle
					(start -5.08 5.08)
					(end 5.08 -5.08)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "RPM7236-H8_1_1"
				(pin passive line
					(at 7.62 -2.54 180)
					(length 2.54)
					(name "MH"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin output line
					(at 7.62 0 180)
					(length 2.54)
					(name "Vout"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 -2.54 0)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 2.54 0)
					(length 2.54)
					(name "VCC"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:Relay"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "REL"
				(at 3.81 3.81 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "Relay"
				(at 3.81 -3.81 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_locked" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(symbol "Relay_1_1"
				(rectangle
					(start -3.81 -1.8796)
					(end 3.7846 1.905)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.905 -1.8288) (xy 1.905 1.8796)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at 0 5.08 270)
					(length 3.2004)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 0 -5.08 90)
					(length 3.2004)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
			(symbol "Relay_2_1"
				(circle
					(center 0 -0.6096)
					(radius 0.0508)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 0 -0.6096)
					(radius 0.3048)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.5908 2.54) (xy -3.2766 2.54)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -2.5908 2.54) (xy -1.778 2.54)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -0.6096) (xy 0 -1.905)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0 -0.381) (xy 3.302 2.921)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.6162 2.54) (xy 1.8034 2.54)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.6162 2.54) (xy 3.3274 2.54)
					)
					(stroke
						(width 0.3048)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at 0 -5.08 90)
					(length 2.9972)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "COM0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 2.54 180)
					(length 2.4892)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "NC0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 2.54 0)
					(length 2.4892)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "NO0"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:SIDE_WTCM-TR(3x4)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "SW"
				(at -4.064 2.794 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "SIDE_WTCM-TR(3x4)"
				(at 14.478 2.794 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at -0.0254 0.9652 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at -0.0254 0.9652 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SIDE_WTCM-TR(3x4)_0_1"
				(circle
					(center -2.0066 0)
					(radius 0.4318)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.635 3.048) (xy 0.6096 3.048)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0254 0.9398) (xy -2.0066 0.9398)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0254 0.9398) (xy 1.9812 0.9398)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.0254 1.016) (xy -0.0254 2.9718)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(circle
					(center 2.0574 0.0254)
					(radius 0.4318)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SIDE_WTCM-TR(3x4)_1_1"
				(pin passive line
					(at -5.08 0 0)
					(length 2.5908)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at 5.08 0 180)
					(length 2.5908)
					(name "~"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:SJ"
			(pin_names
				(offset 1.016) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "SJ"
				(at -1.27 1.905 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "SJ"
				(at -1.27 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" "jumper_SJ"
				(at 0.2032 1.5748 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*SJ* *SJ-CLOSE* *SJ_1_SMALLER_CLOSE* *SJ_1_SMALLER_CLOSE_10MILS* *SJ_1_THE_SMALLEST* *SJ_1_SMALLER* *SJW*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SJ_0_1"
				(arc
					(start -0.508 0.762)
					(mid -1.27 0)
					(end -0.508 -0.762)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.143 0.381) (xy -1.143 -0.254)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.016 0.508) (xy -1.016 -0.508)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.889 0.508) (xy -0.889 -0.508)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.762 0.635) (xy -0.762 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.635 0.762) (xy -0.635 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -0.508 0.762) (xy -0.508 -0.762)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.508 0.762) (xy 0.508 -0.762)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 0.762) (xy 0.635 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.762 0.635) (xy 0.762 -0.635)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.889 0.508) (xy 0.889 -0.508)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.016 0.508) (xy 1.016 -0.381)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.143 0.381) (xy 1.143 -0.381)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(arc
					(start 0.508 -0.762)
					(mid 1.0468 -0.5388)
					(end 1.27 0)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(arc
					(start 1.27 0)
					(mid 1.0468 0.5388)
					(end 0.508 0.762)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SJ_1_1"
				(pin passive line
					(at -2.54 0 0)
					(length 1.27)
					(name "1"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 0 180)
					(length 1.27)
					(name "2"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:SJ2W_Closed(1-2)"
			(pin_names
				(offset 1.016) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "SJ"
				(at 2.54 0.381 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "SJ2W_Closed(1-2)"
				(at 2.54 -1.905 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at 0.762 3.81 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*SJ_2* *SJ_2_SMALL* *SJ_2_SMALLER* *SJ_2_SMALL_23_TIED* *SJ_2_SMALL_12_TIED* *SJ_2_SMALLER_12_TIED* *SJ_2_SMALLER_23_TIED* *SJ_2W*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SJ2W_Closed(1-2)_0_1"
				(polyline
					(pts
						(xy 0 1.905) (xy 0 0)
					)
					(stroke
						(width 0.762)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SJ2W_Closed(1-2)_1_0"
				(polyline
					(pts
						(xy -2.54 0) (xy -1.27 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 -0.635) (xy -1.27 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 0) (xy -1.27 0.635)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 0.635) (xy 1.27 0.635)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -0.635) (xy -1.27 -0.635)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 0.635) (xy 1.27 -0.635)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SJ2W_Closed(1-2)_1_1"
				(arc
					(start -1.27 -1.397)
					(mid 0 -2.5695)
					(end 1.27 -1.397)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(rectangle
					(start -1.27 -0.635)
					(end 1.27 0.635)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(polyline
					(pts
						(xy -1.1684 1.3716) (xy 1.143 1.3716)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.143 -1.397) (xy 1.143 -1.397)
					)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(arc
					(start 1.27 1.397)
					(mid 0 2.5695)
					(end -1.27 1.397)
					(stroke
						(width 0.254)
						(type solid)
					)
					(fill
						(type outline)
					)
				)
				(pin passive line
					(at 0 5.08 270)
					(length 2.54)
					(name "1"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at -5.08 0 0)
					(length 2.54)
					(name "2"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin passive line
					(at 0 -5.08 90)
					(length 2.54)
					(name "3"
						(effects
							(font
								(size 0.508 0.508)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:SMBJ6.0A"
			(pin_names
				(offset 0)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "D"
				(at -2.9464 2.6416 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "SMBJ6.0A"
				(at -4.445 -4.445 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" ""
				(at 0.762 3.81 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*DO214AA*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SMBJ6.0A_0_1"
				(rectangle
					(start -2.54 0)
					(end -1.27 0)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(rectangle
					(start 1.27 0)
					(end 2.54 0)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SMBJ6.0A_1_0"
				(polyline
					(pts
						(xy -1.27 -1.905) (xy 1.27 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.27 1.905) (xy -1.27 -1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 0) (xy -1.27 1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.397 -1.905) (xy 0.762 -1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.397 1.905) (xy 1.397 -1.905)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "SMBJ6.0A_1_1"
				(pin passive line
					(at 2.54 0 180)
					(length 0)
					(name "K"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin passive line
					(at -2.54 0 0)
					(length 0)
					(name "A"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:SY8009AAAC(SOT23-5)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at -1.27 5.715 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "SY8009AAAC(SOT23-5)"
				(at -10.16 -6.985 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Footprint" "OLIMEX_Regulators-FP:SOT-23-5"
				(at 0 -8.255 0)
				(effects
					(font
						(size 1.016 1.016)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0.762 1.016 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Note" "PB-Free"
				(at 0 -10.16 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "ki_fp_filters" "*SOT23-5*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "SY8009AAAC(SOT23-5)_0_0"
				(rectangle
					(start -1.016 -1.651)
					(end 1.651 -3.302)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -1.016 -1.651) (xy -1.016 -3.302) (xy -5.08 -3.302)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy -5.08 1.778) (xy -1.016 1.778) (xy -1.016 0.254) (xy -1.016 -1.651) (xy -5.08 -1.651)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 0.635 5.08) (xy 0.635 4.191) (xy 0.635 2.794) (xy -1.016 2.794) (xy -1.016 1.016) (xy -1.016 -1.651)
						(xy 5.08 -1.651)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(text "2A continuous, 3A peak"
					(at 1.905 1.651 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "Cin=22uF/6.3V/X5R"
					(at -2.286 3.683 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "Cout=2x22uF/6.3V/X5R"
					(at 2.032 -1.27 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "DCR<50mR"
					(at 2.921 3.683 0)
					(effects
						(font
							(size 0.4572 0.4572)
						)
					)
				)
				(text "Do not float."
					(at -3.2512 0.8382 0)
					(effects
						(font
							(size 0.2032 0.2032)
						)
					)
				)
				(text "Enable control."
					(at -2.9972 1.4732 0)
					(effects
						(font
							(size 0.254 0.254)
							(bold yes)
						)
					)
				)
				(text "FB Input Current, I(FB)=50nA(max)"
					(at 0 -4.445 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "Feedback Reference Voltage, V(REF)=0.6V"
					(at 0 -3.81 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "load current capability!"
					(at 1.905 1.016 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "Lx=2.2uH"
					(at 2.794 4.445 0)
					(effects
						(font
							(size 0.4572 0.4572)
							(bold yes)
						)
					)
				)
				(text "Part Number:"
					(at 0.381 -2.032 0)
					(effects
						(font
							(size 0.2286 0.2286)
							(italic yes)
						)
					)
				)
				(text "Pull high to turn on."
					(at -3.0226 1.143 0)
					(effects
						(font
							(size 0.1778 0.1778)
							(bold yes)
						)
					)
				)
				(text "Quiescent Current I(Q)=55uA"
					(at 2.0066 0.381 0)
					(effects
						(font
							(size 0.254 0.254)
							(bold yes)
						)
					)
				)
				(text "Recommended:"
					(at 2.032 -0.762 0)
					(effects
						(font
							(size 0.3048 0.3048)
							(bold yes)
						)
					)
				)
				(text "Shutdown Current I(SHDN)=0.1-1uA"
					(at 2.032 -0.254 0)
					(effects
						(font
							(size 0.2032 0.2032)
							(bold yes)
						)
					)
				)
				(text "SY8089AAAC"
					(at 0.381 -2.921 0)
					(effects
						(font
							(size 0.254 0.254)
							(italic yes)
						)
					)
				)
				(text "SY8089AAC"
					(at 0.381 -2.4638 0)
					(effects
						(font
							(size 0.254 0.254)
							(italic yes)
						)
					)
				)
				(text "V(ENH)=1.5V"
					(at -3.175 -0.762 0)
					(effects
						(font
							(size 0.254 0.254)
							(bold yes)
						)
					)
				)
				(text "V(ENL)=0.4V"
					(at -3.175 -1.27 0)
					(effects
						(font
							(size 0.254 0.254)
							(bold yes)
						)
					)
				)
				(text "Vin=2.7-5.5V"
					(at -2.286 4.445 0)
					(effects
						(font
							(size 0.4572 0.4572)
							(bold yes)
						)
					)
				)
				(text "Vout=0.6*(1+Ra/Rb)"
					(at 3.302 -3.302 0)
					(effects
						(font
							(size 0.1778 0.1778)
							(italic yes)
						)
					)
				)
			)
			(symbol "SY8009AAAC(SOT23-5)_0_1"
				(rectangle
					(start -5.08 5.08)
					(end 5.08 -5.08)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "SY8009AAAC(SOT23-5)_1_1"
				(pin input line
					(at -7.62 0 0)
					(length 2.54)
					(name "EN"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 -2.54 0)
					(length 2.54)
					(name "GND"
						(effects
							(font
								(size 0.762 0.762)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin output line
					(at 7.62 2.54 180)
					(length 2.54)
					(name "LX"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at -7.62 2.54 0)
					(length 2.54)
					(name "IN"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
				(pin input line
					(at 7.62 -2.54 180)
					(length 2.54)
					(name "FB"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:TESTPAD"
			(pin_numbers hide)
			(pin_names
				(offset 0) hide)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "TESTPAD"
				(at -2.54 1.524 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
				)
			)
			(property "Value" "TESTPAD"
				(at -2.54 -2.921 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(justify left bottom)
					(hide yes)
				)
			)
			(property "Footprint" ""
				(at -6.096 -1.905 0)
				(effects
					(font
						(size 0.508 0.508)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 0 0 90)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "ki_fp_filters" "*TEST_PAD40/70/SQUARE* *TESTPAD50/80* *TESPAD28/40* *TESTPAD32/56* *TESTPAD34/60* *TESTPAD311_1* *TESTPAD40/66/SQUARE* *TESTPAD40/66* *TESTPAD* *TESTPAD2* *TESTPAD43/80* *SMD50/40* *TESTPAD50/80* *TESTPAD50/80_SQUARE* *TESTPAD60/110* *TESTPAD311* *SMD80/30* *SMD80/40* *SMD80/50* *TESTPAD80/130* *TESTPAD90/69* *SMD100/40* *TESTPAD100/150* *SMD250/80* *TESTPAD40/OBLONG* *TESTPAD_RPM* *TESTPAD60/90_WITHOUT_MASK*"
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "TESTPAD_1_0"
				(polyline
					(pts
						(xy 0 0) (xy 1.27 -1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 -1.27) (xy 2.54 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 1.27 1.27) (xy 0 0)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(polyline
					(pts
						(xy 2.54 0) (xy 1.27 1.27)
					)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "TESTPAD_1_1"
				(circle
					(center 1.27 0)
					(radius 0.635)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
				(pin passive line
					(at -2.54 0 0)
					(length 2.54)
					(name "Pad"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.016 1.016)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:USB-MINI"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "USB"
				(at -4.445 8.255 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Value" "USB-MINI"
				(at -7.62 -8.89 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Footprint" ""
				(at 2.54 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Datasheet" ""
				(at 2.54 0 0)
				(effects
					(font
						(size 1.524 1.524)
					)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "USB-MINI_0_1"
				(rectangle
					(start 3.81 6.35)
					(end -2.54 -6.35)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type none)
					)
				)
			)
			(symbol "USB-MINI_1_1"
				(pin passive line
					(at 0 -10.16 90)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "0"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 0 10.16 270)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "0"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 -10.16 90)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "0"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin passive line
					(at 2.54 10.16 270)
					(length 3.81)
					(name "~"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
					(number "0"
						(effects
							(font
								(size 0.9906 0.9906)
							)
						)
					)
				)
				(pin input line
					(at -7.62 5.08 0)
					(length 5.08)
					(name "VBUS"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at -7.62 2.54 0)
					(length 5.08)
					(name "D-"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin bidirectional line
					(at -7.62 0 0)
					(length 5.08)
					(name "D+"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -7.62 -2.54 0)
					(length 5.08)
					(name "ID"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "4"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 -5.08 0)
					(length 5.08)
					(name "GND"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "5"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
		(symbol "ESP32-EVB_Rev_K1:VDA2710NTA(SOT-23)"
			(pin_names
				(offset 1.016)
			)
			(exclude_from_sim no)
			(in_bom yes)
			(on_board yes)
			(property "Reference" "U"
				(at 0 7.62 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Value" "VDA2710NTA(SOT-23)"
				(at 0 -7.62 0)
				(effects
					(font
						(size 1.27 1.27)
					)
				)
			)
			(property "Footprint" "OLIMEX_IC-FP:SOT-23"
				(at 2.54 -10.16 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Datasheet" ""
				(at 2.54 -2.54 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(property "Description" ""
				(at 0 0 0)
				(effects
					(font
						(size 1.27 1.27)
					)
					(hide yes)
				)
			)
			(symbol "VDA2710NTA(SOT-23)_0_1"
				(rectangle
					(start -5.08 5.08)
					(end 5.08 -5.08)
					(stroke
						(width 0)
						(type solid)
					)
					(fill
						(type background)
					)
				)
			)
			(symbol "VDA2710NTA(SOT-23)_1_1"
				(pin open_collector line
					(at 7.62 0 180)
					(length 2.54)
					(name "VOut"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "1"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin power_in line
					(at -7.62 -2.54 0)
					(length 2.54)
					(name "Vss"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "2"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
				(pin input line
					(at -7.62 2.54 0)
					(length 2.54)
					(name "VIn"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
					(number "3"
						(effects
							(font
								(size 1.27 1.27)
							)
						)
					)
				)
			)
		)
	)
	(junction
		(at 88.9 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "03abf177-2a04-4920-9f53-fe025b93d4db")
	)
	(junction
		(at 279.4 340.36)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "04146916-ba37-485b-921e-4dfdd0e6bd77")
	)
	(junction
		(at 73.66 53.34)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "05b7de96-1982-4d06-90b2-c0383ecbdce8")
	)
	(junction
		(at 345.44 353.06)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "0789aa90-c682-4082-9a77-da0d0dad6d1d")
	)
	(junction
		(at 411.48 251.46)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "0c13acba-46bb-417f-b666-3ee183966ed1")
	)
	(junction
		(at 208.28 83.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "0ea12483-350f-4238-b6b1-a70e4ec2c3b1")
	)
	(junction
		(at 220.98 162.56)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "1501f79b-864b-4905-98e9-a3725b010671")
	)
	(junction
		(at 25.4 162.56)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "16dc6f5c-f2c9-43e2-9dfa-dac8e4c6c4ef")
	)
	(junction
		(at 101.6 335.28)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "1900c3eb-0d9c-44a4-9723-5c8c3d8597ba")
	)
	(junction
		(at 182.88 208.28)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "19c2391b-9f3b-4f50-847f-fe7b58500fbd")
	)
	(junction
		(at 358.14 261.62)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "19d74ab1-589a-4bdd-86ce-c15a6db63aa2")
	)
	(junction
		(at 106.68 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "1a47715d-ec10-427e-8a34-4ba515e17186")
	)
	(junction
		(at 220.98 152.4)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "1b5578ee-f547-4966-b8c4-d62ea0b7fc2c")
	)
	(junction
		(at 101.6 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "1ce4d99a-227f-45ff-b5bb-c0bfeb05661d")
	)
	(junction
		(at 119.38 160.02)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "2065fdf4-35c2-4bab-8e1b-a18dfbfb3aae")
	)
	(junction
		(at 210.82 264.16)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "20d9d16d-5da6-4469-94ae-a504b3dc2b91")
	)
	(junction
		(at 119.38 147.32)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "2469339a-861a-4c2a-a116-6caf1d3421f3")
	)
	(junction
		(at 25.4 142.24)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "24e38846-290d-41ab-8a3b-7424c5dfc19c")
	)
	(junction
		(at 116.84 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "269abffa-387e-44b7-aa07-85aa09308f6e")
	)
	(junction
		(at 274.32 246.38)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "28c72829-08d0-4040-b26d-7be6a2292463")
	)
	(junction
		(at 132.08 208.28)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "29d5069f-c044-4e21-897b-05d388de45b1")
	)
	(junction
		(at 299.72 167.64)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "2a50562b-8107-452b-8cf5-772aa8cdabbf")
	)
	(junction
		(at 530.86 193.04)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "2dae9afd-f3e7-4a6b-9514-f3fe32742d95")
	)
	(junction
		(at 289.56 193.04)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "2e347d43-50d0-4959-829c-52649bdb1b5f")
	)
	(junction
		(at 299.72 264.16)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "309a0364-2133-4fe1-aa96-3690c6f75a00")
	)
	(junction
		(at 60.96 142.24)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "3286a32d-e758-4135-a1f4-6aa12a2a77e5")
	)
	(junction
		(at 182.88 167.64)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "36b2a2b3-5f79-4f4f-8a9c-6230b9dfaed7")
	)
	(junction
		(at 121.92 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "392e69e8-ac86-4932-905c-b0fd1c9b1856")
	)
	(junction
		(at 127 205.74)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "3a0787fd-12b3-427c-85e6-58772838277c")
	)
	(junction
		(at 48.26 60.96)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "3da48c44-8a5f-4147-8d4a-764e537c442b")
	)
	(junction
		(at 210.82 284.48)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "40c16269-bade-45b1-934d-f206eee2b2f1")
	)
	(junction
		(at 180.34 170.18)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "41bbf78f-34e6-4bf3-a02c-caca5b666645")
	)
	(junction
		(at 60.96 147.32)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "445884c7-74d2-4004-9ec1-d7478e3f170e")
	)
	(junction
		(at 162.56 68.58)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "4539837c-3d3f-4171-8dc5-81538171f401")
	)
	(junction
		(at 71.12 330.2)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "4647f103-06d7-4df2-935b-45f63f7fb3c1")
	)
	(junction
		(at 40.64 355.6)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "48b9ae64-df52-4b50-ba15-e264c00753ce")
	)
	(junction
		(at 40.64 66.04)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "491c51a5-3ff1-4858-9861-8f22035a6d82")
	)
	(junction
		(at 38.1 220.98)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "493c998c-83f5-4d01-bc7a-bb81d5e93f4c")
	)
	(junction
		(at 96.52 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "4d8ec2f1-2cba-4b7c-8a04-5a5178080fe3")
	)
	(junction
		(at 373.38 355.6)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "4ded35c8-f03f-4d2a-9112-0c2676ce7a2a")
	)
	(junction
		(at 30.48 337.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "4e809bf9-ace9-42c1-989d-90d208f813c6")
	)
	(junction
		(at 73.66 45.72)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "4ee8cca5-e587-417d-bb8d-1ae23f62000b")
	)
	(junction
		(at 213.36 46.99)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "5573fa39-dcea-4aff-8b9e-0e997707d08c")
	)
	(junction
		(at 93.98 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "564d2b86-8774-47b1-8cc9-d9db2912fc11")
	)
	(junction
		(at 88.9 213.36)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "57a48f01-981e-4b77-9b2b-25389ab8dcc4")
	)
	(junction
		(at 182.88 73.66)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "57ecc53e-bccf-45d7-accb-259fbc571d41")
	)
	(junction
		(at 40.64 83.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "5a4fd7d8-5a10-42c6-9f7b-80f2c4d9cbd1")
	)
	(junction
		(at 233.68 78.74)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "5be4a343-cf02-44e7-a4a5-b9f5979dbda7")
	)
	(junction
		(at 78.74 45.72)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "5f066d1d-efdd-44c7-804a-78e3090d29c6")
	)
	(junction
		(at 144.78 355.6)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "62c8bd02-1ab0-4953-b7ff-28d6e724dc69")
	)
	(junction
		(at 378.46 193.04)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6405251e-126d-4e23-a647-a5087897060a")
	)
	(junction
		(at 144.78 337.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6554cc31-a1b9-40ca-ab61-ccd0d7ab4005")
	)
	(junction
		(at 388.62 167.64)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "66828aa7-3d89-449f-88d9-d671bd159ab4")
	)
	(junction
		(at 106.68 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "67efe43f-0e04-41ec-a426-1aa55c8ee0f1")
	)
	(junction
		(at 322.58 340.36)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6804defb-5288-472c-bf44-ab9aee3a7349")
	)
	(junction
		(at 73.66 360.68)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6b67f931-ea7d-4c0c-b0c5-e21ec88d8a96")
	)
	(junction
		(at 220.98 78.74)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6cd6b3f8-423d-4ea8-a020-6ee7726eee4d")
	)
	(junction
		(at 299.72 187.96)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6d883f7d-394d-4e85-bcaa-5d6d81d72f91")
	)
	(junction
		(at 335.28 266.7)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6e287363-f6e1-437f-b181-6b555e29e236")
	)
	(junction
		(at 332.74 274.32)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "6eb60dcf-216a-4e96-accd-3b6a06fa6015")
	)
	(junction
		(at 287.02 53.34)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7243a7c9-f21e-4004-ab9c-4fae98c84a8c")
	)
	(junction
		(at 368.3 251.46)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "727b6434-7b20-47c9-9050-a45ff8a31ad6")
	)
	(junction
		(at 33.02 147.32)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "739f4965-592d-4e3b-90ee-dd1500543888")
	)
	(junction
		(at 33.02 162.56)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "79748997-6601-4fdd-9659-4a7d27b5bec4")
	)
	(junction
		(at 276.86 251.46)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7a5998a6-3650-4356-aa4c-04aeee862396")
	)
	(junction
		(at 35.56 246.38)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7a996767-9f66-405e-9b92-8d15ddee3888")
	)
	(junction
		(at 60.96 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7af747db-99be-450c-b84c-7e76cd6819ec")
	)
	(junction
		(at 149.86 347.98)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7c25decf-7ad7-4ea2-bc0f-17f413701674")
	)
	(junction
		(at 353.06 353.06)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7d5dbc87-de41-46bd-8ffa-5bcaa97b4262")
	)
	(junction
		(at 403.86 251.46)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7e7f691d-5692-4400-8f91-cfb53b97059d")
	)
	(junction
		(at 86.36 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7ea788f0-4353-4de8-9ada-825f9ade6343")
	)
	(junction
		(at 91.44 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7eb21053-8c59-414a-aea2-0ab14e393b06")
	)
	(junction
		(at 200.66 46.99)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "7eead7ef-db42-4801-9756-7fd5a8c74f50")
	)
	(junction
		(at 182.88 78.74)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "80a06622-8966-43e5-82ce-0ff81a122b8f")
	)
	(junction
		(at 287.02 50.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "83628a07-374c-4a50-8e0c-0704ddbb5dd3")
	)
	(junction
		(at 40.64 363.22)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "86308b1b-befb-4fc6-8487-d6bb93d5cb83")
	)
	(junction
		(at 60.96 246.38)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "87244423-75aa-4c8a-ae34-6f885507e358")
	)
	(junction
		(at 99.06 355.6)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "93127f8b-14dc-41cb-a15d-9a2d2149fee0")
	)
	(junction
		(at 274.32 269.24)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "94a84af7-52cc-4ead-9d94-ab3c5c2e8e99")
	)
	(junction
		(at 162.56 73.66)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "97ef2fcd-dcdc-4842-be7d-1dde6a26e771")
	)
	(junction
		(at 294.64 368.3)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "9b6bdfee-c055-408d-b2d8-07654b5817ff")
	)
	(junction
		(at 187.96 78.74)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a26b5d42-220f-453d-a65a-7b7de2b782fa")
	)
	(junction
		(at 101.6 213.36)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a55abc34-e2a3-4bdc-bc0a-472a2bfebbae")
	)
	(junction
		(at 180.34 391.16)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a8375341-ee5a-48ac-8c2f-a1287ecc556d")
	)
	(junction
		(at 309.88 347.98)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "a897f7a3-ea1b-41cd-9553-c47f51030a24")
	)
	(junction
		(at 358.14 248.92)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "aac0b694-3d0f-45f7-874d-08c3051baead")
	)
	(junction
		(at 198.12 190.5)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "abf22fb6-0045-4cf1-9c7b-6ed2e475a168")
	)
	(junction
		(at 121.92 165.1)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "aced1cf3-eafb-416a-9d78-afc4e12d3a41")
	)
	(junction
		(at 104.14 337.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ae3c86ae-bc7e-4900-a0ef-d800609785bc")
	)
	(junction
		(at 520.7 160.02)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "af6be0fb-e289-4e4e-bc41-e5de70f7b766")
	)
	(junction
		(at 30.48 363.22)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "afa50c5e-9a05-4d85-8e88-4666953bb1d7")
	)
	(junction
		(at 167.64 241.3)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "afbffb7d-c742-40e5-9e13-0e06173ef765")
	)
	(junction
		(at 287.02 350.52)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b0781be6-ca2e-4bdb-accc-29cfe4c2776c")
	)
	(junction
		(at 81.28 193.04)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b1595df4-fa6e-475b-813b-d5654bb2140b")
	)
	(junction
		(at 175.26 45.72)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b5050e21-a557-4e4b-8b69-ef93be98e1f3")
	)
	(junction
		(at 111.76 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b6231bac-f325-4e38-9342-a0d6abdddb6c")
	)
	(junction
		(at 391.16 48.26)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b7fae8b9-01af-4467-88eb-020897fe28ec")
	)
	(junction
		(at 40.64 220.98)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b8be2db2-96b3-4c4a-bc31-7c1cc18232fb")
	)
	(junction
		(at 93.98 195.58)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "b98d0dfa-e03a-45b2-99ae-5fab9f9d428c")
	)
	(junction
		(at 119.38 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "bd7c08ee-b705-48c1-8675-b70a96441ec7")
	)
	(junction
		(at 274.32 251.46)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "be481612-5e48-4b44-bd0d-37b321d7dd22")
	)
	(junction
		(at 358.14 241.3)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "bf6fda2f-6c33-4143-a754-5b66c73193bf")
	)
	(junction
		(at 111.76 73.66)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "c032ff69-eb01-4e24-aceb-f9806f9261b0")
	)
	(junction
		(at 101.6 45.72)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "c14fafa0-35f7-44bc-ba17-8a0cb9064357")
	)
	(junction
		(at 530.86 203.2)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "c24f56d2-dc98-4318-a379-58d74b2490d9")
	)
	(junction
		(at 101.6 330.2)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "c4722346-d89e-4a22-8092-58ff77663b88")
	)
	(junction
		(at 520.7 259.08)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "c4e97fec-131d-406c-880b-6e98dac2a80d")
	)
	(junction
		(at 175.26 73.66)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "cb686e3e-42b2-4907-8ffe-7305abd6cd0b")
	)
	(junction
		(at 182.88 218.44)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "cbb7a659-f4be-4d88-b808-1cf2b2b74d05")
	)
	(junction
		(at 358.14 243.84)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ce552a32-22ca-4542-84f1-8dfbb894242b")
	)
	(junction
		(at 284.48 68.58)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "d073d4e6-3ea1-4f1b-88bb-e390e763e356")
	)
	(junction
		(at 96.52 210.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "d20ed040-12e9-48d2-a1d6-7bc5b05bce3f")
	)
	(junction
		(at 388.62 187.96)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "d6d3bf00-cafd-458b-859f-89b74c66f34a")
	)
	(junction
		(at 48.26 53.34)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "d9e22103-ae66-4bee-aef5-a0b7d8c9b466")
	)
	(junction
		(at 101.6 177.8)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "db7d07b8-02e6-45b9-b895-5b5c52e70423")
	)
	(junction
		(at 88.9 45.72)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "dd1703da-48ba-4193-9209-1ed44fdfcfc3")
	)
	(junction
		(at 91.44 208.28)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "de1123ed-f0e6-4782-a01d-3d6df875ba64")
	)
	(junction
		(at 226.06 78.74)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "de4110ec-29ca-4260-be11-c1eba13a276a")
	)
	(junction
		(at 330.2 269.24)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "de7464d0-e022-4989-b3fa-edd8bae99a86")
	)
	(junction
		(at 287.02 375.92)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "e2f748a6-68a2-4735-abb7-3dea9ba37b52")
	)
	(junction
		(at 81.28 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "e9f4df61-16ce-4e1d-b1c8-f277924e27ac")
	)
	(junction
		(at 167.64 335.28)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "eccfa890-2080-43e4-9c5c-0b3b54de2d03")
	)
	(junction
		(at 220.98 213.36)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "edfba568-0797-48d9-aa9a-095225a076fc")
	)
	(junction
		(at 182.88 210.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ee39b467-8c30-4869-bb10-3ae56829f697")
	)
	(junction
		(at 284.48 76.2)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ef28b69b-dc64-4699-9af2-c06e9803fa9e")
	)
	(junction
		(at 203.2 284.48)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ef7d0726-311a-4643-9781-7620d7241ec2")
	)
	(junction
		(at 198.12 203.2)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f0fe4b0a-2f9a-4b04-8944-cd9bec50b6ce")
	)
	(junction
		(at 83.82 45.72)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f1c7d024-7972-4e18-b7c4-28027b177922")
	)
	(junction
		(at 332.74 251.46)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f2b3df96-b526-48e8-a2ae-e297ea877ab1")
	)
	(junction
		(at 96.52 190.5)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f37337cc-1d20-4547-82bb-d11d602b5235")
	)
	(junction
		(at 81.28 210.82)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f3ffcda5-3554-4e75-9ee9-ce056aaca2a4")
	)
	(junction
		(at 66.04 154.94)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f5acf8d7-9a95-4bbc-a71a-3adc43053333")
	)
	(junction
		(at 25.4 147.32)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f66a976c-a6a0-4caa-8a2c-9e74ce2e64da")
	)
	(junction
		(at 358.14 259.08)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "f7a7ac71-0d18-4730-8418-bed4957350a3")
	)
	(junction
		(at 167.64 243.84)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "fa6f985e-b08c-49a3-b33e-ad5130980811")
	)
	(junction
		(at 99.06 360.68)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "fdf07c5f-278c-4389-ae6b-96c0c20a0306")
	)
	(junction
		(at 81.28 147.32)
		(diameter 0)
		(color 0 0 0 0)
		(uuid "ff235fdb-d975-42af-8587-1caac10ad225")
	)
	(no_connect
		(at 38.1 353.06)
		(uuid "2b8a21bb-7348-433f-8d8e-345056bb1420")
	)
	(no_connect
		(at 132.08 353.06)
		(uuid "31269fc3-e6c0-4cef-a5dc-738f461c677d")
	)
	(no_connect
		(at 132.08 345.44)
		(uuid "467da409-7324-4cfc-bc6e-3f0e66eab746")
	)
	(no_connect
		(at 132.08 355.6)
		(uuid "6e2f6389-1193-4683-84a4-94c29da05ab2")
	)
	(no_connect
		(at 177.8 177.8)
		(uuid "7ccad762-bf60-48b1-a024-8e9d3be4c000")
	)
	(no_connect
		(at 147.32 185.42)
		(uuid "7f3ddea4-0586-4e4f-b428-9b657df17624")
	)
	(no_connect
		(at 177.8 198.12)
		(uuid "9caa18de-4a36-4521-ac4a-0773879168e6")
	)
	(no_connect
		(at 132.08 358.14)
		(uuid "ac44d42e-a238-47d7-98e0-50fd022658e6")
	)
	(no_connect
		(at 132.08 350.52)
		(uuid "b1aad560-a2a1-4480-af75-9ad56eaf540c")
	)
	(no_connect
		(at 177.8 162.56)
		(uuid "db699d1e-3924-415a-a1c7-16e861477a5c")
	)
	(no_connect
		(at 177.8 160.02)
		(uuid "f7f41027-5d52-4a1f-b6f2-f706e2b0847a")
	)
	(no_connect
		(at 132.08 360.68)
		(uuid "f8c23e7b-5c25-4521-9bda-8ca5b560dbb3")
	)
	(wire
		(pts
			(xy 523.24 63.5) (xy 556.26 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "006cecba-8db4-45c5-965c-1f01dc1a654e")
	)
	(wire
		(pts
			(xy 175.26 54.61) (xy 175.26 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "008cef43-0542-408f-93e5-24497148daf7")
	)
	(wire
		(pts
			(xy 299.72 251.46) (xy 299.72 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "00951c5c-a767-4dbd-8740-f8fa90580355")
	)
	(wire
		(pts
			(xy 375.92 251.46) (xy 403.86 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0166cc3d-459d-44c5-88da-49abe587aff8")
	)
	(wire
		(pts
			(xy 297.18 271.78) (xy 337.82 271.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "018d8ba5-ddfa-4899-b439-47a93c5d6ee4")
	)
	(wire
		(pts
			(xy 182.88 210.82) (xy 182.88 218.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "020b8578-5705-4d94-b807-682644edf73a")
	)
	(wire
		(pts
			(xy 223.52 193.04) (xy 208.28 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "021efe90-2769-483a-bedc-c2c9bedd68f1")
	)
	(wire
		(pts
			(xy 510.54 63.5) (xy 474.98 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "02ab7e2c-92aa-4d47-b885-a96f062ceb88")
	)
	(wire
		(pts
			(xy 180.34 370.84) (xy 185.42 370.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "02aefe57-6949-480a-b1bc-056389d3c163")
	)
	(wire
		(pts
			(xy 25.4 172.72) (xy 25.4 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "031d00fa-86ac-49c8-8ddf-7675c0a96923")
	)
	(wire
		(pts
			(xy 523.24 81.28) (xy 556.26 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "033da4fd-3dce-41c8-81a8-045e85a5bb26")
	)
	(wire
		(pts
			(xy 510.54 76.2) (xy 474.98 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "034e11f8-4fd0-423b-b135-1b4bf9e40d91")
	)
	(wire
		(pts
			(xy 139.7 66.04) (xy 144.78 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "03b4b916-d63b-465c-990a-aeda70f9a553")
	)
	(wire
		(pts
			(xy 40.64 355.6) (xy 38.1 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "03b9918a-aa46-40d4-b840-e2c4fd54c946")
	)
	(polyline
		(pts
			(xy 465.455 386.08) (xy 424.18 386.08)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "03df4ba8-ee86-445c-bb79-de575780dc91")
	)
	(wire
		(pts
			(xy 60.96 165.1) (xy 60.96 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "04179542-63a0-4f0b-8663-b6ec74395dc7")
	)
	(wire
		(pts
			(xy 182.88 210.82) (xy 193.04 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0451178c-693b-473c-91fe-8d855e62ff22")
	)
	(wire
		(pts
			(xy 96.52 170.18) (xy 96.52 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0455460f-fa15-4d94-bdfa-2b233349fa59")
	)
	(wire
		(pts
			(xy 142.24 251.46) (xy 154.94 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0495fbda-183c-4efb-b0ff-3fc113f1b936")
	)
	(wire
		(pts
			(xy 121.92 165.1) (xy 147.32 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "04b0c005-9ff1-45b8-aa61-fb080ac786b7")
	)
	(wire
		(pts
			(xy 40.64 220.98) (xy 43.18 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "04ca8acb-bfb6-4a5e-bd4f-1caa54c44b10")
	)
	(wire
		(pts
			(xy 81.28 170.18) (xy 81.28 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "04cc86bd-9548-418b-a3b8-9ce35aa4f11e")
	)
	(wire
		(pts
			(xy 386.08 50.8) (xy 424.18 50.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "05222c72-5766-40b9-9df3-878c915840f2")
	)
	(wire
		(pts
			(xy 177.8 167.64) (xy 182.88 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "057d1c9b-03f9-4a76-8850-51cdd532e445")
	)
	(wire
		(pts
			(xy 190.5 243.84) (xy 167.64 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "059b4789-7eb9-4c9d-9178-6dd145a6ed0b")
	)
	(wire
		(pts
			(xy 287.02 350.52) (xy 287.02 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "05f4b86b-c413-4557-a2c2-1519003b4ec3")
	)
	(wire
		(pts
			(xy 279.4 363.22) (xy 279.4 350.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "060ac742-3f52-4993-bc45-b2420bb8b436")
	)
	(wire
		(pts
			(xy 411.48 251.46) (xy 429.26 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "06c3c86c-24dc-431b-b527-6ac99509caa2")
	)
	(wire
		(pts
			(xy 218.44 78.74) (xy 220.98 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0709b0af-1737-44bf-a41d-3a1bade5d4eb")
	)
	(wire
		(pts
			(xy 373.38 368.3) (xy 373.38 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "079023da-29f5-4b4e-a99c-1ecfca3e1f48")
	)
	(wire
		(pts
			(xy 530.86 200.66) (xy 530.86 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "07bf3ee8-70b6-4776-8254-91c1ca7c3da3")
	)
	(wire
		(pts
			(xy 101.6 335.28) (xy 106.68 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "07ddaa1b-be9c-4c9c-839a-338bb2ef7782")
	)
	(wire
		(pts
			(xy 505.46 198.12) (xy 477.52 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0892a17f-ffe7-419e-8c76-7be0d28debd1")
	)
	(wire
		(pts
			(xy 177.8 152.4) (xy 220.98 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "08baed39-e742-4b7c-84ad-853a209e9318")
	)
	(wire
		(pts
			(xy 91.44 170.18) (xy 91.44 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "09421fca-0cda-4182-9820-7413552cb647")
	)
	(wire
		(pts
			(xy 177.8 203.2) (xy 198.12 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "094dff6c-30fb-4fbf-b329-95749f963d60")
	)
	(wire
		(pts
			(xy 287.02 50.8) (xy 287.02 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "096be91e-0787-42ed-8dcb-78feab0e5b70")
	)
	(polyline
		(pts
			(xy 449.58 116.84) (xy 574.04 116.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "0a9439bc-66d6-4212-852e-5a5c213663dc")
	)
	(polyline
		(pts
			(xy 424.18 299.72) (xy 465.455 299.72)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "0ac09402-50e4-40c5-be3a-dcdc36665c7b")
	)
	(wire
		(pts
			(xy 198.12 264.16) (xy 190.5 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0ac5da32-654d-4cd6-affa-0121494e12c2")
	)
	(wire
		(pts
			(xy 233.68 73.66) (xy 233.68 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0aca1613-c808-4471-867c-324593d70c95")
	)
	(wire
		(pts
			(xy 30.48 340.36) (xy 30.48 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0afa3789-e438-4e77-9d13-98682b43d6f7")
	)
	(wire
		(pts
			(xy 279.4 350.52) (xy 287.02 350.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0b0b3090-e939-4fc4-9e6e-f76e9a6bdc79")
	)
	(wire
		(pts
			(xy 27.94 340.36) (xy 27.94 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0bf15be0-e5fb-463c-abdc-b1d35cad7631")
	)
	(wire
		(pts
			(xy 45.72 147.32) (xy 60.96 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0c147b6a-3582-456c-9d6e-31268259bc62")
	)
	(wire
		(pts
			(xy 378.46 248.92) (xy 403.86 248.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0cd94c65-6e8a-49a3-8073-bee3416c215b")
	)
	(wire
		(pts
			(xy 408.94 241.3) (xy 378.46 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0d23e2ca-8bb8-4c92-a801-8e3ae545933c")
	)
	(wire
		(pts
			(xy 81.28 147.32) (xy 119.38 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0d7ad619-153f-4f06-b898-236756a6aeac")
	)
	(wire
		(pts
			(xy 213.36 33.02) (xy 213.36 46.99)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0d7f91bc-cf3c-4143-aab9-f9d121d58ba0")
	)
	(wire
		(pts
			(xy 279.4 340.36) (xy 322.58 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0d8974b8-2e08-4f49-be9e-dc5f5c7b4733")
	)
	(polyline
		(pts
			(xy 574.04 17.78) (xy 449.58 17.78)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "0e2652bc-557c-49b5-b785-3079bbafde8b")
	)
	(polyline
		(pts
			(xy 523.367 299.466) (xy 523.367 324.866)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "0e26d6b6-90a6-4947-888e-cf8b2c3f5df7")
	)
	(wire
		(pts
			(xy 335.28 266.7) (xy 337.82 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0e7c6e2f-0f7c-4879-ab9c-580fa0054d27")
	)
	(wire
		(pts
			(xy 43.18 220.98) (xy 43.18 223.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0e8f9d92-e67c-4daf-accf-6f6e76eff1b7")
	)
	(wire
		(pts
			(xy 523.24 73.66) (xy 556.26 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0f82e45c-ff06-4547-9632-956dd448823e")
	)
	(polyline
		(pts
			(xy 482.6 299.72) (xy 482.6 325.12)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "0f872039-c2e0-485c-ae95-01725d829a4e")
	)
	(wire
		(pts
			(xy 180.34 391.16) (xy 180.34 370.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0f88a596-85ba-4c5f-90a9-663c8480c0c4")
	)
	(wire
		(pts
			(xy 525.78 200.66) (xy 525.78 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "0fd86ba0-752b-4ff5-8bf3-7e5d548ca32c")
	)
	(polyline
		(pts
			(xy 350.52 284.48) (xy 449.58 284.48)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "10323646-64e0-4ffc-acfd-00148de1ae98")
	)
	(wire
		(pts
			(xy 353.06 340.36) (xy 353.06 353.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1074df80-a150-44f8-bcd9-dd8f1a6410d5")
	)
	(wire
		(pts
			(xy 38.1 347.98) (xy 106.68 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1079c69d-3c49-4cca-951b-01c97d820a99")
	)
	(wire
		(pts
			(xy 378.46 172.72) (xy 378.46 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "10f7667a-557c-472f-a76f-21a87fc07e9a")
	)
	(wire
		(pts
			(xy 525.78 195.58) (xy 525.78 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "11454296-be26-4aca-852b-9c045b8c1617")
	)
	(wire
		(pts
			(xy 220.98 165.1) (xy 220.98 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1169a0a3-3e46-4d76-8c1e-bdf4693b6ab0")
	)
	(wire
		(pts
			(xy 187.96 81.28) (xy 187.96 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1243a27a-8707-498d-9eeb-06f80527d048")
	)
	(wire
		(pts
			(xy 58.42 93.98) (xy 58.42 91.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1280ff16-9b56-49f2-a2dc-99a80864b68b")
	)
	(wire
		(pts
			(xy 78.74 154.94) (xy 81.28 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1282ef5e-3361-4e96-a5a0-ade84b320231")
	)
	(wire
		(pts
			(xy 510.54 58.42) (xy 474.98 58.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "146005b6-fde5-4fa2-97a8-26ca3ba0f167")
	)
	(polyline
		(pts
			(xy 482.727 334.645) (xy 541.782 334.645)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "1487b176-62a4-471c-8938-5c226e1cc42b")
	)
	(wire
		(pts
			(xy 200.66 49.53) (xy 200.66 46.99)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1520abc7-3f43-4f77-90f3-bee3a063a72e")
	)
	(wire
		(pts
			(xy 38.1 345.44) (xy 71.12 345.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "15cb6255-d69e-49d7-8854-812942dcd79a")
	)
	(wire
		(pts
			(xy 530.86 170.18) (xy 530.86 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "15d04e42-069c-455a-89e3-0a0b20cc9500")
	)
	(wire
		(pts
			(xy 38.1 220.98) (xy 40.64 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "16846006-077f-4a95-bcb4-9fadd23fc173")
	)
	(wire
		(pts
			(xy 330.2 254) (xy 330.2 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "16984672-77e7-4ede-8e2d-9a43a06761fa")
	)
	(wire
		(pts
			(xy 73.66 360.68) (xy 73.66 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "16cecbec-cb4c-45cf-ab55-425b819cf962")
	)
	(wire
		(pts
			(xy 363.22 198.12) (xy 363.22 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "17076e72-a381-40e8-b605-fdfede1d9ddc")
	)
	(wire
		(pts
			(xy 373.38 198.12) (xy 378.46 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "17218795-b5da-494a-a85b-7ae2f77cf312")
	)
	(wire
		(pts
			(xy 391.16 40.64) (xy 391.16 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "172fc072-43b1-48ac-a35b-b77894c2767e")
	)
	(wire
		(pts
			(xy 345.44 353.06) (xy 353.06 353.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "18077883-e71e-4396-a1e8-018e68617c58")
	)
	(wire
		(pts
			(xy 365.76 198.12) (xy 363.22 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "18590fd6-292d-4fdd-8abe-5c4dfa35fe91")
	)
	(wire
		(pts
			(xy 210.82 284.48) (xy 210.82 287.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "185defd5-75f8-4811-bf8e-0819e073253f")
	)
	(wire
		(pts
			(xy 40.64 337.82) (xy 40.64 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "18dfba98-98a4-459e-a21f-353be2175ce3")
	)
	(wire
		(pts
			(xy 259.08 269.24) (xy 274.32 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "19676ed4-7be0-46ea-8e0e-6d66e4569fbb")
	)
	(wire
		(pts
			(xy 91.44 210.82) (xy 96.52 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1a27ece4-62d1-495f-a3b8-e6d9c830dbf8")
	)
	(wire
		(pts
			(xy 177.8 208.28) (xy 182.88 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1a63a003-e280-4abd-8d83-fe4faf8963cd")
	)
	(polyline
		(pts
			(xy 518.16 325.12) (xy 518.16 299.72)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "1a87b736-c697-489b-8563-bc22c90832a7")
	)
	(wire
		(pts
			(xy 386.08 127) (xy 424.18 127)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1c037d98-c0b1-487b-8c0d-4ed613b80ea2")
	)
	(wire
		(pts
			(xy 403.86 40.64) (xy 408.94 40.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1d48f628-ce75-48ec-8ec0-f041aba09fc4")
	)
	(wire
		(pts
			(xy 220.98 78.74) (xy 226.06 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1d99ffc8-f41d-4f49-a603-fba2fefa54ab")
	)
	(polyline
		(pts
			(xy 17.78 17.78) (xy 17.78 114.3)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "1e673fa1-4e8d-41ea-8167-7abd576d7df2")
	)
	(wire
		(pts
			(xy 162.56 68.58) (xy 170.18 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "1f67f90e-96d0-442d-9fc2-b065ed57dc38")
	)
	(wire
		(pts
			(xy 198.12 218.44) (xy 182.88 218.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "200db327-c320-4e09-92c0-d5afcb8dfd90")
	)
	(wire
		(pts
			(xy 406.4 243.84) (xy 406.4 248.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2015f3ca-8251-4fd5-9113-e9a12a033a6e")
	)
	(polyline
		(pts
			(xy 482.727 340.36) (xy 541.782 340.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "2024813f-4e89-40aa-a4db-a716b70c246d")
	)
	(wire
		(pts
			(xy 510.54 81.28) (xy 474.98 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "20b0bd9a-663b-43cd-a615-6dcc5b7d99ff")
	)
	(wire
		(pts
			(xy 386.08 81.28) (xy 424.18 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "20db54b7-cdbd-4ada-a07a-7c427b6d5d31")
	)
	(wire
		(pts
			(xy 500.38 200.66) (xy 500.38 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "211b07d9-3464-465b-95e5-225314aedd72")
	)
	(wire
		(pts
			(xy 330.2 172.72) (xy 322.58 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2149d25c-33b6-4c63-b164-5640a1a42bce")
	)
	(polyline
		(pts
			(xy 574.04 116.84) (xy 574.04 17.78)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "218a843d-88f8-4468-a1fe-21bc15e92ebc")
	)
	(polyline
		(pts
			(xy 550.037 304.546) (xy 550.037 324.866)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "21b900cc-f76d-44c6-85f2-a004f6886e2a")
	)
	(wire
		(pts
			(xy 101.6 322.58) (xy 115.57 322.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "21f13a34-70b6-461f-b565-041fa2710f7f")
	)
	(wire
		(pts
			(xy 220.98 154.94) (xy 220.98 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "21f1ee6c-1d0e-4191-a88e-ecfbe65180e0")
	)
	(wire
		(pts
			(xy 127 66.04) (xy 132.08 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "222a39ed-1523-45e4-b168-748b400eec8e")
	)
	(wire
		(pts
			(xy 111.76 160.02) (xy 111.76 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "22fa15e8-4b2d-4dcc-8d8f-fa9769ece21b")
	)
	(wire
		(pts
			(xy 274.32 368.3) (xy 274.32 381)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "23257c86-dafb-4473-9344-8df234024aab")
	)
	(wire
		(pts
			(xy 60.96 137.16) (xy 60.96 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "233864ae-279a-44c4-bb69-a2af8822477a")
	)
	(wire
		(pts
			(xy 429.26 246.38) (xy 408.94 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "233e4e86-fdb6-4f83-ac41-1ceb0726706f")
	)
	(wire
		(pts
			(xy 149.86 347.98) (xy 152.4 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "234b1533-68c6-4d64-8227-a81b2900d683")
	)
	(wire
		(pts
			(xy 220.98 152.4) (xy 223.52 152.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "23c0d65b-7785-4ddd-baac-919a21cffb81")
	)
	(wire
		(pts
			(xy 520.7 264.16) (xy 520.7 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "23d463fd-0101-48f4-a37e-39fc25ff8561")
	)
	(wire
		(pts
			(xy 190.5 398.78) (xy 220.98 398.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "23f707c5-9703-4ee2-82c6-3ee0802f2009")
	)
	(wire
		(pts
			(xy 182.88 167.64) (xy 233.68 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "243bd582-0624-4d9d-b503-3f4724a082d7")
	)
	(wire
		(pts
			(xy 38.1 264.16) (xy 35.56 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "244debfd-8b28-4b8e-a590-ceb5c56ec6bc")
	)
	(wire
		(pts
			(xy 167.64 327.66) (xy 167.64 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2477374b-1e3b-44f4-904c-e913c48323a2")
	)
	(wire
		(pts
			(xy 358.14 259.08) (xy 368.3 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "24a3c178-add6-4cb4-b750-0181c75f52fc")
	)
	(wire
		(pts
			(xy 27.94 167.64) (xy 25.4 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "251b2f36-f80c-406d-8de3-417b109e74cd")
	)
	(wire
		(pts
			(xy 358.14 243.84) (xy 363.22 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2547547f-be80-4a54-bc25-032135432495")
	)
	(wire
		(pts
			(xy 294.64 375.92) (xy 304.8 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "25543657-af29-45f4-b17c-857aae233750")
	)
	(wire
		(pts
			(xy 38.1 218.44) (xy 38.1 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "26261518-5cb6-427b-a280-f1287fa84656")
	)
	(wire
		(pts
			(xy 332.74 246.38) (xy 332.74 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "26423df2-0b96-4434-81ac-08ce94048ed0")
	)
	(wire
		(pts
			(xy 182.88 340.36) (xy 220.98 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "269afeb8-ea87-4d15-a273-2e7003c0d4ac")
	)
	(wire
		(pts
			(xy 68.58 73.66) (xy 68.58 93.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "26a5fed2-ee32-4da3-8aa9-632227a01707")
	)
	(wire
		(pts
			(xy 510.54 73.66) (xy 474.98 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "26d16e3a-c906-43e4-ae03-c9a703971f76")
	)
	(wire
		(pts
			(xy 274.32 233.68) (xy 274.32 231.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "27a25ddd-7fe5-44e6-aee6-c5edc9dbae05")
	)
	(wire
		(pts
			(xy 419.1 172.72) (xy 411.48 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "27f6fc47-5329-4fbd-9705-4e4201e96ffc")
	)
	(wire
		(pts
			(xy 121.92 177.8) (xy 147.32 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2893a6a6-227a-4d0f-a1a8-8c1c73b73fe4")
	)
	(wire
		(pts
			(xy 116.84 177.8) (xy 121.92 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "28f44e55-1c6a-431a-bcaf-b01fe08314de")
	)
	(wire
		(pts
			(xy 71.12 213.36) (xy 88.9 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "29034f93-01c3-4baa-9a52-e75e03783707")
	)
	(wire
		(pts
			(xy 287.02 360.68) (xy 287.02 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "291b6829-c3ec-433e-9128-2dc1c8640292")
	)
	(wire
		(pts
			(xy 386.08 48.26) (xy 391.16 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "29b85bce-fcfb-44d6-bb82-48903e265f72")
	)
	(polyline
		(pts
			(xy 342.9 220.98) (xy 254 220.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "2a3d05d9-2016-48a4-91bc-264e3475a511")
	)
	(wire
		(pts
			(xy 88.9 335.28) (xy 101.6 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2aaa69ab-32be-4cd7-bd4e-afdb790ac785")
	)
	(wire
		(pts
			(xy 467.36 259.08) (xy 472.44 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2adb8b04-57ac-474b-a243-dd3d0dfc0c57")
	)
	(wire
		(pts
			(xy 386.08 71.12) (xy 411.48 71.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2b09b774-1a11-4a90-80ab-d73cc874322c")
	)
	(wire
		(pts
			(xy 116.84 165.1) (xy 121.92 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2bc5edad-a012-4d0c-819c-e2bab922ca5c")
	)
	(wire
		(pts
			(xy 274.32 246.38) (xy 274.32 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2c4b93ef-f036-4012-bc33-5e4d59bb72b5")
	)
	(polyline
		(pts
			(xy 518.16 299.72) (xy 482.6 299.72)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "2c951289-99a4-4b0a-a0aa-9a05b986933e")
	)
	(wire
		(pts
			(xy 233.68 86.36) (xy 233.68 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2cac20c7-e2c8-47fd-a2a4-7f0240bc4adb")
	)
	(wire
		(pts
			(xy 386.08 55.88) (xy 424.18 55.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2d308d43-5019-46f0-a01e-ff62d513b50d")
	)
	(wire
		(pts
			(xy 38.1 142.24) (xy 25.4 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2d69c84d-ef59-45d9-a315-219fe50d1bc7")
	)
	(wire
		(pts
			(xy 386.08 58.42) (xy 424.18 58.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2e95be69-8d68-486e-bc9b-a5b65371d611")
	)
	(wire
		(pts
			(xy 177.8 147.32) (xy 233.68 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2eadb950-c93e-4e05-94f3-cdeb64ace843")
	)
	(wire
		(pts
			(xy 121.92 167.64) (xy 121.92 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2eaf6cc1-5c49-449e-8529-edf8d9bf87a8")
	)
	(wire
		(pts
			(xy 388.62 203.2) (xy 388.62 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2f39bc8d-1faa-4e88-aec4-e7a2664bb08b")
	)
	(wire
		(pts
			(xy 88.9 337.82) (xy 104.14 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "2f52488a-d3be-45d9-b3cf-d96da540cd31")
	)
	(wire
		(pts
			(xy 198.12 210.82) (xy 220.98 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "30541531-cfd2-46e2-ad43-02b740c9ed6d")
	)
	(wire
		(pts
			(xy 276.86 198.12) (xy 274.32 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "30c50ff7-418b-469f-b211-d5ce883a087e")
	)
	(wire
		(pts
			(xy 101.6 330.2) (xy 101.6 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "324afdaf-4cf6-44a0-88cb-4c9d5e043880")
	)
	(wire
		(pts
			(xy 327.66 332.74) (xy 353.06 332.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3263c692-bc7d-4ccc-bd03-ee46ad0bbe0c")
	)
	(wire
		(pts
			(xy 73.66 45.72) (xy 73.66 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "32686c03-8e14-46ff-bd31-0d78120e3d0c")
	)
	(wire
		(pts
			(xy 119.38 154.94) (xy 119.38 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "32d20fb2-1212-477a-99e8-103d0beba276")
	)
	(wire
		(pts
			(xy 93.98 208.28) (xy 132.08 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "339bbc7a-ea51-4c2e-a8c9-03a5d4eee705")
	)
	(wire
		(pts
			(xy 561.34 259.08) (xy 561.34 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "33a815b4-e7e8-4134-8894-8086f3747d4a")
	)
	(wire
		(pts
			(xy 60.96 147.32) (xy 60.96 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "340aecf2-e617-45a6-b40d-85d141a71027")
	)
	(wire
		(pts
			(xy 284.48 68.58) (xy 284.48 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "34f7b32a-f2d4-4653-bd65-923964430a03")
	)
	(wire
		(pts
			(xy 276.86 251.46) (xy 284.48 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "352ba437-ded8-4c2e-9fd9-51e55a96ee2b")
	)
	(wire
		(pts
			(xy 66.04 259.08) (xy 58.42 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3599fc99-35b0-4704-b5b4-8b0f1983bf79")
	)
	(wire
		(pts
			(xy 170.18 340.36) (xy 177.8 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "35b7960c-10e4-43dd-8ef7-644cf3550a69")
	)
	(wire
		(pts
			(xy 304.8 368.3) (xy 294.64 368.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "35f4b8d5-06a3-45fa-bf2e-6b0395a7aacd")
	)
	(wire
		(pts
			(xy 170.18 360.68) (xy 170.18 358.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "367e7872-f55e-4cfa-92bb-818b1b6ae9be")
	)
	(wire
		(pts
			(xy 111.76 160.02) (xy 119.38 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "36871f2b-d29b-411e-b406-fca43288ce2d")
	)
	(wire
		(pts
			(xy 205.74 83.82) (xy 208.28 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "36cb4c06-9a0c-4d95-94ea-e772f0391fa1")
	)
	(polyline
		(pts
			(xy 436.88 213.36) (xy 436.88 149.86)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "36cc1b5f-0bff-4c79-aef3-10142f963eb9")
	)
	(wire
		(pts
			(xy 88.9 38.1) (xy 88.9 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "37604488-496b-4012-84e8-1e966b3cb4e1")
	)
	(wire
		(pts
			(xy 284.48 48.26) (xy 292.1 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3843f373-10a2-4a0b-9d68-b4fd40b347a2")
	)
	(wire
		(pts
			(xy 274.32 251.46) (xy 274.32 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3894a632-efbb-40c8-8f61-7099b444db4e")
	)
	(wire
		(pts
			(xy 345.44 381) (xy 345.44 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "38e8d594-90fa-4882-8264-4d35984a9b55")
	)
	(wire
		(pts
			(xy 193.04 289.56) (xy 203.2 289.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3913322d-86a1-47e8-8858-05ec3cc2ac82")
	)
	(wire
		(pts
			(xy 203.2 284.48) (xy 203.2 279.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "39fbf5b4-11a2-48e1-9656-68cc63adb3f7")
	)
	(wire
		(pts
			(xy 144.78 355.6) (xy 144.78 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3a35ccdc-e510-441b-b121-a3aa3f9923e3")
	)
	(wire
		(pts
			(xy 345.44 353.06) (xy 345.44 370.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3a4f5622-42aa-43a7-bf72-12cd0cb0899a")
	)
	(wire
		(pts
			(xy 299.72 264.16) (xy 302.26 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3a81c0a0-d356-4cc4-abda-0b0bbf7afa4a")
	)
	(wire
		(pts
			(xy 81.28 142.24) (xy 81.28 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3ab49266-c492-4cfb-8075-9f74b46677a5")
	)
	(wire
		(pts
			(xy 203.2 289.56) (xy 203.2 294.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3ac48409-0799-43f9-bac1-ed0c8467ca52")
	)
	(wire
		(pts
			(xy 66.04 165.1) (xy 66.04 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3b72c1bf-9378-4388-833c-9f30afe5269f")
	)
	(wire
		(pts
			(xy 167.64 241.3) (xy 167.64 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3bd157aa-923c-43ca-b583-9e485095cbdf")
	)
	(wire
		(pts
			(xy 119.38 149.86) (xy 119.38 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3c5cabe6-72ea-40c5-afdf-aada50cfe40a")
	)
	(wire
		(pts
			(xy 144.78 66.04) (xy 144.78 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3ca7d81c-bffa-4dcc-8ced-0797a47ac599")
	)
	(wire
		(pts
			(xy 520.7 195.58) (xy 525.78 195.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3cd2affb-c4e2-492d-99f1-4aadb83ad215")
	)
	(wire
		(pts
			(xy 66.04 40.64) (xy 66.04 35.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3d03c1f5-67c9-46ef-902d-d6f87134bad1")
	)
	(wire
		(pts
			(xy 182.88 165.1) (xy 182.88 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3d1d9456-7259-4a7f-8597-6663f6da9007")
	)
	(wire
		(pts
			(xy 182.88 208.28) (xy 198.12 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3dba99a0-6fd3-42b6-be95-985560118fe8")
	)
	(polyline
		(pts
			(xy 424.18 386.08) (xy 424.18 299.72)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "3e1a5dc6-8eca-4988-b456-7350875f72e9")
	)
	(polyline
		(pts
			(xy 241.3 17.78) (xy 241.3 114.3)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "3e4b9128-1b05-4da7-99fc-60c4e17de425")
	)
	(wire
		(pts
			(xy 332.74 246.38) (xy 274.32 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3e656e75-1891-4ff9-824b-8507f58b34c0")
	)
	(wire
		(pts
			(xy 101.6 45.72) (xy 175.26 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3e6de381-3205-4005-82ba-5c0e5503ec3c")
	)
	(wire
		(pts
			(xy 281.94 266.7) (xy 259.08 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "3e8d0a5c-0354-4efa-a2c2-ce704406d7b0")
	)
	(polyline
		(pts
			(xy 449.58 213.36) (xy 449.58 124.46)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "3f05f662-7205-43d2-9a13-fe0ea65efbb6")
	)
	(polyline
		(pts
			(xy 342.9 284.48) (xy 342.9 220.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "3f9f7e21-a2d2-47d8-83a1-68eb5ad48ee8")
	)
	(polyline
		(pts
			(xy 523.367 324.993) (xy 574.167 324.993)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "3fd30218-a9b3-4e17-bf9c-1217470c24fd")
	)
	(wire
		(pts
			(xy 162.56 33.02) (xy 200.66 33.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4080aa10-a4d4-4ccd-b9eb-7163907177d6")
	)
	(polyline
		(pts
			(xy 482.6 325.12) (xy 518.16 325.12)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "40826e68-011c-4a9a-a69f-a7d5908843ab")
	)
	(wire
		(pts
			(xy 101.6 226.06) (xy 101.6 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "40f49324-e96d-47b7-a9e7-8b4c79049fbb")
	)
	(polyline
		(pts
			(xy 254 139.7) (xy 436.88 139.7)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "42088f52-7cc2-4d79-ac54-b6c6b655fc8f")
	)
	(wire
		(pts
			(xy 200.66 246.38) (xy 213.36 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "428b75e2-e012-4306-9bdf-b3a877efc115")
	)
	(wire
		(pts
			(xy 190.5 241.3) (xy 167.64 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "42b93159-8eb4-4039-b54a-3c03bc089d56")
	)
	(wire
		(pts
			(xy 175.26 45.72) (xy 182.88 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "43208eb3-2b22-4406-b01f-5b4fb7158961")
	)
	(wire
		(pts
			(xy 215.9 165.1) (xy 220.98 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4353f9bb-7c87-4638-b35e-ec1e5998fbcd")
	)
	(wire
		(pts
			(xy 210.82 271.78) (xy 210.82 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "44a6f463-c3aa-4bd1-b3df-975b9b488a92")
	)
	(wire
		(pts
			(xy 86.36 170.18) (xy 86.36 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "44aee54c-6853-4aa5-b045-69486ddf527b")
	)
	(wire
		(pts
			(xy 66.04 154.94) (xy 68.58 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4542370e-9417-49b1-bf57-a65e1ad13e30")
	)
	(wire
		(pts
			(xy 175.26 66.04) (xy 175.26 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "45d1e9d3-c6fc-4e30-89a5-9e2e2c34b50b")
	)
	(wire
		(pts
			(xy 177.8 182.88) (xy 195.58 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "45f70395-c8cd-47f8-ac04-f999e8dfb3a4")
	)
	(wire
		(pts
			(xy 411.48 236.22) (xy 411.48 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "46aac5ba-59eb-4b9c-9c07-83b94744de2f")
	)
	(wire
		(pts
			(xy 312.42 375.92) (xy 325.12 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "46e97335-97aa-46b0-ba14-7b4fc73cbeb3")
	)
	(wire
		(pts
			(xy 190.5 363.22) (xy 220.98 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "47c66879-8c21-48ca-a539-c73602f897ae")
	)
	(wire
		(pts
			(xy 170.18 383.54) (xy 170.18 391.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "47f2b024-cea9-4b1a-b359-0a4fc988e748")
	)
	(wire
		(pts
			(xy 127 226.06) (xy 127 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4800914e-1dd9-4997-9f1f-2746acb26caf")
	)
	(wire
		(pts
			(xy 210.82 264.16) (xy 223.52 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "480a48a7-9953-40e4-a7cb-ba0a6189176a")
	)
	(wire
		(pts
			(xy 500.38 147.32) (xy 508 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "48394807-bc3e-4f47-9dc8-258a779573f1")
	)
	(wire
		(pts
			(xy 190.5 383.54) (xy 190.5 386.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "48ee56fd-25ec-4026-8819-616a4d1bba2f")
	)
	(wire
		(pts
			(xy 365.76 193.04) (xy 350.52 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "490b1fd5-af03-4dce-98d0-ec61657f5b5d")
	)
	(wire
		(pts
			(xy 386.08 109.22) (xy 424.18 109.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4934709b-1d42-475e-879a-cfa179a0019f")
	)
	(wire
		(pts
			(xy 289.56 180.34) (xy 289.56 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "49c0714c-0978-427a-92c5-26010afc5b1e")
	)
	(wire
		(pts
			(xy 515.62 160.02) (xy 520.7 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "49ecc442-b4ef-4d61-951a-21c146484679")
	)
	(wire
		(pts
			(xy 523.24 53.34) (xy 556.26 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a002deb-7389-418d-8557-6120f05d69c9")
	)
	(wire
		(pts
			(xy 123.19 327.66) (xy 167.64 327.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a033329-1c13-43aa-8b2d-77674fe62269")
	)
	(wire
		(pts
			(xy 330.2 182.88) (xy 322.58 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a272a36-0166-48be-ac93-bf0391d27567")
	)
	(wire
		(pts
			(xy 182.88 218.44) (xy 182.88 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a2ba713-a55d-442a-893a-44cf47b214bd")
	)
	(wire
		(pts
			(xy 172.72 73.66) (xy 175.26 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4a48413b-15a7-4bc3-b9d6-9a6ef10e10b8")
	)
	(wire
		(pts
			(xy 388.62 187.96) (xy 388.62 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4af60181-5854-4846-848e-94b713d01f54")
	)
	(wire
		(pts
			(xy 101.6 177.8) (xy 106.68 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4b057587-e008-47b1-8f19-6779974ac1c6")
	)
	(wire
		(pts
			(xy 297.18 274.32) (xy 332.74 274.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4b2b9f07-7e0e-461d-92de-b7f67f39ae56")
	)
	(wire
		(pts
			(xy 386.08 121.92) (xy 424.18 121.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4c0ef5f6-7294-4833-8eb0-d736c1d4e32a")
	)
	(wire
		(pts
			(xy 322.58 340.36) (xy 353.06 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4c39540f-06ce-47fa-b29a-ff06b5be5b79")
	)
	(wire
		(pts
			(xy 396.24 40.64) (xy 391.16 40.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4c40b60b-0746-4ef8-8b0f-1ca035935605")
	)
	(wire
		(pts
			(xy 378.46 167.64) (xy 388.62 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4ca4d178-f981-4575-9020-8943d91b310a")
	)
	(wire
		(pts
			(xy 101.6 200.66) (xy 71.12 200.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4cebd6a2-57bc-4f4f-8499-df8687d9483c")
	)
	(wire
		(pts
			(xy 520.7 259.08) (xy 533.4 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4d0ccc4a-1f65-4498-9f0c-ef4fa1dc8037")
	)
	(wire
		(pts
			(xy 73.66 43.18) (xy 73.66 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4dec54b0-84cc-477d-8ff6-09cd23892984")
	)
	(wire
		(pts
			(xy 386.08 119.38) (xy 424.18 119.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4e12ab88-61c1-43a7-ab82-a702b0630bb2")
	)
	(wire
		(pts
			(xy 541.02 259.08) (xy 561.34 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4e30b6dc-3526-478e-a0fb-9cafb9ddb868")
	)
	(wire
		(pts
			(xy 421.64 175.26) (xy 419.1 175.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4ed34052-2cb4-4510-9941-bc8f7fd39954")
	)
	(polyline
		(pts
			(xy 254 149.86) (xy 254 213.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "4ee0989f-b9ba-4917-96c7-8e70571852bc")
	)
	(wire
		(pts
			(xy 93.98 195.58) (xy 71.12 195.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4f1e1d16-fc1c-4dbf-8070-6717854f8725")
	)
	(wire
		(pts
			(xy 154.94 335.28) (xy 167.64 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4f6e3cbb-8711-4230-8d38-cc2bb9340933")
	)
	(wire
		(pts
			(xy 119.38 147.32) (xy 147.32 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4f761781-7e3d-43cf-924a-416037332251")
	)
	(wire
		(pts
			(xy 497.84 259.08) (xy 520.7 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "4ff8a467-1558-4d28-90e9-bb4e248faa5e")
	)
	(wire
		(pts
			(xy 182.88 228.6) (xy 182.88 226.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "501cca8a-9145-4503-81f8-9d5cd92ea449")
	)
	(wire
		(pts
			(xy 187.96 83.82) (xy 187.96 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "50c4d1e6-974e-4800-b82d-1cb7584cfa75")
	)
	(wire
		(pts
			(xy 408.94 246.38) (xy 408.94 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "50c718ea-cbe2-4982-9358-51dfbff36167")
	)
	(wire
		(pts
			(xy 386.08 76.2) (xy 411.48 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5107510e-0962-4a6e-895d-e7854e91ee3b")
	)
	(polyline
		(pts
			(xy 436.88 304.8) (xy 436.88 381)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "511c7c01-f999-4ee7-a1de-27f935741526")
	)
	(wire
		(pts
			(xy 180.34 162.56) (xy 180.34 170.18)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5151d57e-1894-46b4-8931-a1a92d696b16")
	)
	(wire
		(pts
			(xy 154.94 337.82) (xy 220.98 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5168f60e-b4b4-45ce-b27f-e29e720f2918")
	)
	(polyline
		(pts
			(xy 482.727 337.82) (xy 541.782 337.82)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "52328de8-3496-4e5a-b0f6-adc1a419beee")
	)
	(wire
		(pts
			(xy 322.58 340.36) (xy 322.58 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "524b8840-1957-4406-be39-90cca5ab9260")
	)
	(wire
		(pts
			(xy 525.78 88.9) (xy 523.24 88.9)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5258d4a3-5e5f-4d10-933a-48018a8d68e6")
	)
	(polyline
		(pts
			(xy 494.157 334.645) (xy 494.157 340.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "53449efe-5401-483f-a846-07b0116721b3")
	)
	(wire
		(pts
			(xy 25.4 157.48) (xy 25.4 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "537e55d1-bbe9-4f4e-b675-7c3ec80e2664")
	)
	(polyline
		(pts
			(xy 457.2 284.48) (xy 574.04 284.48)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "54db439a-cbe7-4eaf-9704-3482a3ffde9e")
	)
	(wire
		(pts
			(xy 205.74 78.74) (xy 208.28 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "54fad0fa-b116-4a8a-87ce-e47155fbb3eb")
	)
	(polyline
		(pts
			(xy 219.71 342.9) (xy 195.58 342.9)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5560a811-2076-4733-a0e4-fa099967ff39")
	)
	(wire
		(pts
			(xy 165.1 73.66) (xy 162.56 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "55807fdf-15ec-4422-a548-81416c1aac05")
	)
	(wire
		(pts
			(xy 299.72 347.98) (xy 309.88 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "55f925fe-a7e2-4e8e-bb33-737088a2e671")
	)
	(wire
		(pts
			(xy 520.7 200.66) (xy 525.78 200.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "568256f4-430e-4880-8cb7-c73b718a3bd2")
	)
	(wire
		(pts
			(xy 30.48 360.68) (xy 30.48 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "56f509ec-2a93-41fb-a1c7-deb45bc11cee")
	)
	(wire
		(pts
			(xy 60.96 254) (xy 60.96 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5756400c-97b6-4d4a-851a-f39fb8d00ee4")
	)
	(wire
		(pts
			(xy 299.72 187.96) (xy 299.72 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5820bec6-7dca-41ca-b67e-9f6e995f7f13")
	)
	(wire
		(pts
			(xy 279.4 68.58) (xy 284.48 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "58b52b04-6383-4fe4-9107-7e12bf40f61b")
	)
	(wire
		(pts
			(xy 132.08 208.28) (xy 147.32 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "591f8882-2617-4139-aea6-2bd13dab5410")
	)
	(wire
		(pts
			(xy 73.66 355.6) (xy 73.66 360.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "595f456d-cc39-4870-94a1-c7628d7e98ee")
	)
	(polyline
		(pts
			(xy 558.292 360.68) (xy 558.292 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "59721c19-4d18-482f-8880-7046dbde29b2")
	)
	(wire
		(pts
			(xy 193.04 284.48) (xy 203.2 284.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5a230f29-3cf8-42f6-a740-d8d8d7c0cfb6")
	)
	(wire
		(pts
			(xy 106.68 167.64) (xy 106.68 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5a79bbe6-ddde-4e09-9ddb-52abec6d9713")
	)
	(wire
		(pts
			(xy 223.52 208.28) (xy 205.74 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5a90f89c-59da-4969-b0bb-3ecc2e4e1830")
	)
	(polyline
		(pts
			(xy 523.367 309.372) (xy 574.167 309.372)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5a9c885c-1f14-42d4-8e67-9cf4dc8a7532")
	)
	(polyline
		(pts
			(xy 254 17.78) (xy 254 139.7)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5b1438d4-8c44-4bbd-b985-d754f8a5f103")
	)
	(polyline
		(pts
			(xy 449.58 17.78) (xy 449.58 116.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5b45d15e-e35f-427f-ba59-9ad9be558675")
	)
	(wire
		(pts
			(xy 101.6 73.66) (xy 101.6 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5b473827-cf8d-49cb-96db-397c65f4716f")
	)
	(wire
		(pts
			(xy 223.52 200.66) (xy 208.28 200.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5b80993d-83ff-4ec1-a928-93fcde19c81e")
	)
	(wire
		(pts
			(xy 101.6 198.12) (xy 101.6 200.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5b88148b-23ef-4cc8-a6a8-18b29c1c24f2")
	)
	(wire
		(pts
			(xy 332.74 175.26) (xy 330.2 175.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5ba1da1a-7d31-42a2-bb5a-577132bef237")
	)
	(wire
		(pts
			(xy 63.5 73.66) (xy 68.58 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5bf1b2b0-1a75-4fd3-8420-f64b69789a1e")
	)
	(wire
		(pts
			(xy 99.06 360.68) (xy 106.68 360.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5c79f3ba-7ddf-43d6-91c2-04552258563d")
	)
	(wire
		(pts
			(xy 88.9 45.72) (xy 101.6 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5c8ba335-f452-4914-9007-c5b0958bf1c9")
	)
	(polyline
		(pts
			(xy 482.727 358.14) (xy 574.802 358.14)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5cb84d00-0a2d-4d91-ad8c-bc962bd28402")
	)
	(wire
		(pts
			(xy 279.4 375.92) (xy 287.02 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5ccb9c13-7316-401f-8de6-00ebaa8b2f71")
	)
	(wire
		(pts
			(xy 510.54 53.34) (xy 474.98 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5cf5caeb-65cc-4dff-b45f-37254709ddeb")
	)
	(polyline
		(pts
			(xy 424.18 304.8) (xy 465.455 304.8)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "5d750460-636a-4acd-9b34-521695656a41")
	)
	(wire
		(pts
			(xy 386.08 99.06) (xy 424.18 99.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5ec8c21a-7eb9-404a-ab61-5ae9180d64c1")
	)
	(wire
		(pts
			(xy 203.2 271.78) (xy 203.2 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5ecbdee6-cea3-48b1-9fc5-fda75a5d6943")
	)
	(wire
		(pts
			(xy 25.4 137.16) (xy 25.4 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5ed82491-6078-4563-99cd-fcbf4408cb51")
	)
	(wire
		(pts
			(xy 525.78 83.82) (xy 523.24 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5edc6dac-6dd1-4615-b4d1-fa265363276e")
	)
	(wire
		(pts
			(xy 48.26 60.96) (xy 48.26 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5f53a1d0-1af5-4d0b-b6e6-6233f90624d8")
	)
	(wire
		(pts
			(xy 25.4 147.32) (xy 33.02 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "5fff7f0d-2cdf-4e15-be46-776f4debfa0f")
	)
	(wire
		(pts
			(xy 127 251.46) (xy 114.3 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "602f2f47-5a34-42ee-8713-c08973590573")
	)
	(wire
		(pts
			(xy 104.14 231.14) (xy 101.6 231.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "609a0b19-f41a-4def-b8d6-3f9e11ba9084")
	)
	(polyline
		(pts
			(xy 465.455 299.72) (xy 465.455 386.08)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "60e3dcfb-db2d-4f5f-a3d0-dde6b3e93722")
	)
	(wire
		(pts
			(xy 96.52 205.74) (xy 127 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "61eba465-5d1e-4fc7-9b20-502bd19d8eee")
	)
	(wire
		(pts
			(xy 190.5 398.78) (xy 190.5 396.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "632ee0c0-c1bd-4f07-a2d3-22ea2808c2fd")
	)
	(wire
		(pts
			(xy 508 160.02) (xy 477.52 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6352c37c-3298-4b8e-923f-84040e79259b")
	)
	(polyline
		(pts
			(xy 254 299.72) (xy 254 401.32)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "637b99b7-3a05-428f-9450-facedb7fd687")
	)
	(wire
		(pts
			(xy 180.34 391.16) (xy 185.42 391.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "63eb5cbc-811b-4f18-90b6-4928866c2fc0")
	)
	(wire
		(pts
			(xy 78.74 45.72) (xy 78.74 58.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "643d3324-2499-48cc-89f9-116abc494f4a")
	)
	(wire
		(pts
			(xy 510.54 55.88) (xy 474.98 55.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6482498b-76b9-4c95-bfa0-6dae531db2fe")
	)
	(wire
		(pts
			(xy 421.64 177.8) (xy 419.1 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "64eba2b1-53b5-4aa8-a62e-fa93e22cb190")
	)
	(wire
		(pts
			(xy 520.7 165.1) (xy 520.7 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "65119d14-0be6-4c38-b2eb-c1619ade314a")
	)
	(wire
		(pts
			(xy 330.2 355.6) (xy 360.68 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "66302368-b8bc-4003-a7b0-6003bcdff59b")
	)
	(wire
		(pts
			(xy 210.82 292.1) (xy 210.82 294.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "667b6194-06f7-4233-8715-f923ee12afa8")
	)
	(wire
		(pts
			(xy 134.62 73.66) (xy 162.56 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "669fcda7-5acd-47f8-b1d2-a861378b7541")
	)
	(wire
		(pts
			(xy 284.48 76.2) (xy 284.48 91.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "673708df-4f8b-4014-822c-363c774f01c0")
	)
	(wire
		(pts
			(xy 177.8 180.34) (xy 195.58 180.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "673b90c4-c90d-4094-9d8d-61642e62eafa")
	)
	(wire
		(pts
			(xy 114.3 251.46) (xy 114.3 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "675ba448-6e1c-43a0-9b75-48222e824839")
	)
	(wire
		(pts
			(xy 177.8 172.72) (xy 195.58 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "67cd7cc6-1875-49ee-9d0c-cdbc8dd5390b")
	)
	(wire
		(pts
			(xy 203.2 284.48) (xy 210.82 284.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "685b69a3-4554-48ac-a15e-c4f1df95a66d")
	)
	(wire
		(pts
			(xy 106.68 154.94) (xy 119.38 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "68b6bfde-51eb-4ba2-9c7a-9e29a0c7147e")
	)
	(polyline
		(pts
			(xy 574.802 370.84) (xy 574.802 332.74)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "68f020fd-0a95-494d-ba6b-a1b82c36f416")
	)
	(wire
		(pts
			(xy 378.46 261.62) (xy 429.26 261.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "69353f92-e6e6-4ec5-a9a3-020d43d48f7b")
	)
	(wire
		(pts
			(xy 132.08 335.28) (xy 149.86 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "69cef849-7478-495c-ade2-061c86219e7c")
	)
	(polyline
		(pts
			(xy 574.04 213.36) (xy 449.58 213.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "6a7924de-211b-4eee-97ff-365d7fe7f2d5")
	)
	(wire
		(pts
			(xy 523.24 60.96) (xy 556.26 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6a8efe20-308f-4978-9302-e1478fe406c7")
	)
	(polyline
		(pts
			(xy 522.732 334.645) (xy 522.732 340.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "6aeffa9a-8bfc-4d7b-85e3-9607e9f0ce7d")
	)
	(wire
		(pts
			(xy 104.14 340.36) (xy 101.6 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6b0ae815-5623-43d9-bb43-f695de20e989")
	)
	(wire
		(pts
			(xy 88.9 93.98) (xy 88.9 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6b33291b-5e0b-448f-859a-0e666c3387f9")
	)
	(wire
		(pts
			(xy 35.56 243.84) (xy 35.56 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6b7657ad-d4b2-4060-80a6-2ae6c12ea7a4")
	)
	(wire
		(pts
			(xy 78.74 93.98) (xy 78.74 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6bc8c8bb-7eb0-408f-a538-604f8a661437")
	)
	(wire
		(pts
			(xy 119.38 160.02) (xy 147.32 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6bd8aa6c-dc01-4a4f-9ac2-f3fb19aae176")
	)
	(wire
		(pts
			(xy 40.64 83.82) (xy 35.56 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6be3defe-4b05-4a20-80c5-c4bee38deced")
	)
	(wire
		(pts
			(xy 63.5 40.64) (xy 66.04 40.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6c61604d-e4d1-46b0-98b6-77c96da6b1a7")
	)
	(wire
		(pts
			(xy 53.34 172.72) (xy 53.34 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6d62decd-a87c-462e-b86d-87fa30a258bf")
	)
	(wire
		(pts
			(xy 358.14 241.3) (xy 358.14 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6d9838c5-5fd1-4550-9d37-a8a0b9b8767d")
	)
	(wire
		(pts
			(xy 63.5 71.12) (xy 68.58 71.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6e4be797-3ab9-4e01-9103-6e99aeed2eef")
	)
	(polyline
		(pts
			(xy 17.78 307.34) (xy 241.3 307.34)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "6e6cefb1-1d06-4281-845c-529ca9e64697")
	)
	(polyline
		(pts
			(xy 523.367 299.466) (xy 574.167 299.466)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "6e8200e7-e7a7-4c2d-85d7-f064ee2c7729")
	)
	(wire
		(pts
			(xy 284.48 76.2) (xy 266.7 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6ea94fd0-19ff-47ef-9fe1-34c1ab264802")
	)
	(wire
		(pts
			(xy 378.46 259.08) (xy 414.02 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6eab07c3-4073-4167-ad28-cb61fe53dc25")
	)
	(wire
		(pts
			(xy 510.54 83.82) (xy 474.98 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6eb56a80-cb01-4b4d-8ee8-5e4204f1e3b0")
	)
	(wire
		(pts
			(xy 381 256.54) (xy 360.68 256.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6eb87a8a-f5be-48dc-93f2-b8a2a0cc9d86")
	)
	(wire
		(pts
			(xy 515.62 165.1) (xy 520.7 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6ed32058-45a4-4018-8db2-8bb7b53c04c4")
	)
	(wire
		(pts
			(xy 114.3 264.16) (xy 114.3 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6f22d540-1c37-4e90-a2fd-ccba54326c23")
	)
	(wire
		(pts
			(xy 81.28 210.82) (xy 81.28 218.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6f76ebdf-d35e-4cb9-b9e8-00e9e93ad7a4")
	)
	(wire
		(pts
			(xy 353.06 375.92) (xy 353.06 381)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6fc55729-75b7-4171-8521-a80508b372e5")
	)
	(wire
		(pts
			(xy 111.76 177.8) (xy 116.84 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6ffc1700-abfb-4301-853a-cbff5af3c2cd")
	)
	(wire
		(pts
			(xy 88.9 177.8) (xy 88.9 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "6ffd9e1c-7f7d-4cb6-be9e-af06920b91d0")
	)
	(polyline
		(pts
			(xy 241.3 401.32) (xy 241.3 307.34)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "6ffffae9-b6a6-4b04-b170-1ebab1a1c5bd")
	)
	(wire
		(pts
			(xy 266.7 63.5) (xy 266.7 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "70010e87-3c0a-4c26-a04c-6e4da3ae3264")
	)
	(wire
		(pts
			(xy 467.36 274.32) (xy 487.68 274.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "70239ba0-2ded-43b7-bd2c-ed6768589499")
	)
	(wire
		(pts
			(xy 81.28 223.52) (xy 81.28 231.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "707ac6f1-8a21-44ac-abd0-0df29fac7c27")
	)
	(wire
		(pts
			(xy 170.18 342.9) (xy 170.18 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "70e30570-12e4-4453-a55a-1ef1720730a1")
	)
	(wire
		(pts
			(xy 200.66 57.15) (xy 200.66 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "710a2a93-f8f7-4cc3-b86d-abbbdd13c97a")
	)
	(wire
		(pts
			(xy 429.26 254) (xy 368.3 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "715f1025-581f-4f0f-ac5d-9611a818c189")
	)
	(polyline
		(pts
			(xy 403.86 299.72) (xy 403.86 401.32)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "723ed8c7-9b9f-4cc5-b861-60d854da0e32")
	)
	(wire
		(pts
			(xy 185.42 248.92) (xy 187.96 248.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7280088d-1639-49c6-83df-46e08fdc8daf")
	)
	(wire
		(pts
			(xy 523.24 50.8) (xy 556.26 50.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7319b4fe-b793-4a70-95b5-b428127eb6a3")
	)
	(wire
		(pts
			(xy 508 91.44) (xy 510.54 91.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "738e203a-5ee0-453f-80ed-d4bafe831d0e")
	)
	(polyline
		(pts
			(xy 482.727 360.68) (xy 574.802 360.68)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "73c7c34d-2809-4c76-ae68-8a91621029b0")
	)
	(wire
		(pts
			(xy 200.66 33.02) (xy 200.66 36.83)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7408425f-4b79-4082-a416-410fa7cd62aa")
	)
	(wire
		(pts
			(xy 287.02 375.92) (xy 292.1 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "74649e91-327b-44b7-92f8-c73cc8554909")
	)
	(wire
		(pts
			(xy 83.82 355.6) (xy 99.06 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "74885327-59b1-40cf-baf8-794ecde6ac14")
	)
	(wire
		(pts
			(xy 116.84 165.1) (xy 116.84 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "749c23e6-c8f4-4df3-9254-ea380c2a461f")
	)
	(wire
		(pts
			(xy 86.36 205.74) (xy 71.12 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "74e56072-a3aa-4c66-b07b-d0938e9e1022")
	)
	(wire
		(pts
			(xy 182.88 73.66) (xy 182.88 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "757f5bf1-1d38-49f8-af99-9eb84c69903d")
	)
	(wire
		(pts
			(xy 48.26 172.72) (xy 53.34 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "75afe3a1-2ad0-4979-8eb6-6bd62baf5182")
	)
	(wire
		(pts
			(xy 368.3 355.6) (xy 373.38 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "75d97b55-5c52-414f-8a89-8ff09fd1daac")
	)
	(wire
		(pts
			(xy 279.4 340.36) (xy 279.4 345.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "75def6a2-9073-426d-b5a6-6e6eec069270")
	)
	(wire
		(pts
			(xy 91.44 154.94) (xy 93.98 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "76706c29-411c-4a04-b95b-d72a3cbfbdfb")
	)
	(wire
		(pts
			(xy 408.94 269.24) (xy 429.26 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "772c54ea-1552-4735-8494-add3ef338e9d")
	)
	(wire
		(pts
			(xy 96.52 177.8) (xy 96.52 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "776f66c4-2d1f-4d8a-8c41-a1ae67ce34c9")
	)
	(wire
		(pts
			(xy 149.86 358.14) (xy 149.86 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "77a481e5-f29e-4e2c-a31e-18474dbb892a")
	)
	(wire
		(pts
			(xy 403.86 251.46) (xy 411.48 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "77afe8a4-ea1a-419d-9d87-a808f2f2ba00")
	)
	(wire
		(pts
			(xy 299.72 165.1) (xy 299.72 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "77e699b0-7202-4614-be27-6f12a21cef1d")
	)
	(wire
		(pts
			(xy 60.96 246.38) (xy 114.3 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "78253b7f-c960-4896-b560-55a73c712d21")
	)
	(wire
		(pts
			(xy 25.4 152.4) (xy 25.4 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "792cacd7-8f19-4a97-a95a-7cc0ecd08982")
	)
	(wire
		(pts
			(xy 330.2 350.52) (xy 340.36 350.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "79ef941e-6c82-409d-b478-0a7f3cfbc428")
	)
	(wire
		(pts
			(xy 190.5 378.46) (xy 198.12 378.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "79fbdccc-bad8-49b2-bf8e-c628399be850")
	)
	(wire
		(pts
			(xy 220.98 162.56) (xy 223.52 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7a028eb2-ef36-456b-8b2e-b53aea436d8f")
	)
	(wire
		(pts
			(xy 86.36 198.12) (xy 86.36 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7a3e8943-d435-4b0b-9eb1-2ed43b14c60e")
	)
	(polyline
		(pts
			(xy 574.167 299.466) (xy 574.167 324.866)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "7a637b39-9fa7-4eae-bc69-e444c3f5a393")
	)
	(wire
		(pts
			(xy 266.7 368.3) (xy 274.32 368.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7a88130f-534d-4996-8da5-92e98085f31e")
	)
	(wire
		(pts
			(xy 289.56 251.46) (xy 299.72 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7aea7212-cb58-402f-b3bd-e5fe94ebc37d")
	)
	(wire
		(pts
			(xy 91.44 208.28) (xy 91.44 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7b11c316-ba63-471f-97ee-70f7d4dbc0c0")
	)
	(wire
		(pts
			(xy 279.4 330.2) (xy 279.4 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7bd52fab-0f74-44f1-955b-2bfc1594aabb")
	)
	(wire
		(pts
			(xy 116.84 177.8) (xy 116.84 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7c71b6c4-b7fb-4730-b8e7-172522c5a44f")
	)
	(wire
		(pts
			(xy 358.14 236.22) (xy 358.14 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7c851ca9-a147-432a-b90f-511cbf7a21c7")
	)
	(wire
		(pts
			(xy 40.64 162.56) (xy 33.02 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7cb45fdc-7f88-4bf6-ab6d-ab8d6ab45c87")
	)
	(wire
		(pts
			(xy 48.26 45.72) (xy 48.26 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7cd0d455-ffc6-4583-a0e2-7e6b8d7196f1")
	)
	(wire
		(pts
			(xy 104.14 200.66) (xy 104.14 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7cf063f4-aeda-403f-8cf3-bd0a19f30953")
	)
	(wire
		(pts
			(xy 190.5 375.92) (xy 190.5 378.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7dd15d93-7d89-4ee5-9249-53218b42f57d")
	)
	(polyline
		(pts
			(xy 219.71 342.9) (xy 219.71 358.775)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "7de36b72-0188-498b-b25f-71334ba704be")
	)
	(wire
		(pts
			(xy 373.38 355.6) (xy 398.78 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7e25a477-0fde-44c4-9b89-fe48b2ca014f")
	)
	(wire
		(pts
			(xy 96.52 190.5) (xy 71.12 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7e8a80a2-c6f1-4855-a417-52518a32ca3c")
	)
	(wire
		(pts
			(xy 66.04 35.56) (xy 48.26 35.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7f8617a4-6293-49ad-b1d9-6a349cce6e0d")
	)
	(wire
		(pts
			(xy 144.78 322.58) (xy 144.78 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "7fbb6ba9-7ad6-469d-98a1-666b95ed7b5e")
	)
	(polyline
		(pts
			(xy 254 213.36) (xy 436.88 213.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "80043de8-4218-4da6-923b-e4f09206db9e")
	)
	(wire
		(pts
			(xy 220.98 81.28) (xy 220.98 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8005f8ec-b8a0-4fc4-bfc0-8790878eebf3")
	)
	(polyline
		(pts
			(xy 207.645 347.98) (xy 207.645 358.775)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "8030b02d-837b-43e4-b337-10850f2c051a")
	)
	(wire
		(pts
			(xy 48.26 53.34) (xy 48.26 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "804ac3f6-2bfb-48da-b03f-76ae65a93a39")
	)
	(wire
		(pts
			(xy 66.04 160.02) (xy 66.04 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "80507bdd-ef72-4604-a398-de8a94fa6a08")
	)
	(wire
		(pts
			(xy 510.54 48.26) (xy 474.98 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "809dc019-7e0b-44a7-9f06-189625fcc816")
	)
	(wire
		(pts
			(xy 43.18 228.6) (xy 43.18 231.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8113ca20-1a27-44ea-961c-65fcded6b285")
	)
	(wire
		(pts
			(xy 332.74 177.8) (xy 330.2 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8163abd9-bc7b-4010-ba22-cd57549d1540")
	)
	(wire
		(pts
			(xy 35.56 254) (xy 38.1 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "81968e38-53e5-44b5-a9c6-f64a1aae5b16")
	)
	(wire
		(pts
			(xy 132.08 342.9) (xy 144.78 342.9)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "81b30c3d-2d32-4bc4-ab2a-a1c3d8ba9951")
	)
	(wire
		(pts
			(xy 132.08 337.82) (xy 144.78 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "81c3430e-5bf4-4585-b9f8-cd781821aa4e")
	)
	(wire
		(pts
			(xy 111.76 73.66) (xy 101.6 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "81c72226-4e43-4239-a6f2-d26c38416351")
	)
	(wire
		(pts
			(xy 116.84 66.04) (xy 111.76 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "82f36215-718e-49fc-afec-9dc73a554285")
	)
	(wire
		(pts
			(xy 510.54 66.04) (xy 474.98 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "82fc71f9-b95a-4bfa-a592-6c226aa72553")
	)
	(wire
		(pts
			(xy 152.4 93.98) (xy 152.4 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8312b98e-08ec-4d6e-8e7e-2a66c84ab72d")
	)
	(wire
		(pts
			(xy 523.24 58.42) (xy 556.26 58.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "83316328-7485-432e-a32f-4d33d71f9998")
	)
	(wire
		(pts
			(xy 210.82 81.28) (xy 208.28 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8365d9c2-d55f-44dc-90f1-94148493bcb2")
	)
	(wire
		(pts
			(xy 523.24 86.36) (xy 525.78 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "83cb41e2-c0f4-4500-b98c-fc6bd1d74191")
	)
	(wire
		(pts
			(xy 175.26 88.9) (xy 175.26 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8407791d-edbe-4c3f-be9b-5e74dc6dfcd9")
	)
	(wire
		(pts
			(xy 289.56 198.12) (xy 289.56 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "845b6780-79a3-45e6-a2df-af07fe20cabc")
	)
	(wire
		(pts
			(xy 292.1 347.98) (xy 287.02 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "848c518a-8785-4d26-a041-b95b1e60737c")
	)
	(wire
		(pts
			(xy 523.24 43.18) (xy 556.26 43.18)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "848d14dc-55e8-4c14-854b-deaf4a4314fe")
	)
	(wire
		(pts
			(xy 287.02 350.52) (xy 314.96 350.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "84c8b395-3313-4366-b7e3-a820bd8fad40")
	)
	(wire
		(pts
			(xy 309.88 175.26) (xy 309.88 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "84d19520-b015-45e6-9a3e-2f4d3ee032f7")
	)
	(wire
		(pts
			(xy 167.64 238.76) (xy 167.64 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "84dc28f8-e8b4-4e52-afe9-6de318d854df")
	)
	(wire
		(pts
			(xy 78.74 360.68) (xy 73.66 360.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "850e0997-6796-4e0e-864f-92db9477c5e7")
	)
	(wire
		(pts
			(xy 205.74 162.56) (xy 180.34 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "852cad20-350b-4b6f-af2d-5f13e1a505d6")
	)
	(wire
		(pts
			(xy 208.28 83.82) (xy 208.28 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8565455a-14c9-442a-9c79-f903a0ae366d")
	)
	(wire
		(pts
			(xy 182.88 45.72) (xy 182.88 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "85933599-e62d-4d2f-9115-61137bca3561")
	)
	(wire
		(pts
			(xy 96.52 154.94) (xy 101.6 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "85a66b97-44d4-4bf9-867b-7c48f58004af")
	)
	(wire
		(pts
			(xy 398.78 175.26) (xy 398.78 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "85aa7cfe-326c-4041-b460-5926a948853a")
	)
	(wire
		(pts
			(xy 289.56 193.04) (xy 292.1 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8627584e-ca14-48a5-93b8-a39a2f8c4561")
	)
	(wire
		(pts
			(xy 124.46 236.22) (xy 132.08 236.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "86a27612-4e0f-4539-b810-e1c916439b9a")
	)
	(wire
		(pts
			(xy 332.74 251.46) (xy 332.74 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8772c1c3-e368-41d7-9a12-a39f56fd9aec")
	)
	(wire
		(pts
			(xy 530.86 187.96) (xy 530.86 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "87f6b215-2f38-409a-a030-bff7a2e033bd")
	)
	(wire
		(pts
			(xy 81.28 210.82) (xy 71.12 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8808bffc-1985-44a9-a7e6-a8250d08dc3d")
	)
	(polyline
		(pts
			(xy 482.727 345.44) (xy 541.782 345.44)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "88328503-593b-49dc-b727-96de9ba615e9")
	)
	(wire
		(pts
			(xy 292.1 63.5) (xy 284.48 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "88ed0016-53f9-44d0-97e4-2e0454385fc9")
	)
	(wire
		(pts
			(xy 314.96 355.6) (xy 294.64 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "89656497-f333-4e2d-96f3-1e1e0e687519")
	)
	(wire
		(pts
			(xy 35.56 246.38) (xy 35.56 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "89843544-67c8-4c7a-801b-ead900b16289")
	)
	(wire
		(pts
			(xy 335.28 251.46) (xy 335.28 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "89aa53bd-3b75-4b66-82e1-682bf0e31166")
	)
	(wire
		(pts
			(xy 33.02 60.96) (xy 48.26 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "89ae39df-aed1-4699-855a-8c77b7a9409f")
	)
	(wire
		(pts
			(xy 388.62 167.64) (xy 388.62 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8a1673fb-1b49-49c5-8d6e-474d6256c8bf")
	)
	(wire
		(pts
			(xy 480.06 259.08) (xy 487.68 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8abfbe82-fff3-4991-9c50-be6de29d4bb9")
	)
	(wire
		(pts
			(xy 104.14 327.66) (xy 115.57 327.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8b678038-16c7-4984-8503-cbcdd7864a03")
	)
	(polyline
		(pts
			(xy 201.295 347.98) (xy 201.295 358.775)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "8b9e52d0-3c74-4322-8061-75cf9ae431de")
	)
	(wire
		(pts
			(xy 391.16 48.26) (xy 424.18 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8c174365-9972-464c-b77e-e21eae251ed7")
	)
	(wire
		(pts
			(xy 132.08 236.22) (xy 132.08 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8c1c78fb-4083-4986-a859-e29a2120bda3")
	)
	(wire
		(pts
			(xy 101.6 330.2) (xy 71.12 330.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8c46000c-11a7-4e3e-bfe0-d506df6c8ce7")
	)
	(wire
		(pts
			(xy 368.3 241.3) (xy 358.14 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8cb3b29d-dc51-4bfe-9b02-92cb29f0ecdd")
	)
	(wire
		(pts
			(xy 287.02 50.8) (xy 292.1 50.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8cbe604b-5f2f-4b5e-9820-5be5f706b23b")
	)
	(wire
		(pts
			(xy 386.08 73.66) (xy 411.48 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8df8dae3-d216-458f-b401-28e87913c2e1")
	)
	(wire
		(pts
			(xy 523.24 68.58) (xy 556.26 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8e784f99-91f6-4df2-b998-aac5c2730c2f")
	)
	(wire
		(pts
			(xy 170.18 391.16) (xy 180.34 391.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8e89395e-ed1e-414e-87e4-34f98da2e24b")
	)
	(wire
		(pts
			(xy 48.26 45.72) (xy 52.07 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8ead5679-15a8-43df-b53c-8dad7568ce32")
	)
	(wire
		(pts
			(xy 292.1 353.06) (xy 292.1 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8ef641f3-a890-4b35-a250-168e731bc14c")
	)
	(wire
		(pts
			(xy 162.56 73.66) (xy 162.56 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8f38793b-75c2-42a5-887d-6498c47692be")
	)
	(wire
		(pts
			(xy 330.2 251.46) (xy 332.74 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8fc41a65-fdc1-471b-8247-804e47ad29c9")
	)
	(wire
		(pts
			(xy 330.2 353.06) (xy 345.44 353.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "8fd2adff-8210-4865-8dd9-b2b325a91d2d")
	)
	(wire
		(pts
			(xy 388.62 187.96) (xy 398.78 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9058cea8-6ad4-4505-be50-26d2f49468ed")
	)
	(wire
		(pts
			(xy 226.06 78.74) (xy 233.68 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "908efae1-86fa-4bbe-831d-d987601724ce")
	)
	(polyline
		(pts
			(xy 494.157 360.68) (xy 494.157 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "909718f4-4d12-494b-a3be-337b9b3b84ca")
	)
	(wire
		(pts
			(xy 144.78 337.82) (xy 149.86 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9163622a-e368-485b-a6ab-5d4622a78d92")
	)
	(wire
		(pts
			(xy 530.86 203.2) (xy 530.86 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "917d6523-6ef9-416a-9271-cb46836a6dc6")
	)
	(wire
		(pts
			(xy 93.98 195.58) (xy 93.98 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9207227f-f73e-4408-9fa0-4e9f79f6d8ae")
	)
	(wire
		(pts
			(xy 40.64 218.44) (xy 40.64 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "920acfc4-0d2f-4359-b8b5-ba5462de71bc")
	)
	(wire
		(pts
			(xy 33.02 66.04) (xy 40.64 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "922556cb-c0b4-482e-bcd0-eacd86d9f206")
	)
	(wire
		(pts
			(xy 205.74 165.1) (xy 182.88 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "922d4c4a-01ea-4ce1-8734-7b8a451abd45")
	)
	(wire
		(pts
			(xy 368.3 251.46) (xy 370.84 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "92492115-642a-4d56-bff1-f5540dcc03b7")
	)
	(wire
		(pts
			(xy 88.9 170.18) (xy 88.9 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "92d35a2a-ec4a-42bd-84a8-5d70d0336d0b")
	)
	(polyline
		(pts
			(xy 350.52 220.98) (xy 350.52 284.48)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9320f8ef-afd9-4a01-b99d-505abd51b01f")
	)
	(wire
		(pts
			(xy 330.2 180.34) (xy 330.2 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9392a264-1bdc-4d60-b31b-c02825afd690")
	)
	(polyline
		(pts
			(xy 482.727 365.76) (xy 574.802 365.76)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "93eaf5cc-8603-41b8-8f5c-8c5bb70d6108")
	)
	(wire
		(pts
			(xy 226.06 73.66) (xy 226.06 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "940cfd44-e755-466d-83fb-40b9b93314a6")
	)
	(wire
		(pts
			(xy 386.08 104.14) (xy 424.18 104.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "94128f0f-1785-4724-9270-e27ddd53bedb")
	)
	(wire
		(pts
			(xy 508 86.36) (xy 510.54 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "942d57e0-f344-43ee-9d1d-9a76fa4daafc")
	)
	(wire
		(pts
			(xy 106.68 177.8) (xy 111.76 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9483365c-7260-4603-95bc-36aef0ca6ecd")
	)
	(wire
		(pts
			(xy 223.52 22.86) (xy 238.76 22.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "94c6fed9-fdd3-4eed-b97b-50b9e8e2be9e")
	)
	(wire
		(pts
			(xy 284.48 198.12) (xy 289.56 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "94d2667f-17e7-4bc2-a452-60b348b06c0d")
	)
	(polyline
		(pts
			(xy 436.88 17.78) (xy 436.88 139.7)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "94f1d858-ff63-4b04-a7c2-a020a5fa5248")
	)
	(polyline
		(pts
			(xy 523.621 312.928) (xy 574.167 312.928)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9537bfeb-9cad-4069-ae43-ffc5feb41fbb")
	)
	(wire
		(pts
			(xy 127 205.74) (xy 147.32 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "95422747-aa2f-4f17-89bb-5939cbaf1b5d")
	)
	(wire
		(pts
			(xy 124.46 226.06) (xy 127 226.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "959cfa80-d71f-44c7-a156-fd69ddd0e546")
	)
	(wire
		(pts
			(xy 101.6 162.56) (xy 101.6 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "95c63262-62fc-4ba4-a28a-671246e2ad61")
	)
	(wire
		(pts
			(xy 182.88 78.74) (xy 187.96 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "95d0d0be-bd95-4eab-a645-2ebdce34e60d")
	)
	(polyline
		(pts
			(xy 522.732 342.9) (xy 522.732 350.52)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9611ede7-de1f-4f2e-8651-c75e27139ef2")
	)
	(wire
		(pts
			(xy 111.76 66.04) (xy 111.76 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "96c9d3f0-ddb0-4ad9-bc02-c1f3ceb9373c")
	)
	(wire
		(pts
			(xy 523.24 76.2) (xy 556.26 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "96dbdcc0-b6f4-4c0b-a540-afaa88c0ad93")
	)
	(wire
		(pts
			(xy 358.14 248.92) (xy 358.14 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9711cb95-a7fe-4d7a-a713-ed68118822ea")
	)
	(polyline
		(pts
			(xy 241.3 302.26) (xy 241.3 127)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9756e316-d265-4429-89fb-c272b511f43c")
	)
	(wire
		(pts
			(xy 213.36 46.99) (xy 213.36 50.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "978131f4-2d03-4679-83a0-7a4f6b705a38")
	)
	(wire
		(pts
			(xy 386.08 114.3) (xy 424.18 114.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9858b9ee-7ec6-4e44-be5f-725eec0d4c9f")
	)
	(wire
		(pts
			(xy 71.12 330.2) (xy 71.12 345.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "98dfa05f-224f-468c-b8a0-d547e232f425")
	)
	(wire
		(pts
			(xy 180.34 170.18) (xy 233.68 170.18)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9959eef2-1052-434e-80bf-c6a582cb90e8")
	)
	(wire
		(pts
			(xy 35.56 264.16) (xy 35.56 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9a4a3aa0-0699-43f7-bbe1-7a27a8443f30")
	)
	(polyline
		(pts
			(xy 17.78 127) (xy 17.78 302.26)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9a5b295b-1801-449a-a176-e8c12cb6f221")
	)
	(wire
		(pts
			(xy 228.6 33.02) (xy 238.76 33.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9a6c8ce4-6572-407b-b3ef-2bb860df5c37")
	)
	(wire
		(pts
			(xy 170.18 353.06) (xy 170.18 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9a73945d-fae9-4677-b64a-e68e8a310e89")
	)
	(wire
		(pts
			(xy 170.18 358.14) (xy 149.86 358.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9a7b3baa-e0e0-4e47-8440-1b6552ee890f")
	)
	(wire
		(pts
			(xy 187.96 78.74) (xy 190.5 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9aa6eba4-1bc8-4af4-9418-9759a6873eab")
	)
	(wire
		(pts
			(xy 167.64 335.28) (xy 220.98 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9ae21b19-6fb8-4481-9a99-cc8aff1269eb")
	)
	(wire
		(pts
			(xy 96.52 190.5) (xy 96.52 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9b59acce-2b79-4424-835e-40611f22d6b9")
	)
	(wire
		(pts
			(xy 332.74 180.34) (xy 330.2 180.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9b59d8c0-8bc8-463f-b383-7fdd2f450592")
	)
	(wire
		(pts
			(xy 114.3 73.66) (xy 111.76 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9b67b1a9-1220-494e-ae14-3de23454e1bf")
	)
	(wire
		(pts
			(xy 182.88 208.28) (xy 182.88 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9c0eb741-ce75-402b-b4ea-731215e63c52")
	)
	(wire
		(pts
			(xy 378.46 193.04) (xy 381 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9c4695a4-3e58-43cb-92af-9d514b00eb1a")
	)
	(wire
		(pts
			(xy 182.88 55.88) (xy 182.88 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9cf36d88-afe7-4076-b118-183c278e3f36")
	)
	(wire
		(pts
			(xy 419.1 175.26) (xy 419.1 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9d39043a-37ee-483f-b4a2-d3ce8146c1bd")
	)
	(wire
		(pts
			(xy 101.6 149.86) (xy 96.52 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9d4ddf85-d0e5-4623-8f0d-de99e7acd4e3")
	)
	(wire
		(pts
			(xy 38.1 289.56) (xy 50.8 289.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9d80f4e8-cc22-4051-a3db-7ca3f8e1318a")
	)
	(wire
		(pts
			(xy 294.64 368.3) (xy 294.64 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9dd01f2e-fa40-4535-aa61-7937d9e9f17d")
	)
	(polyline
		(pts
			(xy 494.157 342.9) (xy 494.157 350.52)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9dd94da0-560e-48e3-9ae7-0f761f14ae91")
	)
	(wire
		(pts
			(xy 226.06 86.36) (xy 226.06 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9de10027-3300-457f-b3c1-7b1a39befade")
	)
	(wire
		(pts
			(xy 170.18 355.6) (xy 144.78 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9e1dc294-f02b-46aa-a2bd-c605fb494d07")
	)
	(wire
		(pts
			(xy 213.36 46.99) (xy 200.66 46.99)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9e38b0de-39e2-4f18-8249-ce4ac0274c14")
	)
	(wire
		(pts
			(xy 104.14 226.06) (xy 101.6 226.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9e40a30b-dac3-4ae7-a938-b7ad74f9276f")
	)
	(polyline
		(pts
			(xy 17.78 127) (xy 241.3 127)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9e501e64-8200-451c-9b30-f3c02bcfde5e")
	)
	(wire
		(pts
			(xy 96.52 210.82) (xy 147.32 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9e76681a-2157-4174-86b1-262790e0d9b3")
	)
	(wire
		(pts
			(xy 162.56 68.58) (xy 162.56 33.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9eeb4530-f803-4973-af85-ace72a5ef30e")
	)
	(wire
		(pts
			(xy 63.5 53.34) (xy 73.66 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f46d0a9-f848-4cae-86b6-01cf6163d978")
	)
	(wire
		(pts
			(xy 299.72 187.96) (xy 309.88 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f57fb66-c4f5-42c6-8fc6-f989063cd710")
	)
	(wire
		(pts
			(xy 294.64 355.6) (xy 294.64 368.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f75b1fa-2d1d-4ebf-a6a3-17caebde4c31")
	)
	(wire
		(pts
			(xy 388.62 165.1) (xy 388.62 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f825265-7ec1-45d6-ab1d-6afe4fba0359")
	)
	(polyline
		(pts
			(xy 503.047 360.68) (xy 503.047 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "9f85fd7a-4244-425b-a0e1-5e8305e8056e")
	)
	(wire
		(pts
			(xy 274.32 261.62) (xy 274.32 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9f9a2d55-7c57-4bed-a8bf-0a6986be401a")
	)
	(wire
		(pts
			(xy 368.3 254) (xy 368.3 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "9fc28ebf-ecde-4844-a947-39aafa6c1c60")
	)
	(wire
		(pts
			(xy 27.94 337.82) (xy 30.48 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a0b89196-62c7-4f2a-a545-b5dfbdf34e36")
	)
	(wire
		(pts
			(xy 279.4 365.76) (xy 279.4 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a0edb49d-8889-46ea-a7a5-3770ecfd01f8")
	)
	(wire
		(pts
			(xy 78.74 45.72) (xy 83.82 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a0ee3892-ef33-4d9d-8a6d-a8a40c1542c0")
	)
	(wire
		(pts
			(xy 154.94 256.54) (xy 154.94 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a121f4b5-efe0-44a4-87d8-afc528dd348e")
	)
	(polyline
		(pts
			(xy 494.157 353.06) (xy 494.157 358.14)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "a13ba55f-cdc9-446b-88cf-4a65db16330d")
	)
	(wire
		(pts
			(xy 530.86 147.32) (xy 518.16 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a1528512-444a-4bb2-a97b-c72799395bdc")
	)
	(wire
		(pts
			(xy 386.08 111.76) (xy 424.18 111.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a1dede33-9930-4dc9-aa22-3afbc96ffdef")
	)
	(polyline
		(pts
			(xy 254 284.48) (xy 342.9 284.48)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "a1f3550c-0feb-431d-9279-360747752d5d")
	)
	(polyline
		(pts
			(xy 482.727 353.06) (xy 574.802 353.06)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "a243fee8-42ff-48a1-9375-7355672da764")
	)
	(wire
		(pts
			(xy 35.56 220.98) (xy 38.1 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a2476feb-537d-4907-9c85-c62abcae24df")
	)
	(wire
		(pts
			(xy 358.14 243.84) (xy 358.14 248.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a27fdcdc-2a63-46b4-84a6-1bbee314d0e8")
	)
	(wire
		(pts
			(xy 93.98 177.8) (xy 93.98 195.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a29bc012-9850-4e94-95ca-b90593e39e28")
	)
	(wire
		(pts
			(xy 114.3 259.08) (xy 114.3 256.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a31772fb-86f7-44be-971d-180a1d3010c1")
	)
	(wire
		(pts
			(xy 81.28 154.94) (xy 86.36 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a3b68c5d-ef93-42e8-8e14-81e9221778b4")
	)
	(wire
		(pts
			(xy 40.64 66.04) (xy 40.64 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a3cda424-1a09-4169-834b-2fb1dc7e7acd")
	)
	(wire
		(pts
			(xy 523.24 91.44) (xy 525.78 91.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a4203133-bb10-4c7b-9906-5085ffedce33")
	)
	(polyline
		(pts
			(xy 523.621 320.802) (xy 574.167 320.802)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "a42e9d02-4b1a-4d46-8a50-174238f232ef")
	)
	(wire
		(pts
			(xy 101.6 213.36) (xy 147.32 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a4bb11c6-37ae-4742-8b21-84f75d19c95a")
	)
	(wire
		(pts
			(xy 48.26 142.24) (xy 60.96 142.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a4ca3389-f57d-40f1-a74e-2bb134edbb62")
	)
	(wire
		(pts
			(xy 220.98 86.36) (xy 218.44 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a4cfb5cb-1010-4520-8d67-deb655b61259")
	)
	(wire
		(pts
			(xy 160.02 365.76) (xy 162.56 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a4ed2c63-9751-42c4-be02-ddf0c5437e73")
	)
	(wire
		(pts
			(xy 190.5 83.82) (xy 187.96 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a514fba1-9b51-483d-9fb9-ce3b66e450e2")
	)
	(wire
		(pts
			(xy 523.24 66.04) (xy 556.26 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a56a154f-2715-433d-9032-758f0e20387d")
	)
	(wire
		(pts
			(xy 386.08 96.52) (xy 424.18 96.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a6a270ca-4226-4f6f-aec8-4d596b10db06")
	)
	(wire
		(pts
			(xy 152.4 83.82) (xy 144.78 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a6e05230-f688-4021-8bba-5de2fcc90183")
	)
	(wire
		(pts
			(xy 378.46 198.12) (xy 378.46 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a7ca07a4-393f-4433-ada4-85ca245382f9")
	)
	(wire
		(pts
			(xy 353.06 353.06) (xy 353.06 370.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a8701be4-a500-473d-ba1c-0e3af971b9d6")
	)
	(wire
		(pts
			(xy 33.02 162.56) (xy 25.4 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a871f0e3-3dca-4d71-9acd-74050f12113d")
	)
	(wire
		(pts
			(xy 309.88 347.98) (xy 314.96 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a87a6d57-455e-4a2e-8046-85f0fa4b24a7")
	)
	(wire
		(pts
			(xy 226.06 78.74) (xy 226.06 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a8bb7982-5866-4599-873f-bb61efde0b7b")
	)
	(wire
		(pts
			(xy 200.66 243.84) (xy 213.36 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a8c09125-1e3f-4c06-a232-54f20ad002ec")
	)
	(wire
		(pts
			(xy 279.4 345.44) (xy 292.1 345.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a8f491c4-8d80-4aab-80e5-4f06b6517769")
	)
	(wire
		(pts
			(xy 88.9 213.36) (xy 101.6 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "a94768c5-ec57-413f-af20-e5b342ff406b")
	)
	(wire
		(pts
			(xy 299.72 203.2) (xy 299.72 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "aaceb065-9fc0-44af-801b-6c222009efd0")
	)
	(wire
		(pts
			(xy 101.6 330.2) (xy 101.6 322.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ab1715b8-3bfd-4b6d-8b8e-75f1bffed852")
	)
	(wire
		(pts
			(xy 177.8 287.02) (xy 162.56 287.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ab68d94a-152e-4bf6-b208-50565be3bfc7")
	)
	(wire
		(pts
			(xy 266.7 68.58) (xy 271.78 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ab7422b0-fb8b-404f-a487-c39674ecb4a6")
	)
	(polyline
		(pts
			(xy 453.39 304.8) (xy 453.39 381)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "ab80615d-3694-442c-9cd2-5dfb0937c742")
	)
	(wire
		(pts
			(xy 96.52 236.22) (xy 96.52 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ab8604f0-88ed-48fe-a4e6-772d412af2d7")
	)
	(polyline
		(pts
			(xy 503.047 334.645) (xy 503.047 340.36)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "ab897d72-9735-4f51-84d1-62305c6e107c")
	)
	(wire
		(pts
			(xy 530.86 193.04) (xy 530.86 195.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "abe7f26b-9d3b-43a4-a58c-a581b2711754")
	)
	(wire
		(pts
			(xy 35.56 167.64) (xy 38.1 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ac47a287-21b3-4c00-b568-df6af6e10aa3")
	)
	(polyline
		(pts
			(xy 523.367 316.992) (xy 574.167 316.992)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "acdc7cfa-28b9-485a-b66a-d316d118bcd9")
	)
	(wire
		(pts
			(xy 378.46 264.16) (xy 429.26 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ad5f355f-5f50-4bb8-9dd3-c3129618d6cc")
	)
	(wire
		(pts
			(xy 533.4 264.16) (xy 520.7 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "adcb480b-5e93-4520-a0d7-ed35bda44680")
	)
	(wire
		(pts
			(xy 287.02 53.34) (xy 287.02 55.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ae031b43-616c-40ce-a567-abba2a987236")
	)
	(wire
		(pts
			(xy 510.54 43.18) (xy 474.98 43.18)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ae09d928-9361-4ca7-ac67-aee918e57498")
	)
	(polyline
		(pts
			(xy 254 220.98) (xy 254 284.48)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "ae199983-3430-4a92-8d98-32dfc90e2759")
	)
	(wire
		(pts
			(xy 358.14 261.62) (xy 358.14 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ae31302e-9e0d-4c2d-bcdf-eb3c226cfd17")
	)
	(wire
		(pts
			(xy 220.98 210.82) (xy 220.98 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ae3d7257-eea4-471f-9c50-3cce3043ad74")
	)
	(wire
		(pts
			(xy 104.14 236.22) (xy 96.52 236.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ae47e21a-2484-45f6-b4aa-ee7771e33f02")
	)
	(polyline
		(pts
			(xy 482.727 370.84) (xy 574.802 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "aea85dbe-ea74-477d-9def-7b0cd951edf5")
	)
	(wire
		(pts
			(xy 73.66 53.34) (xy 73.66 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "aed75f3c-b591-4b46-a0da-01fc2e2942b0")
	)
	(wire
		(pts
			(xy 289.56 187.96) (xy 299.72 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "af21790b-1f58-44b2-a684-2aae6b6cd192")
	)
	(wire
		(pts
			(xy 50.8 246.38) (xy 60.96 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "afa35756-65e4-4f3b-bad1-400669e83ebd")
	)
	(wire
		(pts
			(xy 289.56 167.64) (xy 299.72 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b09cbae2-2cbe-47b8-8279-bce2c04fdf48")
	)
	(wire
		(pts
			(xy 223.52 27.94) (xy 223.52 22.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b108a3e5-6b4c-4a97-b482-d55e37054fc1")
	)
	(wire
		(pts
			(xy 386.08 63.5) (xy 411.48 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b173c957-0ca1-44d5-9143-f8dc49cf5acf")
	)
	(wire
		(pts
			(xy 386.08 53.34) (xy 424.18 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b1bf27d8-64fb-4b4b-8910-6b657faf8ca1")
	)
	(wire
		(pts
			(xy 373.38 375.92) (xy 373.38 381)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b2c6b0b9-759d-4bae-a5b6-80979b1b0883")
	)
	(wire
		(pts
			(xy 287.02 55.88) (xy 292.1 55.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b32db99f-4cbb-4e93-bee2-05a634888bef")
	)
	(polyline
		(pts
			(xy 520.827 360.68) (xy 520.827 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "b346c34d-c3d2-4c93-a206-9f8bdf0e4b53")
	)
	(wire
		(pts
			(xy 162.56 68.58) (xy 162.56 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b355c191-9b2c-4d29-9b8f-8ba8409a02a6")
	)
	(wire
		(pts
			(xy 200.66 238.76) (xy 213.36 238.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b35fbe19-d2bc-4b89-a149-811e731d45a5")
	)
	(polyline
		(pts
			(xy 254 299.72) (xy 403.86 299.72)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "b3ba63de-ca36-4525-80f5-291d0e0d89e4")
	)
	(wire
		(pts
			(xy 190.5 264.16) (xy 190.5 261.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b3cf4f47-3fa4-48e8-9669-1e0b0ab71532")
	)
	(wire
		(pts
			(xy 33.02 63.5) (xy 40.64 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b457478c-436b-471e-b88e-6fd676358c7b")
	)
	(wire
		(pts
			(xy 48.26 60.96) (xy 68.58 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b4b1dac8-3ee2-4a77-912e-709557b2f4ee")
	)
	(wire
		(pts
			(xy 93.98 170.18) (xy 93.98 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b4dbe40b-c139-4ae4-b446-2e96a5a658e8")
	)
	(wire
		(pts
			(xy 510.54 45.72) (xy 474.98 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b50d0e81-ca74-4f57-9c53-910ec9f94142")
	)
	(wire
		(pts
			(xy 419.1 180.34) (xy 419.1 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b5a0a3a7-dddb-4963-bffa-547ab56a37dd")
	)
	(wire
		(pts
			(xy 96.52 259.08) (xy 73.66 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b61331ae-2d14-4a38-bf88-a110ebd0aa8d")
	)
	(wire
		(pts
			(xy 309.88 345.44) (xy 309.88 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b65482ae-0bee-44e0-a12c-04ee079523a2")
	)
	(wire
		(pts
			(xy 494.03 314.96) (xy 499.11 314.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b6e137ac-16d7-44c6-acd3-06614df9fc68")
	)
	(wire
		(pts
			(xy 198.12 190.5) (xy 233.68 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b6f089a6-3799-4513-b820-cdd42f9f73df")
	)
	(polyline
		(pts
			(xy 195.58 345.44) (xy 219.71 345.44)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "b777feb3-8ec2-4ecb-8492-3c55f16cba8b")
	)
	(wire
		(pts
			(xy 386.08 124.46) (xy 424.18 124.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b83500b9-16d2-4d3a-9bb9-3a16e636c33e")
	)
	(polyline
		(pts
			(xy 503.047 342.9) (xy 503.047 350.52)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "b91bf573-81b7-46aa-a049-785797f41b30")
	)
	(wire
		(pts
			(xy 373.38 193.04) (xy 378.46 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b9892581-b397-4785-b59d-9f186fbd3e40")
	)
	(wire
		(pts
			(xy 386.08 60.96) (xy 424.18 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b99fdbac-ac5e-4c0d-b104-9910191f10e5")
	)
	(wire
		(pts
			(xy 358.14 248.92) (xy 368.3 248.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "b9af0a82-c68d-4cbe-8f09-18a818eefc37")
	)
	(polyline
		(pts
			(xy 523.367 304.546) (xy 574.167 304.546)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "b9f82bac-2ed4-46a4-9eea-1600d3901c30")
	)
	(wire
		(pts
			(xy 198.12 193.04) (xy 198.12 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ba30395d-9121-4030-8535-543bdf25f72c")
	)
	(wire
		(pts
			(xy 43.18 246.38) (xy 35.56 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ba3af502-e72c-40f1-924c-f341cffb8143")
	)
	(wire
		(pts
			(xy 190.5 383.54) (xy 220.98 383.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ba6dacc7-bfdc-4232-bd53-520a3e3018c1")
	)
	(wire
		(pts
			(xy 330.2 261.62) (xy 330.2 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "baea1f6e-d289-49a7-81db-5cd37045041a")
	)
	(wire
		(pts
			(xy 177.8 157.48) (xy 233.68 157.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bb06ed15-392e-4034-a354-b4636cff679c")
	)
	(wire
		(pts
			(xy 200.66 46.99) (xy 200.66 44.45)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bb08b62d-566b-4cc7-ab00-c4d23f4baec3")
	)
	(wire
		(pts
			(xy 208.28 81.28) (xy 208.28 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bb09a4a8-e1fd-4082-956b-7aed9b10b6a6")
	)
	(polyline
		(pts
			(xy 424.18 309.88) (xy 465.455 309.88)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "bb9d0591-0dd6-4e03-8a41-953e521df256")
	)
	(wire
		(pts
			(xy 274.32 243.84) (xy 274.32 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bb9d6f7c-7b85-4e73-97f4-592c84e5dea8")
	)
	(wire
		(pts
			(xy 35.56 223.52) (xy 35.56 220.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bbf66b4b-a185-4808-87c1-c4f69b66a1c8")
	)
	(wire
		(pts
			(xy 485.14 147.32) (xy 492.76 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bc49e0e6-d23d-4d95-b8ab-80462577fdc6")
	)
	(wire
		(pts
			(xy 200.66 241.3) (xy 213.36 241.3)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bc61e38a-4d20-4d7d-8920-81db17b6e13e")
	)
	(wire
		(pts
			(xy 370.84 243.84) (xy 406.4 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bcbc1020-8616-4017-ac56-fa0c8d6af55d")
	)
	(polyline
		(pts
			(xy 436.88 149.86) (xy 254 149.86)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "bcd741c0-dc33-4d06-8727-677f37dd30bb")
	)
	(wire
		(pts
			(xy 35.56 228.6) (xy 35.56 231.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bd07c887-aa12-4316-885c-78cd2d40da94")
	)
	(wire
		(pts
			(xy 182.88 88.9) (xy 182.88 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bd47c017-bfaa-42d1-bc94-b605efa925dc")
	)
	(wire
		(pts
			(xy 276.86 193.04) (xy 261.62 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bde64507-b4cd-4f2a-8565-d4d722dcd597")
	)
	(wire
		(pts
			(xy 220.98 101.6) (xy 220.98 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf310ead-9c61-4a25-990b-05cf7c8acad7")
	)
	(wire
		(pts
			(xy 284.48 68.58) (xy 292.1 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf5ae6fa-8824-45c4-842f-9817244d3ae8")
	)
	(wire
		(pts
			(xy 307.34 266.7) (xy 297.18 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bf6b9f90-797f-46ed-9e3e-5b7003d3fcd8")
	)
	(wire
		(pts
			(xy 144.78 342.9) (xy 144.78 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "bfdb58c0-9b5b-4df8-879a-67aaf261a8f5")
	)
	(wire
		(pts
			(xy 287.02 370.84) (xy 287.02 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c0aaad5e-a153-4c70-b4bb-8b4b67883e0c")
	)
	(wire
		(pts
			(xy 71.12 330.2) (xy 71.12 327.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c0ae8999-19a9-4feb-a5de-34461401fdbb")
	)
	(wire
		(pts
			(xy 205.74 218.44) (xy 233.68 218.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c13bf498-7f76-4545-8789-a0be4b4d1030")
	)
	(wire
		(pts
			(xy 147.32 200.66) (xy 104.14 200.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c143ff2d-93cb-4e5e-aaa4-56d29bda3919")
	)
	(wire
		(pts
			(xy 279.4 365.76) (xy 266.7 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c14ddad5-4c23-40a9-bfbd-f1484db02b6b")
	)
	(wire
		(pts
			(xy 167.64 243.84) (xy 167.64 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c157526a-6290-498b-a980-95e472f365d3")
	)
	(wire
		(pts
			(xy 83.82 93.98) (xy 83.82 63.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c1624cfa-9a1b-47e0-8379-3944f91450f5")
	)
	(wire
		(pts
			(xy 317.5 332.74) (xy 292.1 332.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c170b927-b84a-4c6f-bbe8-ddd2b063b1ed")
	)
	(wire
		(pts
			(xy 408.94 276.86) (xy 408.94 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c1820ba6-3652-4d9c-a6ef-e62da423ce80")
	)
	(polyline
		(pts
			(xy 482.727 332.74) (xy 482.727 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "c1ec473a-a2d5-463a-8bff-2b6c41016b16")
	)
	(wire
		(pts
			(xy 523.24 48.26) (xy 556.26 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c27dbd37-763d-4d06-ad84-8351d5cb1c06")
	)
	(polyline
		(pts
			(xy 424.18 345.44) (xy 465.455 345.44)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "c290f572-2d6f-48cb-b067-1a70ce283e16")
	)
	(wire
		(pts
			(xy 289.56 172.72) (xy 289.56 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c2f69e23-4ad1-47b7-889d-414d26f7dde0")
	)
	(wire
		(pts
			(xy 274.32 251.46) (xy 276.86 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c3f547e3-7a93-4391-8f92-bf6351833fbd")
	)
	(polyline
		(pts
			(xy 213.995 347.98) (xy 213.995 358.775)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "c46e904f-60db-48f1-bb7e-9b3d05c8509a")
	)
	(wire
		(pts
			(xy 119.38 154.94) (xy 147.32 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c4c4f77a-4acf-4623-a99f-ae4585a53715")
	)
	(wire
		(pts
			(xy 530.86 147.32) (xy 530.86 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c502909f-88d3-4fd4-a096-f1b9352c35be")
	)
	(wire
		(pts
			(xy 68.58 60.96) (xy 68.58 71.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c5101fc3-7537-48b3-96a3-a631a0bc2840")
	)
	(wire
		(pts
			(xy 81.28 177.8) (xy 81.28 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c58d8c76-0208-4b88-a88d-583ee81e744d")
	)
	(wire
		(pts
			(xy 386.08 68.58) (xy 411.48 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c5e0afbd-8ff9-42b7-9518-f2a74100667e")
	)
	(wire
		(pts
			(xy 88.9 58.42) (xy 88.9 76.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c670c935-9b7f-46ba-86a7-3b3f12f9d1ca")
	)
	(wire
		(pts
			(xy 208.28 264.16) (xy 210.82 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c722e51b-82a0-40eb-8b1b-15a0034f06b8")
	)
	(wire
		(pts
			(xy 88.9 45.72) (xy 88.9 48.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c76e2087-9407-4d3d-9704-7b691799c5ee")
	)
	(wire
		(pts
			(xy 332.74 261.62) (xy 332.74 274.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c7a083ac-0c5e-4483-a0cf-7168789139fa")
	)
	(wire
		(pts
			(xy 218.44 81.28) (xy 220.98 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c803c0be-9036-48e9-b095-1a02927f4def")
	)
	(wire
		(pts
			(xy 510.54 78.74) (xy 474.98 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c833ab29-29b6-4415-bde2-b23b095c0d34")
	)
	(wire
		(pts
			(xy 121.92 177.8) (xy 121.92 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c8f56906-4a92-478b-9344-e4f43b2b9492")
	)
	(polyline
		(pts
			(xy 539.877 360.68) (xy 539.877 370.84)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "c933f36d-18d2-4ff6-bade-f09c14a2e1a1")
	)
	(polyline
		(pts
			(xy 482.727 342.9) (xy 541.782 342.9)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "c935f5e3-7c02-4a12-ad54-15fee35acb2a")
	)
	(wire
		(pts
			(xy 114.3 83.82) (xy 101.6 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c96f50bd-b22a-40cf-a009-05509d7dd0e1")
	)
	(wire
		(pts
			(xy 358.14 261.62) (xy 368.3 261.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c979cf86-3910-4d6c-bb56-729ebb5e070a")
	)
	(wire
		(pts
			(xy 332.74 251.46) (xy 335.28 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c9935c5a-644b-4652-a507-9581881129b8")
	)
	(polyline
		(pts
			(xy 17.78 307.34) (xy 17.78 401.32)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "c9cdd855-0637-4594-84df-8dad74122562")
	)
	(wire
		(pts
			(xy 340.36 350.52) (xy 340.36 381)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "c9f7fae6-5691-4fa6-a34c-a4760c37a289")
	)
	(wire
		(pts
			(xy 177.8 175.26) (xy 195.58 175.26)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ca19ed6e-07f4-4c1b-84b5-a8dd7ccfe8dd")
	)
	(polyline
		(pts
			(xy 503.047 353.06) (xy 503.047 358.14)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "ca61b164-8550-4ba4-836e-a7a9e44ec75a")
	)
	(wire
		(pts
			(xy 284.48 96.52) (xy 284.48 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ca7b4eec-831d-4545-aa46-08d20a6b698a")
	)
	(wire
		(pts
			(xy 299.72 345.44) (xy 309.88 345.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "caea3217-c0a0-472c-a52e-d51efc278f44")
	)
	(wire
		(pts
			(xy 505.46 200.66) (xy 500.38 200.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cafe3cd7-3a13-4355-be3a-be6e62e6f70e")
	)
	(wire
		(pts
			(xy 421.64 259.08) (xy 429.26 259.08)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb115953-5dd5-4f0f-bb8c-947dd69c7132")
	)
	(wire
		(pts
			(xy 83.82 45.72) (xy 88.9 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb15b6f9-027b-4cde-a3d0-856dcfdad322")
	)
	(wire
		(pts
			(xy 424.18 86.36) (xy 386.08 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb3b9b30-f29c-444f-a962-8eb5e8c7b44c")
	)
	(wire
		(pts
			(xy 190.5 363.22) (xy 190.5 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb850076-cc20-4def-9356-dd2b9d23077d")
	)
	(wire
		(pts
			(xy 218.44 33.02) (xy 213.36 33.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb92e2d9-ded2-4efd-bcd4-8d7ca9f223a6")
	)
	(wire
		(pts
			(xy 78.74 355.6) (xy 73.66 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cb9755cd-40b0-4844-b9d8-faa4e2096246")
	)
	(polyline
		(pts
			(xy 482.727 332.74) (xy 574.802 332.74)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "cc23273c-d422-4ed2-bbda-576c16224f66")
	)
	(wire
		(pts
			(xy 406.4 248.92) (xy 429.26 248.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cc39f808-1395-463c-8a1b-a148fa2fe29f")
	)
	(wire
		(pts
			(xy 182.88 78.74) (xy 182.88 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cc646ed2-058b-437a-b793-f6a91c683402")
	)
	(wire
		(pts
			(xy 111.76 167.64) (xy 111.76 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ccf23b88-44e5-4312-9a78-6287e86c25c7")
	)
	(polyline
		(pts
			(xy 449.58 284.48) (xy 449.58 220.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "cd72b6e3-d2c7-481f-81a6-ae589ffbe555")
	)
	(wire
		(pts
			(xy 510.54 60.96) (xy 474.98 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cdb7a893-0fbd-4b00-9c84-5751c46813bd")
	)
	(wire
		(pts
			(xy 523.24 55.88) (xy 556.26 55.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cdb7c410-9cdd-4b0d-ab52-a488ac0e22c8")
	)
	(wire
		(pts
			(xy 520.7 160.02) (xy 523.24 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ce0ef0e9-a3b5-4f2b-b794-12f2f377d148")
	)
	(wire
		(pts
			(xy 284.48 193.04) (xy 289.56 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ce106039-3a35-4a4b-8dd7-ee8446dd4e7f")
	)
	(wire
		(pts
			(xy 429.26 256.54) (xy 388.62 256.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ce34fe0a-94cf-48fb-9d2e-a821221c9409")
	)
	(wire
		(pts
			(xy 106.68 149.86) (xy 119.38 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ce44fdb2-d5ee-4b0d-8f6b-5a5ed37f45a8")
	)
	(wire
		(pts
			(xy 281.94 274.32) (xy 259.08 274.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ce600f95-bf97-4450-abc7-ebf0638c3d74")
	)
	(polyline
		(pts
			(xy 17.78 114.3) (xy 241.3 114.3)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "ceab7dbc-589f-4c82-980e-2a4358845621")
	)
	(wire
		(pts
			(xy 104.14 337.82) (xy 104.14 327.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cec82385-8794-47ae-8510-d85c30f06f53")
	)
	(wire
		(pts
			(xy 335.28 261.62) (xy 335.28 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf2d0a33-4631-463b-86da-ccceff813672")
	)
	(wire
		(pts
			(xy 292.1 53.34) (xy 287.02 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf37a42e-09fd-4656-8720-7eb2e2c37907")
	)
	(wire
		(pts
			(xy 177.8 149.86) (xy 233.68 149.86)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf75310c-c1ae-40f3-922f-270e25b66d02")
	)
	(wire
		(pts
			(xy 83.82 335.28) (xy 81.28 335.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf877146-0936-4749-af43-11dd5a670f00")
	)
	(wire
		(pts
			(xy 60.96 154.94) (xy 60.96 160.02)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf99b692-6aa2-4582-bd35-bf83c7259c58")
	)
	(wire
		(pts
			(xy 25.4 142.24) (xy 25.4 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cf99b8e3-25b0-4411-adfd-b8fef59bfd08")
	)
	(wire
		(pts
			(xy 525.78 193.04) (xy 530.86 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "cfc079c0-a643-42f4-b5e1-10ee7489f7a4")
	)
	(wire
		(pts
			(xy 132.08 347.98) (xy 149.86 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d017be79-3602-4d86-b13e-ec7c9840f721")
	)
	(wire
		(pts
			(xy 86.36 215.9) (xy 86.36 205.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d04b26fc-d3bd-4b40-8196-84f4fb9e834a")
	)
	(wire
		(pts
			(xy 198.12 203.2) (xy 233.68 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d07958e9-a9b7-49da-b88c-cfca473c9be5")
	)
	(wire
		(pts
			(xy 297.18 264.16) (xy 299.72 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d19cb4d8-6f80-4728-a096-4de49cfec649")
	)
	(wire
		(pts
			(xy 365.76 251.46) (xy 368.3 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d1b05ae8-75d1-4c03-85be-a039dad23175")
	)
	(polyline
		(pts
			(xy 17.78 17.78) (xy 241.3 17.78)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "d1e2fa8c-7fb1-4cf0-8a3b-686d212a5e64")
	)
	(wire
		(pts
			(xy 38.1 350.52) (xy 106.68 350.52)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d238a8c2-86e5-43b1-8686-bc79ff9c5b9c")
	)
	(wire
		(pts
			(xy 162.56 101.6) (xy 162.56 88.9)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d24a6780-3f42-4082-8bbf-016d7f37e8d1")
	)
	(wire
		(pts
			(xy 220.98 213.36) (xy 223.52 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d277390f-6d57-4b39-b92f-3f4a12c383ea")
	)
	(wire
		(pts
			(xy 386.08 106.68) (xy 424.18 106.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d2d4d689-a823-426d-886e-710990ec8eba")
	)
	(wire
		(pts
			(xy 71.12 198.12) (xy 86.36 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d34e955a-1bc3-4ecf-b29e-adc531a2a050")
	)
	(polyline
		(pts
			(xy 17.78 401.32) (xy 241.3 401.32)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "d3559936-03d4-4dd9-8242-2f4a0d2bfed9")
	)
	(wire
		(pts
			(xy 154.94 251.46) (xy 154.94 243.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d3663a36-0c67-4ac4-ad4d-f3e424052c3d")
	)
	(polyline
		(pts
			(xy 219.71 358.775) (xy 195.58 358.775)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "d374cb55-8561-4a24-bfc3-c5fe749016f9")
	)
	(polyline
		(pts
			(xy 403.86 401.32) (xy 254 401.32)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "d38e9538-2fe8-4429-8221-5b1fd08296ba")
	)
	(wire
		(pts
			(xy 33.02 147.32) (xy 40.64 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d3a9368a-65ce-4496-9f2b-a3af1090b5f1")
	)
	(wire
		(pts
			(xy 523.24 45.72) (xy 556.26 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d3b2155f-7ab6-4efa-a907-a368c569614c")
	)
	(wire
		(pts
			(xy 210.82 284.48) (xy 210.82 279.4)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d40fc8c2-9201-476c-b552-a21626c3d009")
	)
	(wire
		(pts
			(xy 386.08 88.9) (xy 424.18 88.9)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d43d1407-c48e-468f-86e1-d63c27a45d32")
	)
	(wire
		(pts
			(xy 101.6 167.64) (xy 101.6 177.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d46c1f50-fdf4-470c-859a-ec80e5c0e4d0")
	)
	(polyline
		(pts
			(xy 449.58 124.46) (xy 574.04 124.46)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "d4b9939c-635c-48b3-b8c8-6bbcf420bd84")
	)
	(wire
		(pts
			(xy 134.62 83.82) (xy 137.16 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d4ce5f08-89ce-428c-a2a7-ffffe9607bf1")
	)
	(wire
		(pts
			(xy 170.18 370.84) (xy 170.18 375.92)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d4e271a6-8ad5-4855-909b-fcab26a6b37b")
	)
	(wire
		(pts
			(xy 358.14 264.16) (xy 368.3 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d57507cc-0e02-4ec4-9e32-61d6be06fb87")
	)
	(wire
		(pts
			(xy 297.18 269.24) (xy 330.2 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d6827fac-5aba-44d2-9232-a5e89df5fec3")
	)
	(wire
		(pts
			(xy 175.26 73.66) (xy 182.88 73.66)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d69d235c-8f97-4999-ae36-ad372b932c48")
	)
	(wire
		(pts
			(xy 187.96 248.92) (xy 187.96 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d6a2a31b-36b8-4677-bbb0-e6db86b7a8a3")
	)
	(wire
		(pts
			(xy 284.48 50.8) (xy 287.02 50.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d8d5d6b9-4d35-4736-ba30-91fc72727054")
	)
	(wire
		(pts
			(xy 81.28 342.9) (xy 106.68 342.9)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d94473bc-0da7-4573-a667-40bad635420e")
	)
	(wire
		(pts
			(xy 190.5 238.76) (xy 167.64 238.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d95a5996-f8bc-46c5-b4fc-5fe3d964f985")
	)
	(wire
		(pts
			(xy 170.18 68.58) (xy 170.18 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d98ee65f-12d0-4404-bdaa-beb0ab23e575")
	)
	(wire
		(pts
			(xy 299.72 167.64) (xy 299.72 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "d99a3abb-66b3-43f7-92f0-5212ad7f7253")
	)
	(polyline
		(pts
			(xy 541.782 350.52) (xy 541.782 332.74)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "d9ad2efe-1976-4dbd-b8fa-def441864700")
	)
	(wire
		(pts
			(xy 281.94 271.78) (xy 259.08 271.78)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "da33bc14-c8e2-42f6-8764-0b9d1e5f0970")
	)
	(wire
		(pts
			(xy 160.02 347.98) (xy 162.56 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "da587081-e891-4ce2-964c-e5f2b9f444c1")
	)
	(wire
		(pts
			(xy 205.74 213.36) (xy 220.98 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "da58fb31-c17b-41eb-b919-05b9ff64d146")
	)
	(wire
		(pts
			(xy 198.12 213.36) (xy 177.8 213.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "db0972ce-37cc-4c9e-bbe5-5e5dc06b61fc")
	)
	(wire
		(pts
			(xy 518.16 274.32) (xy 497.84 274.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "db0a4c7d-7f40-4954-ba16-fdc8453327e3")
	)
	(wire
		(pts
			(xy 144.78 365.76) (xy 152.4 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dbb94560-e7e6-454a-86f6-71f0b7fa14b7")
	)
	(wire
		(pts
			(xy 508 88.9) (xy 510.54 88.9)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dbd9b40a-9180-4fc8-af69-a25c4d6e85ed")
	)
	(wire
		(pts
			(xy 510.54 68.58) (xy 474.98 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dbecf0d8-fbd6-4a5b-94fe-2ccbff59f31d")
	)
	(wire
		(pts
			(xy 58.42 254) (xy 60.96 254)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "dcd0aa6a-11e1-4cc7-9a31-0b746a65f6bf")
	)
	(wire
		(pts
			(xy 353.06 332.74) (xy 353.06 330.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ddbba139-55fe-48cc-85d1-cba0f1fd193c")
	)
	(polyline
		(pts
			(xy 574.04 220.98) (xy 457.2 220.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "def608c2-ab56-45f2-a83e-c5a4a07abd48")
	)
	(wire
		(pts
			(xy 60.96 142.24) (xy 60.96 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e0134f77-3a97-446b-a2d9-a0451048a78a")
	)
	(wire
		(pts
			(xy 330.2 175.26) (xy 330.2 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e049bd13-b380-47a7-9a1e-d04167a35038")
	)
	(wire
		(pts
			(xy 40.64 83.82) (xy 40.64 93.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e08dbb22-f20d-42e2-9d0a-71b5cda3e74f")
	)
	(wire
		(pts
			(xy 312.42 266.7) (xy 335.28 266.7)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e103ec79-d0a0-47e6-a454-8de7eefef33d")
	)
	(polyline
		(pts
			(xy 522.732 358.14) (xy 522.732 353.06)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "e110b38e-82f2-4c76-92da-14cf7760be8d")
	)
	(wire
		(pts
			(xy 276.86 264.16) (xy 276.86 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e1146237-b387-4e9f-a8c0-f6cf84173d98")
	)
	(wire
		(pts
			(xy 525.78 203.2) (xy 530.86 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e128a805-f56b-4e32-9525-da285560a229")
	)
	(polyline
		(pts
			(xy 424.18 381) (xy 465.455 381)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "e15ed0f4-71ec-49e3-b685-77b7df61a762")
	)
	(wire
		(pts
			(xy 175.26 73.66) (xy 175.26 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e18a7ab7-dcd2-419f-89c2-857d320fcf33")
	)
	(wire
		(pts
			(xy 233.68 78.74) (xy 233.68 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e260c74e-42da-44a9-9a33-86a2f279f804")
	)
	(wire
		(pts
			(xy 40.64 63.5) (xy 40.64 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e2ebf8b5-4df9-4f3a-806f-edec3d9bd250")
	)
	(wire
		(pts
			(xy 73.66 45.72) (xy 78.74 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e31c08d1-f162-45a6-92da-65db02ce827e")
	)
	(wire
		(pts
			(xy 30.48 363.22) (xy 40.64 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e35bc0ff-2481-4665-b819-275cf8bcb799")
	)
	(wire
		(pts
			(xy 523.24 71.12) (xy 556.26 71.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e4543166-db07-45da-bf12-26c36f7be15f")
	)
	(wire
		(pts
			(xy 388.62 167.64) (xy 398.78 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e4e3f8a8-3d54-415e-ac4a-ad2b4cf66680")
	)
	(wire
		(pts
			(xy 330.2 269.24) (xy 337.82 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e50f3ab5-5603-47e0-a03a-a6f0f2392753")
	)
	(wire
		(pts
			(xy 93.98 154.94) (xy 96.52 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e52a225a-85ee-4b5e-8967-6c290342582b")
	)
	(wire
		(pts
			(xy 508 165.1) (xy 505.46 165.1)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e54e813f-46cc-4b1a-8d26-ad222ef2b51e")
	)
	(wire
		(pts
			(xy 190.5 81.28) (xy 187.96 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e550be20-5d1c-4b94-833f-46e2b0120d8a")
	)
	(polyline
		(pts
			(xy 195.58 342.9) (xy 195.58 358.775)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "e55cbec6-1c34-4bfe-91c7-8c36817c54ed")
	)
	(wire
		(pts
			(xy 386.08 78.74) (xy 424.18 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e59d5d0f-5def-4518-83fd-50a1da60628f")
	)
	(wire
		(pts
			(xy 292.1 332.74) (xy 292.1 330.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e6147200-6178-4713-9195-87f1af131426")
	)
	(wire
		(pts
			(xy 541.02 264.16) (xy 561.34 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e63efed9-24b4-48e1-bd7b-0aad6ce965ac")
	)
	(wire
		(pts
			(xy 279.4 363.22) (xy 266.7 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e6683360-a6b7-440f-9e89-736c16af790e")
	)
	(wire
		(pts
			(xy 83.82 360.68) (xy 99.06 360.68)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e68ba144-16ec-46d4-aea8-bc88389614c5")
	)
	(wire
		(pts
			(xy 215.9 162.56) (xy 220.98 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e6d8fe64-da28-4525-860d-e5487a650fa8")
	)
	(wire
		(pts
			(xy 205.74 378.46) (xy 220.98 378.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e6ee47ce-2025-4a60-8ed0-37d273f1dedd")
	)
	(wire
		(pts
			(xy 386.08 93.98) (xy 424.18 93.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e7062e4e-a657-47f5-a585-f1fbc30da313")
	)
	(wire
		(pts
			(xy 83.82 45.72) (xy 83.82 58.42)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e706cc94-62d6-4f86-aa28-4e7182ee1158")
	)
	(wire
		(pts
			(xy 147.32 198.12) (xy 101.6 198.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e70e7da6-3ddb-4273-b31a-ebebb46574e4")
	)
	(wire
		(pts
			(xy 101.6 93.98) (xy 101.6 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e78b33e4-fcb2-4a8e-8182-099358227e82")
	)
	(wire
		(pts
			(xy 123.19 322.58) (xy 144.78 322.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e78df82b-ee23-4b5b-b7e9-ebe911780b25")
	)
	(wire
		(pts
			(xy 177.8 190.5) (xy 198.12 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e7a55dc5-40d7-4ff0-ba36-a8d7a4e5833d")
	)
	(wire
		(pts
			(xy 101.6 154.94) (xy 106.68 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e807d3e3-58d5-4338-8fe4-099f3573ba4c")
	)
	(wire
		(pts
			(xy 213.36 55.88) (xy 213.36 60.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e8088083-9755-49c5-a20a-6ab71cd98403")
	)
	(wire
		(pts
			(xy 55.88 53.34) (xy 48.26 53.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e8b336d5-598d-4a2c-aa53-a850ac7ae13a")
	)
	(wire
		(pts
			(xy 505.46 165.1) (xy 505.46 170.18)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e8f0552a-6666-4f73-949e-eebe07333415")
	)
	(wire
		(pts
			(xy 101.6 177.8) (xy 101.6 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e8f21c85-997d-4b84-b6a3-efc80f657d8b")
	)
	(polyline
		(pts
			(xy 449.58 220.98) (xy 350.52 220.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "e940f71f-c5f9-4234-9ab1-13cf1ad2dbd2")
	)
	(wire
		(pts
			(xy 134.62 78.74) (xy 144.78 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e950d4ab-2914-4637-9aaf-904914d177c7")
	)
	(wire
		(pts
			(xy 60.96 154.94) (xy 66.04 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e9682506-cf58-4492-8413-f28ba7c334bf")
	)
	(polyline
		(pts
			(xy 195.58 347.98) (xy 219.71 347.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "e994f3f0-d331-499c-835a-a502b75cdcfa")
	)
	(wire
		(pts
			(xy 421.64 180.34) (xy 419.1 180.34)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e99cb6ed-071b-4209-bccd-bc0d09adc172")
	)
	(wire
		(pts
			(xy 83.82 337.82) (xy 81.28 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "e9e737dd-9d05-44c6-8261-483f7e75eb69")
	)
	(wire
		(pts
			(xy 358.14 259.08) (xy 358.14 261.62)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ea3ca742-3e48-45d0-95e5-93357f991c41")
	)
	(wire
		(pts
			(xy 177.8 154.94) (xy 220.98 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eab5d4ff-be56-45a4-b3f1-8283f5bd92e9")
	)
	(wire
		(pts
			(xy 274.32 198.12) (xy 274.32 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eabdcb27-e1df-4f5e-b56a-17c187f9f6e4")
	)
	(wire
		(pts
			(xy 114.3 256.54) (xy 127 256.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eb08b9be-b6de-433b-811e-5791ed8462d4")
	)
	(polyline
		(pts
			(xy 574.04 213.36) (xy 574.04 124.46)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "eb693fda-d1bb-452e-a940-fd45b19f1e95")
	)
	(wire
		(pts
			(xy 73.66 93.98) (xy 73.66 68.58)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eb93b74a-f13c-4328-b894-8b2a0bde5f9e")
	)
	(wire
		(pts
			(xy 142.24 256.54) (xy 154.94 256.54)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ebb0a055-6229-4605-839b-8ed3973b2570")
	)
	(wire
		(pts
			(xy 27.94 363.22) (xy 30.48 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ebd7f612-429e-4a3a-96ee-a374803f5207")
	)
	(wire
		(pts
			(xy 208.28 86.36) (xy 210.82 86.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ebe2b4b6-1c91-40af-ad25-0e136d7cf787")
	)
	(wire
		(pts
			(xy 386.08 116.84) (xy 424.18 116.84)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ec4f6b3b-684b-46d9-9761-705709d99f2c")
	)
	(wire
		(pts
			(xy 523.24 78.74) (xy 556.26 78.74)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eccc1799-cec4-4ffd-90cf-7ca8d81c2fe7")
	)
	(wire
		(pts
			(xy 81.28 193.04) (xy 71.12 193.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ecd2ddd9-150a-4c7a-b53f-4a2da29c9596")
	)
	(wire
		(pts
			(xy 378.46 180.34) (xy 378.46 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ecd7f3ad-830c-4cfa-9825-e6fcd3897a6c")
	)
	(wire
		(pts
			(xy 332.74 274.32) (xy 337.82 274.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ecf3e0e6-87ec-43f6-8053-b4d1277ec2bd")
	)
	(wire
		(pts
			(xy 86.36 223.52) (xy 86.36 231.14)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eda46d9d-881c-43d3-b562-6eb644847944")
	)
	(polyline
		(pts
			(xy 424.18 322.58) (xy 465.455 322.58)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "edb45f57-e5fc-4e29-9154-8e3f623b4db7")
	)
	(wire
		(pts
			(xy 187.96 246.38) (xy 190.5 246.38)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eeb1e630-1cc4-4366-99bd-1753e76bc428")
	)
	(wire
		(pts
			(xy 91.44 177.8) (xy 91.44 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eec079b7-0bb5-4bf1-afe9-d76a9308aa65")
	)
	(wire
		(pts
			(xy 386.08 91.44) (xy 424.18 91.44)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "eed1337a-e3a3-4f54-9091-b4ba6677a793")
	)
	(polyline
		(pts
			(xy 457.2 220.98) (xy 457.2 284.48)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "eeea9ab4-9be1-4fb8-8a28-d9831c3f979a")
	)
	(wire
		(pts
			(xy 60.96 147.32) (xy 81.28 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "efb92d3b-3f2d-4d16-9c02-135e55853365")
	)
	(wire
		(pts
			(xy 386.08 83.82) (xy 424.18 83.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f0605e05-37e4-474a-9bae-188688d4615d")
	)
	(wire
		(pts
			(xy 386.08 66.04) (xy 411.48 66.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f0adbcdd-88f2-47df-84fb-cae7d02a9a4c")
	)
	(wire
		(pts
			(xy 510.54 71.12) (xy 474.98 71.12)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f0b912f4-92fc-46ad-9c9e-4b264f14d110")
	)
	(polyline
		(pts
			(xy 17.78 302.26) (xy 241.3 302.26)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "f0cadddc-e797-4beb-8d50-1987d647914c")
	)
	(wire
		(pts
			(xy 398.78 347.98) (xy 330.2 347.98)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f1689585-1dd6-49af-9fd3-b618a4304bc5")
	)
	(wire
		(pts
			(xy 147.32 190.5) (xy 106.68 190.5)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f17ad613-8aa1-4c17-949a-aac6dba245de")
	)
	(wire
		(pts
			(xy 30.48 337.82) (xy 40.64 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f192dd39-28e7-495f-8e2e-f3bc7d4ea29d")
	)
	(wire
		(pts
			(xy 314.96 353.06) (xy 292.1 353.06)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f203f816-2b75-4169-b08f-3eb952bcd0ab")
	)
	(polyline
		(pts
			(xy 482.727 350.52) (xy 574.802 350.52)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "f3691913-6e47-43a8-92ae-b4fb1d0ce9bf")
	)
	(wire
		(pts
			(xy 378.46 187.96) (xy 388.62 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f3990f8a-482b-402d-b15d-9a960dfb220b")
	)
	(wire
		(pts
			(xy 33.02 152.4) (xy 33.02 147.32)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f45c9044-3bb2-443e-89ba-79b02bcf70cb")
	)
	(wire
		(pts
			(xy 386.08 101.6) (xy 424.18 101.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f51986aa-8142-4365-8076-7defd2b6dcb3")
	)
	(wire
		(pts
			(xy 281.94 264.16) (xy 276.86 264.16)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f61106c5-a10f-4762-91f4-37090dd5ac8e")
	)
	(wire
		(pts
			(xy 510.54 50.8) (xy 474.98 50.8)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f64b7948-d51b-4230-97e3-6d3f051e8d32")
	)
	(wire
		(pts
			(xy 38.1 284.48) (xy 50.8 284.48)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f66697e2-f5e3-482f-9ee6-237a6654240b")
	)
	(wire
		(pts
			(xy 81.28 193.04) (xy 81.28 210.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6966687-a712-4415-a953-991a02223bf4")
	)
	(wire
		(pts
			(xy 177.8 170.18) (xy 180.34 170.18)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6b073e3-3ca1-4cb8-8a83-833d4309a9a2")
	)
	(wire
		(pts
			(xy 40.64 355.6) (xy 40.64 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6b1bb5f-2289-46cb-8702-52e6fd1f2771")
	)
	(wire
		(pts
			(xy 40.64 158.75) (xy 40.64 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6bf6a6a-3205-4de4-b563-6836c58994d0")
	)
	(wire
		(pts
			(xy 104.14 203.2) (xy 71.12 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f6f51551-0272-4fd9-a23a-904e914bd491")
	)
	(wire
		(pts
			(xy 177.8 187.96) (xy 233.68 187.96)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f722797e-8d4d-4c81-9e66-45b0a41bb554")
	)
	(wire
		(pts
			(xy 48.26 93.98) (xy 48.26 81.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f7948ba1-d080-4f2d-b95e-d6e2f5d1aa85")
	)
	(wire
		(pts
			(xy 27.94 360.68) (xy 27.94 363.22)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f8a50250-7f9c-4931-bbc4-efe3fe4a5257")
	)
	(wire
		(pts
			(xy 106.68 162.56) (xy 106.68 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f8f616eb-8389-46e2-8009-c84805b56008")
	)
	(wire
		(pts
			(xy 33.02 160.02) (xy 33.02 162.56)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f91762ca-3b85-431e-a171-b701fa8538ca")
	)
	(wire
		(pts
			(xy 104.14 337.82) (xy 104.14 340.36)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f93e49b9-6eb5-493c-98a7-2301b17090d6")
	)
	(polyline
		(pts
			(xy 436.88 17.78) (xy 254 17.78)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "f971aa7e-f63c-473d-9740-25bc9842e60f")
	)
	(wire
		(pts
			(xy 86.36 154.94) (xy 88.9 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f9a9dfa5-57e0-4a48-a103-37f2fd93f979")
	)
	(wire
		(pts
			(xy 419.1 182.88) (xy 411.48 182.88)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "f9e7e544-244a-464f-a6ff-74c3002282e3")
	)
	(wire
		(pts
			(xy 25.4 162.56) (xy 25.4 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fa290c0a-3686-4b1b-a4e2-ed992ad564c5")
	)
	(wire
		(pts
			(xy 494.03 320.04) (xy 499.11 320.04)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fa6a63d1-5d8c-4bd8-ae8e-ccf1647d7f00")
	)
	(wire
		(pts
			(xy 104.14 337.82) (xy 106.68 337.82)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "faafcc05-b5df-4114-a6e4-687afa5b46c9")
	)
	(wire
		(pts
			(xy 25.4 172.72) (xy 38.1 172.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fb187172-8323-4e09-9c4a-b1d540d6d729")
	)
	(wire
		(pts
			(xy 91.44 208.28) (xy 71.12 208.28)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fc26f7bd-d670-40ab-84a2-e20dfa7b7934")
	)
	(wire
		(pts
			(xy 63.5 45.72) (xy 73.66 45.72)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fc5c8499-3d75-4099-9b33-fc30b3075248")
	)
	(wire
		(pts
			(xy 88.9 154.94) (xy 91.44 154.94)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fc7aa89c-1785-4dfb-bf81-478ec4a00080")
	)
	(wire
		(pts
			(xy 274.32 269.24) (xy 281.94 269.24)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fcc70a08-443c-45d9-bef6-bac9f4160168")
	)
	(wire
		(pts
			(xy 198.12 200.66) (xy 198.12 203.2)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fcd2a15a-c35b-480e-adbf-5972821900a1")
	)
	(polyline
		(pts
			(xy 574.04 284.48) (xy 574.04 220.98)
		)
		(stroke
			(width 0)
			(type dash)
		)
		(uuid "fdc111a3-8a75-416f-b3bd-257a01577c1b")
	)
	(wire
		(pts
			(xy 299.72 167.64) (xy 309.88 167.64)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fdfa2206-3c9b-400d-89bc-10e76db25abc")
	)
	(wire
		(pts
			(xy 40.64 363.22) (xy 40.64 365.76)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "fe23d63a-33cb-4174-badc-6faafffcfda1")
	)
	(wire
		(pts
			(xy 403.86 248.92) (xy 403.86 251.46)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ff71da99-e04f-40c4-a2ba-010d84b87ca1")
	)
	(wire
		(pts
			(xy 99.06 355.6) (xy 106.68 355.6)
		)
		(stroke
			(width 0)
			(type default)
		)
		(uuid "ffe16fe3-6fe8-43fb-9b5e-f36b784eb2bc")
	)
	(image
		(at 492.125 381)
		(scale 0.9)
		(uuid "13e41ad4-c923-427e-8df4-f7151351f23d")
		(data "iVBORw0KGgoAAAANSUhEUgAAAbsAAAByCAMAAAD9J4/kAAAAA3NCSVQICAjb4U/gAAAAkFBMVEX/"
			"/////f71z9DofoHiUFbdMznaISjrhYn/+vr75eb98vPvnaDaGCDWAADZDhjaHybbJi3xqazqkZPf"
			"OkDXAAnvnJ/bIyr74eHocXb97e3xtrjdLjb2wcP++Pnsio7aGyPtmJvgRUvhW1/51tfmam7nZWrw"
			"sLL1xsfvqqz87O3hTlPod3v529zkZWnzurvgR0wQlak5AAAWpElEQVR4nO2di5aiuraGiVfESFDo"
			"eEUULfHu+7/dSZQgkBkIlNXNWbv+MfbY3b0gJvlIMnOb0zCaKNRqd7q9XrfTb/3rrDREiP3PHAxQ"
			"/MfGyhrikY1Jr0ewPXLG1r/OTxM0mLjeiMlz/zS4PlDL9SjtxaLU67Qa/aX9DU1nnt1zuFh9eO15"
			"QyvEWtiklxFerhqa178jZI6XOFUf1LZX5r/OFCR/5dEcux6hq3+drX8o5K+DbI0QZ7RpHjyEWlhC"
			"1+sF2/9hk8WcyB+zMxoWdUVmgfxY5fBR/s2S3m8QBjK6Xs/uDwoSBVReI6Uq76eTeiiVRmJKjbtA"
			"jTijnfqNwbivUnsf6+tQWkfTwziryC963F94iZXSI+88UztKlT46jku0soorC1nPfB03ykL2JwWV"
			"Eyey+tprataq3ce1QiyjYy0Pq0qIpu2RrRSOFYzGhSSYDtjLaBSeih4fnIMEnLNcOgk9u500PGTs"
			"ba9M7VNRZfmD7esxdRnt5aGkaGY0CrCmbKe2dTEJkq+ZpL7mnr2Gn2foUt+/Ws5oXJKlxTKbDt4X"
			"sUMt8bOEuvvNZu/24tzSZTLiIePilObM3l/VLc+PlgTqmdMi7qK4ZCiSjSp1aoET1YO3uyXNjjjd"
			"7vtrpjb8giY6Du9e3PKqsbPGnshn52larkQ7pPZdlF2LXQ+Hym7KGtNeaa2XsTN3tj46np5TPFqo"
			"dFyKBHqP9nB82YoE6Qi037TRcYOnGF41dqeLHae7XRgmx7RYxhVkD8VyghY7QvEZzhmat4PS10vZ"
			"oR2thI6PAavq8BDaYNEThVf+L9FZpAh1muiqjY7D8xZFWarILnxVK8Xt2Ni4zuIuw5uIF/XaHUvD"
			"hVbT/Gmog66EnTl1qqHj7aYGPPah2XEFLnfcWEXGXZidOJQfv15sbXS8jrxDQZYqsuvE7IJJvOI6"
			"X8eZeRsrmuzYrNDZSItHVrQFJyGSCtmhq1sVXe+5xFAZHvt2X+XHl1fFmUZHFG8rZ6saOia7AF7d"
			"dreO2Q36gt26YrvjlYXXg+ygNz929dAVskNTt3zABJIkpDK8hJ09mcelv8WlD9x8tqqjYzV9UC5t"
			"V2M3F+MdvsWzqyie3VBvOBdZ1GfHvtZdCh46rR3dOi9iNz3XQcfh0VXFTYDdXrS79ikufRinJrW7"
			"Guh4F3dUZaminTkUI62z5qjQYB1nndrJsKrPjlss+7d5Z15npVOD96tqdoOOfjJ5FXzmYIWMXfFT"
			"bmxWtlzFeFcLHatZotpkq8bOj8TPk2V/N522+jSupqrzu1gMXuceZ82KOpr95fNNJbtBWK/VvfJj"
			"H0qWfNJi6IRhRe0+70KYqUXFP2TsTHSd1ULHpYBXjZ0x2IpqIdjpdJxkXopnqXUVfXa8Q9++OoXT"
			"YatlYIrfV7EbfNVH94Sn7KNkdEP3nWVq7++t1j1p89n5HdrVR0covDxWkZ01TnJAaZDKOHnPRKqx"
			"49t/wxMyBpNlFXRKdoNZDQszna4+PIYus22HbULspBCUZNDta6NjeeouoCxVZGdMO1ANUzybvvNZ"
			"kR0zESbT3aVilSvYnaqmIyesCy/VYcaijvOuTXuTehZER1WS89SFhuGq7Pz7EqibYJtaDazMjk+O"
			"4K2lAsHsTn1tQ1Wdsh4865hHl0kkcFPjJoSO9JylQnK6ILyq7Axr4wS5fNDATRcWYlfyWVEMtuai"
			"t0B28BxD+X2DmXnCKz8/ZR0Lh2cSpLK3uwHolhflDtlFLgTpyt9TZXbGfOPmNqzwNpnbqdhlSgX8"
			"I1CFNMhY+vlahtjNJ2CnUNSLgrMJDm8upZ5HB23bvZPdZNDJDzjtqTLx6YVInyoArzo71s+HmZYX"
			"dLLtGWB3Hg/fumjNvih+DNPaPHJnQmR2pw2wg02Dr2GBNuDqKYM3KbHZtlhte1C83KCkx2x9Aa3O"
			"uVwLkp/O5FwF0vJvDXaGucjkW6wGqdk5s/R/H6ylXheqvDB7fsm6Zb9zmZ0/hA4f4K/C/XVzFUKf"
			"EqHeuqAimJmibHXM/sZhatt0F1ZGx+bxe2DMy8Orw85oBWk4+U9UYkfozDBRItY+1CUXb9izloHS"
			"sr7K2M1vQFPg6FCRzOgLMpNYDtTweKsDs01IgO2gM4lSD7eBDrM3K0bHiH/Jv0DcY2aeV4MdktiV"
			"tDvOLrNWYY3PBT0OfwP3r7mj4eXsTje5OdvFre6pFmjjFsBj6ICOg7Asbd3zbZ078iN3yqw+ynO1"
			"A47BBGH6RFdNdvh77AzrHhbBYyO9ZCqUsxtI7Kh9K68kPiApDJY+WBfyvO75eA+v76tVtMu/I7Ej"
			"Tmmr49p18vBoEGbsm3/S7vjC6Ew9YOAusAZUh52910FXER5fCAOnOeuB/LABsdvroGO5euSq6DPs"
			"vtvunpv/imVHis8L4CRLDXZYs5IM1PqCcsLgtaXayKxhvh/tBesBvIadZ0e1+gKu1jZbQ01hx+zg"
			"NbiASe0v8HZDdXZ0tNPdEWDwFGNeHp4CHd9FVvxYjl2wLTubmGTKGGbNnIb0mVyDoSsPetS+wLeK"
			"qrNzRqb+LvhuD3UDrCdsZ9quqtWp0UnsOpHiQVlR9lxSc9odMuaHc27qw77fieLc5g+zYzMqcPmF"
			"4rRhAaNjZvFEie477FZNZcdkrW7ZglEyVP38T7MzrvDmEQ3eBr31pwuiczYnde/cNHYf6TOZ/E22"
			"1yQubKsZP88OMXjwHkQgrFVro0Cn/OC48uzO/412Z6Bxjt32n7Ez+CoivGpNXvCsDWhcPdEVGEUS"
			"O/27ir/s9DUADZZ4RuYr0RXdUEZGJ7eGvrzsdL0JNLrPbBg7Jbzefoc20P4SR1e81TfOd8TE0VgR"
			"e+m33VXRQHFkgobg1mA5upXcWInTV5Yy9/Ivuyo6tWGDhcAd5rIYHfLB6aA71svMb59ZTfO2wmCp"
			"gc4w1u/ypfKGb3qLdb/trqgk6f+LNVcttEoKyjpMw3gXD49GyQoXWeo1vF92avnX++Fwv+aestp6"
			"R+KD0lZnrEbiGHnvslpNhBcWivtapwh/+0yFzFU7PLtM57CdvWxu9bUub5ajM5Krpt2F5ftWSxxu"
			"xaGWT5Pfdgf/crR3nSCW497SbioMXwMeQ1c+msasmGX5/KvZikc9fm1YQ7/swNTGLn33jIRQN9OI"
			"yuFpoTNiKzPoxjO6gShE91j+8m+fCSf2Jz9bI8tJFp58QiitQAudEV/nSs5Iz9dxsnrGyv9yu1Om"
			"JS128ExmfCf6w6K7H8GyzPfJS+92F98SjgtB/yG7T7U7c/iD7Kg9UagNHeSk2QvLaKh2yMBanZ4z"
			"lvi4EHHaT68Y5g6L8e6u8/rfb3eGNjuExvbPsWNVppBi9p378eFIcTSfdAsdvaUkel42OvK/XsUB"
			"FBxqLWn+C3b97GiiYof8cX7YocojJnXOiRGV3r+XunWVv/6DFPAYurIqEorE/K7nnCd/9k7yS02d"
			"3xnGWo+dD/gvoipvR3XYlYk+nam9fUo9sg0PjSGHZDZrQ9q3mj1RUfxyyDt3jV1X0WSH0EFeJSSU"
			"KE5+/AA7andWlhV9CT+8jp0/5nQEHAHODhWceQ+95NdSjT11wbtQjWVnRC64vnuGu5MfYMfd+fCb"
			"Dm1hMHn6V831hIylPLYS4mrN7hrcZw7gKRRVVODn2QWP+OSI8BHDYH7axTqaj/LwCA3Wmi23se0u"
			"St3Npuk/L/8OO5p40fL7wr/Nl8YlqGpCU2memPhiK1VT2c03SbNjJoP9thgcD/Rk+Xl2OF5JQWgd"
			"v4hvH2dnGF/55bV+mV/nRE3tM5M7SiQg690p5ecBNqB/oN1dps9cobkY8H6EXf6c2ENrWv5UU9td"
			"0mWSbsS//bfLbNha+fx4R7pxCvdHXL32+gdCikj3EbS2EJ5qKrt74ojs6L+C6LTjqncwdE//B+xM"
			"votmmtxrsLAzJRc0tVzMZ9U0dt/vM9EiHsOJK84JC7dqjv2X2PXwch1Fk65I2LHzx0hM8JpzWQVl"
			"1TR232935iE2VYKO2EK+xw5LHO9T7MrWxCixPc9O/GHgMLeuYoQjWfa6WjCF/x67pM/sdUW7E24a"
			"HPtD453GWnTaOw61c55PUYiht0m/gqe/5rH7gJ0ZUTHexTvWfuIQZvsZdtQ7HA+QxvB96eAr2+xM"
			"ZgmDd/KCSnG2msbuA+2uJVw6Eedg+abvJweP8ewz7JwRUtgV1zPg9KnXze5h+KFi65xwH7X68JrG"
			"7gPtbiD8jhCCL9F19b4JYIOO5WV2+bu/Fc48RJI/aUKWWZf/foiVJ/0Ink214TWN3QfaHVqImibP"
			"rZiEDF2Crrw+ys6MHll4hDXjzMNWoWNBii/a8P6D7DLOX2h6B3SitZ7Zc465RCud8Wt9Ld9O6Vij"
			"6+SOaIaFx2u5k/Kr5kSvaew+sY9gLuCbNVt4A+/D7IzTMHSdAOMAB9TtTLJmyqkY3RPefqcHr2ns"
			"PrJ/d5oAZhxZKkIUfJqdYcwP7VvYOXdul3FuK7QU3bOj3+vFXftPsjOul/xROxp0VeceP8+Oaz69"
			"DiQCJy0nutS+acH7b7Izru1MFBJKgq3yyOqPsHtG8Mkvk5y+9O6SUDvUibvWNHafOWvEqntzptwU"
			"f65uBHh5U0cQ/Jl2B+VJ20c/xaFGDJqmscO9IBH5BjtmrPdDl2LbxoGz3W8KjuD8LXZT0LVYD+xF"
			"Gbx76a5Rw9jtto9toocr3WXSZ8dS243X7dns0p4sir38/h12U7jVOSHkvI87RgYjF6TVKHZsRLjf"
			"FylJM50q7LhMy/JR/v5pTn+H3RUe6+hlB/o75VFVygIINYxdmaqyQ6ZZuiv2V9gpWl3vMjDMQwd0"
			"1ypC4ij1H2eno7/B7nqDXQJceJWhFRgMu4e7xcEUcuyItg/GX3YVdL1Bl0zoCx2/tXqD947A2KeJ"
			"8ux0HXQYv+z0tVOgS4KhmtcLeB026A7B5fOX8n5r9W+iGItfdnragWMdDdrviQsa9MHrX9wJozLd"
			"PDunXTATyhYot0f8y06hHTjWUZyt6RMc6a0IXp4d6SqcgkslbueOVJezKwmEo6P/h+wU6HL+ohH3"
			"oQkNeoQqY9DIftqXxfFqRIEn+dPwZeyCjm6LLlAz2NGR2hFwXip0stc2awhHAtL2086Nm6IFpFj+"
			"RrrIUMaOfUBaB2nQNFocx8fDfQfYWM1glwq5XqYWhI44cHwEPtGDYkat4yPyueeBYFFBt2B8fAqZ"
			"Q/m1MnY9EmjAM1vjy3kZBAF1b5O7lI+GsGM9nmYUCchMUQaV8Vdf4AGyoL2bTgfSpwxtKGG3yDLl"
			"/IErwewXbhk0MjsSrEvgocEw5IFN+eFGgvG2H+XGlYawY/C0ore0btBCmDoekB/tgZbHt9Ivl/Z6"
			"nAuRvoDGx2BbBA+hoyOjI+Sc8b4ks3uG2CiEZ+4uDk4dSSU4GwAPGfnAnZ9g50u2djk7Hvu4HJ4C"
			"XUEQNVYDwCEyQp/X0cl5nQnO4R8By5QGW/WEHhmHLoTukQv6IbN7witYKHguL2SNApzOCDJW53ya"
			"Zy3XZ0Uyj3mfKDQfQg6Kw8VPJhR+NwhGR6gn7Wyl37q2oU2hVxTSwH6kQ1Eh/wBO+R/qddCFdATx"
			"hS635g+w462/r874VQ4zRwM31fLuZ6kyiJ7fOrVMOTCuFP8PvEvCxvdCn/YogvbrOLpCawJNwciy"
			"4jdJO2V0KuAFj7bCdc/Glb8mQrbSJv0KijhLCFalO5nMABOZBufERUIEHTom37uViCIgMgGhGQse"
			"WTM4vEFHWRQu6FgRM1PKDEEeoLTAX5w9Sw875gKMbRmoBD0so1NGSVGmG4A5focbm8OBdZzJN4Y8"
			"dDqDA373kCnPLgTrsaAoQYCBimKTg1J0rKAFcUN5+LV0eX0QXoXYz8S9Q7HJYHgaUaWZkZl29xLb"
			"QGDQVf7j3+g1TXme+lQulivagbFbi2NkA0MG9f7oLC5Zh4cyACPp2emrycha6B6CgZPrwgdjFPBK"
			"FdjLh4vFpxcHJkZWyhzEnp1kmI1OtRsespbvUuDUhbkeOWb3bK8wvEoiPa948vWuuXsHnOg9Uwm2"
			"6fIyeEWRusuypED3ioFZ8cJoj+8X/2ldd4tkPzI4Py2HQ/IhEHs/7G+TBkMe+itUOZkL4R2IBM5s"
			"0t7aosbwJRck/PvwWKsrDO+Tlh99pVsePzPlJfcyvez+uH+vD2+pPksIBzAtVjw/8Vt7cW+ctF5T"
			"O1EHbjSdn66JJ0PS1d8vzgm93VyErcFp0Eo817MRPPfsNfxW5/REp78a77fe2zSsm5wtovFWfDyk"
			"k3v2rrZMi3NEoTicQtXh0UC4ADrG/Rm12fTDNERcbopfh4atdeKGsK9dJVkhU9w0CTqvRK9id4QV"
			"K98TT78FjxkZFdCxLmHaFmM+xeOpZVrTMP675Hq1XstjAwR4py1RdXiJJ7pWPMCxPsI3TFNM/vDl"
			"9a2gk7iB6OxrDnimKXwhOu3Xv6CVuDSLJcds6DvwWKsbV5rMoOTbfXknY/+0i51kOqN8SvVaXlB2"
			"BLQqPJI4q97t416Ds0ODOPY1tWOnvMgQjYbujaruLV5K2L0dV4oottQ+SgfM0KBTd8yrjI7p2I2L"
			"Z78GJWTcXrmlI8mythbQDkShKL6XbkJWhEcdUY2rxLEM+xHTEuy8owD1o+zYzwBe5mrC4+gq7zwn"
			"YwYWqzyx115HZoesg3JKqKhn+6hRaT4cD1MlHn8aGQhZm0Dc+Y+MdJ+5jyveEsaKU3dB2jS9d5/5"
			"dKODokDZZ3KdasGr0+re7c6xW9l254yA3UNrUal7SzWBQlWDx+Zr3Dxnk8O4luhyxzOerEvhyDCR"
			"yYwX4TZsua5cLy8hsyvMysczUWMgEqWOZKs8VQceM1OONc57rB5xF4Avp+fZ7p1w8QO6iWfdpv5w"
			"TEd66Dg88ByNqqjOuT3ph11RSXj2nGql5gjcmhnMkuddfR9oOaF90tN0Fqx+WklIZKIInormleHV"
			"RGdMZ8IYo8/L1ldhZ9Iu+Ly/wLpZc0YH7QM3iqiYqsL2nOXbKyuNvTO817ZJ97z/2iYPkLNfb7jj"
			"kXveIZHczi10E3MNOE/yErLOOvcfU6Vh3VO9U1abxOfBMlxvLg8xWff+wM/7rNvUyRpxRpqe/J8y"
			"K7U8vj2Q/DHovIZq/x31mjxXPJOc1J3ecRDvVcdnoskH01PO9yvCI3kn7fpKjDWWyHKZfFbUU7nJ"
			"9BeEqjwupVUJHSuxFGtFU44nJpDKtejaS2Lsmxp7UJo9XHCkAfmPCt+hU99VtJmKT5j6mL2N8g1/"
			"YQN+yiTphT5JaejYZQIG23gl+inwZDhx9E9yA7KA3UjuWaNwmc18eKVlERpVWk3JCtiM5v5aCj5V"
			"09JR9W998WdYqD9/2rZ0xT99LGQA7OYScqtTK4nQVPpNvru/KR7K/ZKipAq1+s6J4pW0F8S64MLZ"
			"hmn6ZapzZxf0GJmRdfRILqPpEz2oJTUSEnTq2imx/Ejyd07tsvNsCveXkL6Xvfs2t15CbNl7RDPk"
			"R25q/KHYzp7tQLv8hrK9r+ZyEpC5w5mPmwZ4UqNX+SG1wtSmIjNTtvOGojP4CtpyZD+9MwSed7nm"
			"l4P9ixfEO9LUoXZQJZKHSuZpPwpe62uUOsTbrj6Q6MfkDx0vth6Jh+VF1kYJ7dpbGgTd2wEYKZAx"
			"/fJGT0thNPqelZLWNBw9E/VGI1d3weGvyR+fPW4deo9D07KWFwL+lP3Pu/F61p5wNwif+ggRG0vH"
			"/Ut7wy2Lpn3ZPD/m4GoZqaz9H5VML+us2caAAAAAAElFTkSuQmCC"
		)
	)
	(image
		(at 546.1 383.54)
		(scale 0.213)
		(uuid "a26e067b-a9ca-4d9c-bce1-003ec56e34e5")
		(data "iVBORw0KGgoAAAANSUhEUgAAAfQAAACsCAIAAAACHsnzAAAAA3NCSVQICAjb4U/gAAAACXBIWXMA"
			"AArwAAAK8AFCrDSYAAAgAElEQVR4nOydd3wcxdn4n9nd69Kp9y5Zkm3JvVdcwDa4ACGUBEgoKQQI"
			"kORNQgl5k/zeUBJCAgECCQklQIDQi3HBBcu9S5Zlq/deTnen67v7/P5Y6bS3Ot2dykmHvN+PP/6c"
			"7nZmZ2Znn5l55pnnIYgIMjIyMjJTC2qyCyAjIyMjM/7Iwl1GRkZmCiILdxkZGZkpiCzcZWRkZKYg"
			"snCXkZGRmYLIwl1GRkZmCiILdxkZGZkpiCzcZWRkZKYgsnCXkZGRmYLIwl1GRkZmCiILdxkZGZkp"
			"iCzcZWRkZKYgsnCXkZGRmYLIwl1GRkZmCiILdxkZGZkpiCzcZWRkZKYgsnCXkZGRmYLIwl1GRkZm"
			"CiILdxkZGZkpiCzcZWRkZKYgsnCXkZGRmYLIwl1GRkZmCiILdxkZGZkpiCzcZWRkZKYgsnCXkZGR"
			"mYJc6sIdESc4oYyMjMwEQGQhVWns+8fFehcXaDsQgtdmJa9KjAlqqWRkZGTGAjPZBZh8Pq5r++OZ"
			"CqACXsQgtlgdy+KjGYoEs1wyMjIyo+dSV8s4Of5ohwFgZGK6zGDudbqCVCQZGRmZsXOpC3cesc1m"
			"H6Fshy67w85xskZLRkYmZLmkhTsiOnn+cFvPSBO2Gi29DhchslpGRkYmRLmkhTshxOB0od0JIxLT"
			"hABAaY8pWMWSkZGRGTOXtHAHgN2NnUCPvBEocqR9xPN9GRkZmQnjUhfuRW1dMAqjF0L2t3aDbO0u"
			"IyMTqly6wl2Qy0VtPUBG3giElHT2jn+ZZGRkZMaJS1e4E0IQsdZgHqmpjJAYOK7MYJb3VGVkZEKT"
			"S1e4A8CBtm4gZGS7qW4oan9r53iXSEZGRmZ8+NoId7d2exzV3BdGN20XIKS42zS+5ZGRkZEZL74e"
			"wh0RCSEtFnu33SmoU8aeIQB83tA+ymk7AFDk84Z2ABi7ZkYoDMtjpbEP5NFCRkZmPPh6CHdCyNlu"
			"Y8obXyS9sWN7Q/vYhZ8gkdttjrFkYWd5G8uNpRhuOX7BYE59c2fea198VNsq6/FlZGTGTqgLd0H8"
			"7WnuXPzhVwDExfGbPym646szLVY7jG2S22yxddgco5+5A9g5rmQMR5mE5Yid4x8+cWHm27vbLXZQ"
			"K6/dfvjli3Ugz99lZGTGRkgLd0H8He8wXL3zmIvj+zc/lYrXyhumv/Plx2Ob5HbanH2uMc27nTxf"
			"Y7KMLq1QtXM9ptz/7H5C8EkpmNsz9A8OFL9R2Tgu2icZGZlLlpAW7oSQkm7Tkg/2W1ysxxSbELOL"
			"u+aLI3cVFRsF74wY6FTXfVlDn3WMnh1dHF9u7JNk6/fuwpV2jn+6pGr2O3uaLDYPix1CEOHWncc+"
			"rmuT9TMyMjKjhv7Nb34z2WXwgjCx3d3UuXH7YSeP3pUnFHWqrXtnS1eiRjU9KtyvKEQEQlC47LP6"
			"tieKqxpMlrGoZQCg2WKPUipyI8KUNOUuto/rCSGEkGMdPXcVFb9QUg005aUABICm365oTArTLIyL"
			"9JunjIyMzFBCce0viLPSHtPSjw5I5+zerlbR9B356c+tnC1c51sUPlda8/S56har3cFyY5Tswt0V"
			"NBWtUt6Sm/bU0gJx+b1di4SQP5dU/e+pcrOwaPBRAEQg5L+XL/pmdrIs32VkZEZKKAp3ADje2bPk"
			"va+ACuyEESKw3KyEqA83LMnR60Rf98tEG8vV91n/W9Py66PnAcD7fHksIALPA8v9aG7enTMycvU6"
			"vVIBQ6R8p81xV1HxB+UNoGQCLYDd8cHWlddmJY9naWVkZC4BQku4C9JwX3PnN3Yf73W4RiaCeV7F"
			"ML+cm/vbhdPd39k5/l8X6z9raNvf0m2zO4Chx1msi0EAjgOGXpkYvTE1/gczMuM1KveP/7hQ96sT"
			"FzssVqDpEWaLf1897/szMuT5u4yMTOCEkHAXhFd5r3nWe/v6bWNGngUATI8K37dlhZqmHz154Z8X"
			"6x0czwt1nBjJiAgAhBCGkM3pCX9cWpCt123afmR3U8coy4AIiJ9cuWxrRqIs32VkZAIkhIQ7ABxp"
			"71n5cRGPw+ygBggiOFkABIYe8TR5fOF5cHGACEpmBAG4veJ0vXPVshuyU8apZOOPeOAZ90FofDMM"
			"3hgZCqNviDd+8Bh1DxyvrhtqDRUqppCI+FVL11VfHB2rZAcAQkClAJVykiU7AFAUqBSgVo5VsgOA"
			"krnxy5P/vFjPh9JgLJ4ZCN3axfMg2tN2m36OLmd3WkKIi+fHMhGRFNXJ8yzPD3fBqDMXN0JQGVpa"
			"dqB9xiKbJBkOfZojKtIobjrc9z4ukzQ+hzwC+i2z364r5D2iKghp2eA//QAJlZk7j7hp++HdjZ2j"
			"CZ1xiYCYHq4tvm5tpEox2UUZBBFfr2x8t6alqLXb7YwhRq1clxx7R3765anxfpO/Xd28p6XL/dRZ"
			"xB/OyFwaHyX8ua+l8/nztbuaOm0shwBqmlqWGH3PzMyrM5KEc16ByzIby/3zYv07Nc0nOno5YfAA"
			"WBwXtTUj4a6ZWVH+WtXOcs+er60cONkAAHol8z+zpyVp1ULmf7tQ93ZVU0m3iUPkARM16msyEx+Y"
			"NS03QjdGsSvGXeUOm+Pli/VfNLaf6jQ6eV7ImiYkLzJsaXzU1ZlJm9MTRpp5t8P5Ulndx/WtpzuN"
			"wjeEQHa47qr0+NvyMmbH6MHn/NTOck8UVzZb7O5vCIEnFs+MVil93PRUp+GFC3XUgA8/DnFOjP7+"
			"whzJZY+cKGuzOdyXUQQemZuXHq4FACvL/fNi3euVzaU9RpZHBIjXKL+ZlfLArOxskYWFBB7xraqm"
			"92tbDrX19DhcQr4RSsWa5Jhbc9Ovzkz0UWYBd1NUGvv+Vla7vaGjxmxBBAQIU9BrkuK+m5d6dWYS"
			"NcKOOl6EinAXZMRt+89MdkFCGMSfzpn2h8UF9GSPf0JPbeizvnyx4f+dLgcX23/C1t19EYFH4LjE"
			"iLDHFs+8Pjs5TMF47d884j2HSl4sqR50z8nxr29Ycmte2o7G9p8dPV/W3gM0PZg5IiCCi82IiXx6"
			"WeG2jARm+FWRW6RWGS3Pn6/5S0k1cFy/rZS7JDwPPA8IN8/I/MnsnAWxkTCM/DI5XRu3Hzna0uUu"
			"aoRGdfSa1cla9d/K6n514gLrdHlkjggcD4g35Gf8dmH+9MjwUTa3qDpCqfa3dD1+tmJXdTPQFFCe"
			"1RFEC/LA8cDQd87I/G5e+orE6OHki/vL0129TxZXvnuxHggFFBlcawoZ8jzwuDQ17rcLp1+REjfc"
			"sGpysos//Kq8xyj6jtTfujE9TOujXu9UN9+04+jgrI7D9VlJX25eLrks/a1djQbz4GWEnLl+XVa4"
			"9sULdY8cv8B5bXyAOwqyfjEnNz8yTFzZMoP5tYqGP5ytAnbYrqvTqh+dn/+taSk+Co+Ih9sNj568"
			"sK++DQgBigICgwXgEThOq1U/OCf3BzMyErTqCRbxoSLcAYBHvOqLozsbx+CpcQqDmKHXnvvmunAF"
			"M9lFAQD4sLb1Z0dLaw1mP3aliIC4NCnmP+sWZoZ7eUl4xPsPn3uutGYwE45/64pFOxo73qpqYjlu"
			"WI0Wj0DgrplZf1s1x/c780p5w6MnLzQbLb6Kigg8hquVP5yR+ceB8woSTE52y46jRa1d7kyStKq3"
			"1y/8n6PnT7R19wvZYXKO0qr+vmruuBxZ+P6Bs69VNLhcXL8o8QEi8LxSoVibHPPsitl5EWHD3f3R"
			"kxf+WlpjtDl9GR8jAiJFU7fkpr24co6G8aLzNDvZFZ8UnXM7XEIkhNR/e0NamMZHMf9b03LDruMi"
			"4c5vykz84splksumvf1ldW+f+zKKwKcblz55tvJAc4evxme5Rcmxx6+9zP3d789UPHOuurPP5r/r"
			"cnxOdPiv5ufflpcuaTrhz58eOffX0lqW43yFhUAEHrMjw/6xeu66lLiJlO+honMHAIqQdy9fCEAg"
			"ZMabUAERWO7zjUvDFcykD8aIuLOx49t7T9aarf5NSwkBijra1rP6k4OCHx7/5afI3QdLXq9sZBF9"
			"7VVQBAh58Vz1jw+dE96WoVpaRHyvpuWuouJmi91PUQkBmjK72KdKqr6777SgfvVbVIuLu3rnsRMd"
			"BqCHz5wQoCmD3Xn9zmOH27vH+GLfvPfUyxfqXDwC7U+y99+advL8zsaOOe/t29HY7nXm/vDxC78/"
			"XWF0sn6EHSFAUTzC6+UN3ztwxskF1ETBg0f4QVHxgdYuX40PoNEoP9iwWPiMiD89Uvqr42WddmdA"
			"XZehq03W2/edfvZcjbuPuZeDt+8//eczlf291F/XqjFZ1n9S9O/KxomcuYeQcEdEvVLxxVXL+pfe"
			"MgKIwOPjK2YVROsndzte6NZlveZrdx2zj8jXMSGNpr6b956ysZx/h2iE9DqcgXYAhn7uTPnrFY1D"
			"i0oIudjbd+u+U06Ok/zWf+iM54EfchfE1y/U/amkOpCbm5yuQE9jEAIUWfPpoWaLLZCcvfJBbct/"
			"qpq83E6oDjdQI29NZ3e6Xiir80yEAPBGZdPjpy+OTEYT8lZZ3f8cOw/jtIswShCb+6y+G19BU++u"
			"X5Sq0wgVfOJs5Z9PlY/8TuT+/ad+eew8hyi4DwGA35y8+GppDUiWL/2qGEHR59mkhABN377/zP6W"
			"rpEXYJSEkHAXXvtNafE/LMiWhbuYlSmx9xfmTLqhlWCycuX2I7ahPiF4BBcLDifYneBwActJnyBN"
			"H23pCnRPxb3I5XhwusA+fLYAoGB+d7q8w+YQN47wefOOo3ZJURHBxaaGabdkJm3LSs6K0IHD6SEQ"
			"CQGaeuho6f7WrkDGIZGGlxssqtPl9fV2cfxPj5QG1AKeCMV4/GwlSiwxeAS7Mz1cuyE98cbctHWp"
			"8ZkROnCy4GIld1+QEPPamnniDAkhFca+2/af9qJS4HmPunBDml2h+Gtx1fPna2ASJ+/DNb677i72"
			"j0sKtmQkAgAh5L81LQ+fuAAKWtofeH6w63p9dgSApj9vaHfLyoNt3X8orgKl5w48xwPHF8Tob8hN"
			"uyItQc3QQ58Cx/M/OlhsY7mJabSQUOC6Ed7JX8/P/6KxvcHsZ1i+JEDUMMwflhR4VXFOPL87Xd7Y"
			"Z/PQliASQgpj9Q/Ozb0mM1nL0A19tneqm/5YXNVpd4LYsJWh/1vTfFdL5trkWP93QiSEbM1O/uns"
			"nFUJMRRF6szWd6ubnyiuNNidAKLjYITUm63HOwzCa+zmqeKqWqPFY2MQIDsi7N31CxfERbovK+s1"
			"f2vPyZJu02BRCQGAW/aearp5Y0CjKaKCpm7Oz3igMHtObAQg7m3tfvJsxZ7mLo73PItHyOF2Q5XR"
			"kqPXjmicFsKQnWzsALXI7ARxblzk+xsWZ3tuZlhc3Mvl9U+erWi3OgTD2TAl88GGRVEikxXh7rfu"
			"PSW1PEakKOrKzKSfz5m2KjGGIuRcj/GZczVvVTXbWNEwSQBo6qni6huyU+JEx7AnAUQVQ383N/O+"
			"wuyCaL2L47c3tj90/MKF7t47Z2XfPytHEKO9Tvb3p8sBQFJZBU0tiY96oDBndVJMnEbl4Pj9LV1/"
			"LKk60Nrl4gbGUYQ1aQn7tq4AAETkEP95sd7mYgc3CRAB8Zbp6c8tnx0hsrn6d2XjPQdLzE6XuK9e"
			"7Oz918WGewqzJmCuFkIzdwFETNap/7S0ELhQMRedTFzcQ/NylyVET7qqHQBMTtd2SWBCRIqQPy0t"
			"KPnmum9PS9MyNCKmh2l+Pie37ltX3Dk9Q/IQEeD1igb/d0IAgH+snvvxxiWXJcVSFEHEzHDtL+bm"
			"1tx0xeqkWEm2LMsVdxvFTWRjuX9XNnqY1fL85ozE6psuF0t2RJwZGX72G2uuz072yJOQdqvjvdoW"
			"/0XlMUmn3rdl5Str5s2JjRDSrkuO3XnV8tfWzlMztGTu1mS2Vhj7RvFWf9bQBrTHmJqgVe/ZvDw7"
			"XCuuOCLqFPT9hdktt2x6dsWsvMhwjYLeddXy9DCtpAud7DSUGsweT5PHWI1q+5VLP9u09LKkWIoQ"
			"AJgVHfHyZfNKvrl2aWI0eCq4GizWA23dI63IeMLzhTH6099Y89LquYLSUkFTV2cmld2w7tV1C19e"
			"PQ8HFCkH27qLu40eaTl+ZnT4zquWF21bdV12cpxGhYgqmtqYFv/l5uW7rlo+NzZCmNffnJe246pl"
			"gradENJld/67skm84UFT1DMr5/x77YIIlcJ9PgMRb81NO33dmvRwrUcfYOifHyuFCdFohZxwF9bC"
			"38xOfnDhdHCyk12cSYXjrsxOeXR+PsBE+U4YHkSsM1srRFbeAAgs/8zyWT+ZPQ1EdofCZ62CeXn1"
			"3G9MS/UQmohnuoxddn/RDTnunsLsO6dnuL9wZxupUvxn/cJEyQtD4LzBLNafn+sx1Zqt4vtOj4n4"
			"12XzwFON4Dbpe33N/JmxkWIVPMvzuxo7/BwZQwTE3ZuXr0iM9vwaAeDmaWmvrZkvWEOKfuMv9Jr9"
			"VN8bNRL31Dxel50UrVZKJoDiveV7CrL3bFl+4to1wuRAIk0OtfVYxRsnQl2uWr7R82iCIKemReg+"
			"uGJxVmS4uC48x3/V0jVpp+oQ47Tqt9YtnBkVLul7APDd/HTxtf8qr/d8CpgRoftow5K1ybHuUBDi"
			"LdM1ybE7r1o+Kzby90sLXl0zT0VTbm37W1VNnHgyjnhlWsJ9hdnCX8I17oun6XWvrJkH4nYmxOZw"
			"fVzXGqRWERNywh0GXrlfz8+fnRh96SrfEWO1mhdXz+7veZNdHEJIs9XeZ3MOfoVQGB9507SUoSd0"
			"3O/JowvyVQpG/BAb+mwGh88YKYhAyFNLC72WAQDiNaptGZIDJqTT7kTAgQywpMdkFgfIJeTb01IF"
			"P24SGSf8qWboh+blAnh0tuIek9nlc3rB412F2QVResmk2F39TWnxS6Q6KFIjHnUCxigpCWKcalh9"
			"iLuOqTpNQVT4UMnO8niuxySRd98vyJoT46UuQtokrfqumZkSLdOJzt5JE+6EXJmWMCtaD976nuTz"
			"R7Wt4Pn9/bNyciPCAACINIm7m5V8c+3D8/LpQTkOAPBKRcPgEgoROP5Py7zbzgIAIq5LjluYHAvi"
			"zRICXXbncEnGkVAU7gBACNEw9NPLCn0cUZnyPDw/Nz1sZMrZoHK+RzrlXBwfFatW+ShhZph2Voxe"
			"/I3B7uhz+dxQQliRHKukht3MZCiyPDGaFncMAl12p/jqI+09Yp2MhqbWJPlS9CPi3JiIWK1a/GVj"
			"n83q2yiIkGuzkmCYJTYhRK9ULBk4auuGH2qiEwDT9DoPWUxTr1U2GhyuQHwDDC2ek+cbJXY7FLU5"
			"PdEt2ryyLjlOcsyi0mQZVW3GAQKwPiUukCv3NneCeF8dUcPQP5yR4TPRYHsONggBACht7xVlBSkR"
			"OuEAgfdCEgIADxRmT4qSOaRF5/qUuB/MyJRo+i4JeH5lUsxPZk2b7HJ40OBpeUYIEQ7+DQchJFKl"
			"SNKqxF8Bx7dZbT5HLBSOufu4JiNMq6Y9um6vw2MqVNJtEq92lDRVGO3rgCghJFWniVN7nJLvsjuc"
			"Pt9JnZKJVil9b4fkRYRRlGSt4OPyYbkiJU6yK1Bnti76cP9fzlXXma0wTHMNVzaW5ztsHi0WpVSk"
			"6PxsjU7T6yTN3m22IUyOdCcEZvjsfm6+bO6UmACsS47TMoxvrYDX9jzT1Tt4BhUAkL8iJW64i91s"
			"TEuYFOEeWtYyEhDx+ZWzdzd3VBrM4+B76+sCokbBDD1+Pem0WT105YRAqs7XyUOBKKVSIs9MvuOS"
			"I6Ro1b4FYLRKwXhKTKenV7EGi02syXJy/D8u1BNCfLzNTo4zeu7xsP40DjoFo2No3y+2n58DAxFn"
			"x0SkROubhYi7A1QbLT85WPKTA2cBERg6VquOUyvTw7SRKsWcaP1lyTEzIvV6JUMP8RbAIfaxHpVV"
			"M1S4wo93nUhJsxMCHMdNnt40QD8c53o89405fmNaHMBohtkKY59EMVVlsvy5pNrls6c4OA6UjIfl"
			"2IQQ0sJd4P0rFq/4uMjDomhKw1DUG+sWqGh60g3bJXCIYolJgGgDMNCUujkjpN3mZ0NVo/CTrZZh"
			"fB/Q7PTcs7Wx3C8PlwD63rsgIw/RNUH6ZqEbPDI/7+6iYskPQJN+FTBil83RZbVf6DYB4DuIwGNS"
			"ZNh1Wcm/mJObFqYRdyceweo5xCooyo+5LSIQwhDPORaBFqttmj6gGfRkUWv23ItGLIzSD3+5L1qs"
			"Do8uRFEHW7oONnb42xMj0uNOE0JIT4eFndWscO18wcjs0iAjXLs4LirUJDsAdDqku0C6ALrsUPlH"
			"+auXxp+vZt+qAARAyYYVIcAwoGCA8fEvmFG6xoPvTc9YlRw77IAiHOqhKKApoGlgGFAqWi3250pr"
			"5n+wv6jVw/MBAjo8z0NRhNA+az/cXUPKB7VXnDwvEb6jPjViG7oHQ1H++hUzKZIdQly4A4BgWHqi"
			"o3eyCzJxVPf2nTeYQ02yw8SdRUQdw4y1+jj5xqPjjoKi9mxevi4lniZkODcDUggBQrpsjpv3nqr3"
			"baXjL7MQ7JCjRrJzMFUJ6UoK0uTNykar3TH13tVhQXyhbFIPdg9DpFKqk3UGYiox5Ln5qxfptjv8"
			"XuPnN0/7S8HrwMj+sRyyXEhNSxFRQVF7tix/c92CTRkJAABOF7AssJx3fyZuCGk09j12pgIGG5/Q"
			"kheKAPHZqsM9kcmylgmcoSW0+N718ZHV0DFQ8F4wsn8cOyGtFtI6d2Gy8Kuj5ydrXTM5UOSTyqbW"
			"VfYkT8u8SUfD0OK+jYBGp0+LdQDwFpZI6zdClr9xHP3JfpWScYhW0FoF89jyWaOYe8aqfUWZmGDc"
			"R65uzEm5JjPRwnInOgzHO3vrzNaGPltDn63JYrPaHAP6mUFXCgAANPX3c9V/WlYYpmAAgCagVzId"
			"oqm8g+N8G/ULrScd7RATNKHVS4eSEaap7hXtqRJS22dZDtE+E3knRavxEO88vzol7qacFNdIhDXH"
			"48rE0dx9pISucBf68RNnKzxsjy4FCAGavu9QyX+vWBxSmne9xJU8gp/jSAAA0GFzeNgJIMZrfZrc"
			"EWi1OHzvfXY5nKxUZexxQapOXW20uP9UUOTO6RlhoeEKfyy4O4OKplU0vTEtYWOaNNxSh81xosPw"
			"TGnN7uZOD4c5hLxW0XhPQRYAECBKT/MzlkeHP5tjO8uxkvUQIYLPieF6KfI8D+i7Gwd7hZqj1+0V"
			"34IiR9oNN09LG8XLlaxVeyiweJwRGfajmVmjKNWl6FvGDSHEznEvltVNghGk4BVWcOA5Kf6Haeqj"
			"urZmi2978IkmVacR92weoNpk8XE9ANhZrscuGgAQgZB4jZ/pcJW/bFssdqencI9UKsRNlRsRJn5q"
			"Lh49HSd8LXH7LfF9QbxGtTkjcdfm5VvSEzxUEoQcausRPiooIlmUGJ2uDn/HJhv6bBLDf41WTURD"
			"DkqKRwiwXIvF7rsb1/ZZg3oCe0VCjEc7UNQHtS0wql2Eguhwz6zI/pZuGNX4dCn6lhHzWX17q9U+"
			"odP2fk/fqGHoFJ0mLVwbrlS4v5y4YgCwiM+fr53IO/plZnS4x5oUsbjbaBl+LY+IrTZ7pclDqqpV"
			"inCFwtfLQMhXrV1SMeFJmcEkkTJhCkbcS+bHRIqLamO5A62T6uJqPHD7LfF9HhIGmu7egmyPA4AU"
			"Kevtj5GkoKgUrccZBaeLO9XZ61tInezqlahuMsM14rdTx9Bqic6Not6taQafT3Nfc3BdnF+blSg5"
			"/9Vpc37R2O47lbvA4pKn6jSUUrSdQ0h5t7HT09106BCiwh0RWZ7/pL7NyQb/ZBcicFyUUjE/NuLJ"
			"pQVfbl2JP7rWeufWpls2Nty8wXT7Zrzr2sPXXvaPy+Yti49K1Ki8uLcOTql2NnX0Olwhsq2KiJlh"
			"Wspz8+NAa/eZbiMMeXXdLvTerW5pNlrE87JUnSZC6dMYhpAek/X9mpahUkzI1uJiP65vkxQuUasa"
			"3A8kZGlClFhTg4j/qWoWBJOP9mR5vjIkJ/hCmauMlqQ3dr5YVidMM/x2DIuLlSi33EaoSprKjfCM"
			"HE2Rv5bWmJxemkj408nxr5Q3eGjDEOfFRogPHNAUUVCekdRo6tnSmm670+vTBICSHuPprt7gTeAQ"
			"Ua9UzPH07sLy/J+Kq4WAM0Ob0f3NE2crjrT3SPrqjTkpg1kRAhT10PELvgsAAD12p7CLO5Gvc4gK"
			"d0JIt8P1n6qmoK7XAAB4nqHIg/On79my4sS1l/1iTq7gsELyDJYlRH9vRsbha1bv37riqRWzYwUR"
			"H2ROdxiKe4whMikghKTo1B6x5AlhOe6mPSerjZah3rgIIR/Utj58ogxoSixiciN0CX49gCuZHxYV"
			"15qtYongdt/62NmK0+0GSYocvU7sAqQwKjzVM27n8fbunxw+B95mvsKfPOK9h86t+fTQJ3WtMLEv"
			"oW+Eijdb7Ju+ONLWZ/3RgbM37T3pDk7itZzCT787Uw6Mx7H7dNGJ4kXxkSrxUE1Is8lyw5cneMSh"
			"zQ4AvzlV/mWDZLZLLkuKFXk1RwDw6CEAQAjP8Vt2HDU5XUOz5Xi8u6ik02ofRbMEiFD4O6dnSFbe"
			"e5o77jpYDN7UI8I3Pz507qFjZRs+P/xaRSOI2vnumVkgnnFS5N+VDYKeR5h8uH9xO9Rrsdg27zh6"
			"5Y4jBoeXQS54hKhwB4AXztewvn3yjR0e58RF1nxrw+NLZs6LjaBE7T6cSM2PDP/prJyqmy7fkpUc"
			"XEUNIYDwl3MhZBOZotMsio/0mJcR0txnK/jv3lfKG8R2FDaWu/dQyfVfHud5jyPXhJBtmUn+ncER"
			"0utwLvvowMG2waM3hBCLi/3OvlOPnaoYEseZzI6OEJ+NytLrFsRFiZfPQMg/L9Zf/vnhXpGzLXfO"
			"57qNM97d81JZbYvFdt3uEx/VtU7kS+gbQkiLxT7j3T3Vwtl3Au9VNye8vuN/T14UwhYOTWJ1sdfs"
			"Ol7cbZFMTzsAACAASURBVJIcu78mM8n915VpCdEqhWSWvau5M/vt3cc6DOJmb7TYln984PEz5ZJm"
			"j9WqlsZHia8EgKszk6TrWoo62t6z7KOicz0m8cXHOwzJb+w41NY9AXrXK9MSUiI85iUA8Fp5Q+qb"
			"O/e3dEnKu7+lK/2tXUKcqT4Xe9v+029UNrn7w9yYiAJPb7VOjr9u1/E/FVe53a65xTqH+GxpTcqb"
			"O4+29xS1dOW9s6e8d+KOsIRKD5bA8cj84xOAoHljQGQo6seF2U8vK4QR7ly7L36utObhExeC6xfB"
			"7my5c2uSTh0iZjPnekwLPtjv4jwDDCGCi9Vq1SsSovVKRWOf9Xi7AXheepqf53MiwypvvFxcER7x"
			"/sPnniut8dKGiOB0ZcREFETpVTTVbnMcbusGnochlpSxamXRtpXTI8MH0gkBVM0z3t0rdejB8QxD"
			"35iTsjwhOkWndnJ8qcH0UV1bSWs3KJh+TQ4iuNgnVs25ryBbfJTR5GS37Dha1NrlzjBeo9y3ZeXM"
			"KF8uyV4sq7v3UPGgAxaO/9Gs7BdWzvGRREKVsW/Fxwc7bJLNJwSWB5remBa/OD4qK1wbo1LwAK0W"
			"+5GOnvdrW612p0f7IypoynrHVsE5jNBEr1c0fnf3cZAaQQ02u5ImFUZLWYcBaEpq18Dx352R8eqa"
			"+UMLHP3adoPdKX2gPILTlR0fVRAZzlDkdFdvvcHs/VQwx2/KTPziymWSr6e9/WV1b59b20YROHHt"
			"ZfNjI6XJh+Hnx84/daZCWgtEcLH6MM28mIholdLGcsU9ptZeMygYcdOBk/3D6rkPFGYraAoRny+r"
			"/fGhc9IbuNgEve7W3LTC6PAYtbLT5jzd1ftudXOH2QoM0792RYzXqt5ev3BtckD+LMdICBmHCaYA"
			"wpv/ZHFlv3QIEhz/z7ULvpOXBiO3SXKP4fcWZs+O0a/97HAQj7oombsOFn+8cQkhRJgQTKKIR8RZ"
			"0fq/r5p7++7joFAM6loIAaXC6mJ3929SESDgJXYwRX2+aRkZ4sRqWAgBlbLebK13G88QMlSyA89v"
			"TktwS3YYeEDTI8NfWDn77j2nQOzchqZYnn+zouHN8vr+HVfBKlwpepkJAaXiwSOlMSrl90QBQyYL"
			"nYJJDVN3WGzg4R+AAEMD4s6Gtp31baI1ykCNxO2PCBz/9Mo5DEXc2i0A+E5e2oHWrn+W1njId2mz"
			"Ey8imOMzIsJeWjUHPF8f4fOrl827+rND0hCjFAG1ssbYVyPEKiHesg0mTyye+VVL14m2bo8uRAgo"
			"FSaH66vmTtE3jMdeBSHA0C+U1f58zjQAIIR8f3rmvy42nOns9bDAVTDtVvtTZyo81osUAYXH7Tos"
			"9nWfHmr/zqb44J8PmAS1zFCNJ4/IIXI8jwDbG9rv/OrM789UBEuyIwLLvrJ+4Xfy0oZGmQgQ4fVA"
			"xNVJsSevXe09cPO4QFGfNbRdt/v4f6qanBxyiBwi76nag4nS2whVvi0//X8WTQf0Ft+dooCihuhM"
			"+sfsjzcuyY8M8y/ZEYW55aDw7c92iFcvROAxVa99da10/igU9QczMu+cnSM9qd/vgIUGhgaGBtqz"
			"wAMmsBvSE0JBsgNAklZ96htrtmQleQ263e9MhnFXh5Y2FCIQsiEz8Y78dEnjI+LTywpXpMZ76b0+"
			"n2a0VnX82lUqmgbP10do9s3pibcWZHtXWrqzJYPZ9j/uIEMTUrRtVZo+zItxs7SPebYe4swYfcWN"
			"62FAq66iqa+2rgwXlFqSruXxLLzlBuSTTUvjNeoJeGcnaOYu7lXCByvL1ZotnTZnfZ+1uNtUaeo7"
			"0mboNlmE2Lte3uTx42fz828b0tFHgdCV58VGvnnFopv3npJqAMYJnscPqpo/KG8E5NVa9eqk2Oxw"
			"7fzYiMxwbYJGJfh3lbyxwZvdCzk/sajAzvLPldYAz/s5hYAIPK9Xq55cWrAtIzGgsiH+fsnMXY0d"
			"+xs7/LhpRJwZE7F3c3/k4qGadBrgrytmI8C/LtQD+ivqQJ4qhrl/VvaTSwq8ZjvxCGX4dNPSV8sb"
			"/lBcdaHTADQtPbU1HDwPhHwzO/nl1XOHuvAkhOiVig82LL5pz8l9De3+nWIiAsfnxehfX7tAEE9e"
			"dyNpAk8vK+i0O3bUtgDtc3rO8+l63S3T0h47XR5s0wlBKB++etUdX53ZXd8WkAdQngcg385NfWn1"
			"XAVFueuLiOFK5vz1667eeexMhwGoAE5ZIgLHZ0SG/WXZrK0BvghjZiKEu7smJd2mi72mg22GE50G"
			"s4vtsjvNTtbqdPU/V8nqODgURut/PT9/vBpXkO835qR+XN/2bnXz2DP0eo9+t66Idpbb1dAGAICg"
			"VDARSiZapYxQMrkRYVemxWeG61YkRru1RsHrPTRF/rJ81raMxNv3n2k29g27vuZ54Pj1mYl/XT57"
			"RlR4oEVCzArTfrZp6bPnax4+WuZFOydM6p2uq/PTX1o9N0GjGu5pIqKGof++au51Wcn3HCqp6zF5"
			"0R274Xhg2fVZKY8vnrEoPgpCQ7KDqNFuy0/fnJ7waUP7b09ebDCYgfGY/3ogzChZLjcu8i/LZl2R"
			"GieWTZ4XYrxG9cnGJf+8WP+zo+c5F+td6iEI64Yfz5328Ny8RK0ahn+aiBirVr13+aIXymp/cbgU"
			"AL2swhHB4VqdlfTvtfMnxi2gUNrUMM2HGxZ/WNd6z8ESk9U+fNdFYLkZ8VHPLC9ckxwraT3hFUsL"
			"0+zbuuKFstqHj10AFztsVojA8UDILxfk31uYLYRAmJh+NRHCnRCy4fPDu5s6gMdBXwLu6k2YhzZE"
			"AHh88Uz9EAdYY0GYqvx24fTtDe194mhe445nuzl5vtPu7LQ7AeB4h+HNigbBX/mMGH3Z9euDVYYB"
			"KIArUuMbbt7w9wv1fyyubLbaEdG9EKcIAcCVyQkPzc29PHXEe0ccok7BPDQ379bctPsOlXzR2MEP"
			"ZE4RoAk9PSrsxZVzFsdHuQ3qveYjfE8RuCo9oTb9ivdqWv5yrvpkZy8A8AOqLEKAIoQhZENm0v9b"
			"OKMgOhxEZpeeuYGaprSi01JahvE7gVZQRMcw3MAa3EVJz/2PiFi18o789Dvy079s6niurG5fc6eT"
			"5zmRlo4iQBGioqmViTE/mZUjtuv12krClzqGvn9Wzm356Y+dqfhXeYPZxfLo0T40Iddmpv7fohmZ"
			"4Vq/+gQhTy1D/3xO7o05qT89WvpZXRsO+KUhBGhCUnSap5cWbMtMAoBTnUa1gnY7MnNSRHoSCkDI"
			"UHwZRYhf39Fe0TL0Lblp356W+kp5w1MlVbUmK4p85lCEEIAZMeGPzs/7RlYyDNN6wp96BfPQ3LwH"
			"ZuX84WzlPy7Wd9udPIqzAooQvYK5PT/j53Omxaj9BO0adybCWsbsYvV/+xBUioncP/ECzy9MiD5x"
			"7WXgL2rDSBFkwe37T796oX7ixqphigIO157r1q5L8RUydJxuNShV262OcmNfm9XOA6gokqRVz4mJ"
			"EExNfC8jvFjLcNwbly+6OXfQ9YeV5U51GpqtDopArEo5MypcmDkGPrMWX2lluYsGc4vN3ufiCECE"
			"kknVaQqj9UOvHJoJDwAeh3QJ5W8WhogSV4IERimVvJaw2mSpM1sNDieHILRPsk6dLzIcgsDmieJs"
			"q42Wuj5rh91BgIQrmIywgNrHR55Ojj/RaWi22hEhUsnkR4Znhmvdl/GIGEATcYiejQ8USAfgkRYM"
			"ALrtzgpjX5vV7uBRQZEkrXpmZFikKlCHceKsWq32GpO11WoXxvJ4tWpahC5t4LzFxC8EJ2TmDjDy"
			"GDdBwMm+umYeQJB04/DSqrmvnqvxsgE1kQgTrQm5v/g2CVpVwjDuwEZdGndCLUOvGhLeekSvivhK"
			"LUPPj4scasHndbYuyYQGGNG0QMiTHpJkLO+5xDQlR6/LkZwbEv06uibKidDlREjzHGmG7jwRUUlT"
			"KxJjvGaIiJRk11H0q/hPOoDLRlQwgRi1cpl69D4a3XUkhCRp1T48uU68ii90DzGNM4gzEmNmRoYH"
			"Y/wkhCCAkqa+kZ/+NfBvPSUIxkMc3wx95Dle+z2j/nXcbzeKhML3ATZRUFty7IRIMSRcMsKdx83p"
			"CRC0xyBken12MgxxXy4jIyMz8Vwywp3AEtFR6SAxOyZCqVJOgNGuzKXAcPthoXmqXCbUCKETqkFF"
			"o1DE+/VXNWb0CiZZq64z+3FHLiMTCETwEPDZocETpDy/Miu5aNvKSS2XzNeDS0W4hynoKNV4WkB6"
			"haGImrlkFkMywUdJUaBSiIW7TnEphZyUGQOXiiRSUJQq+BGdlBSlu6TCvcrIyIQql4pwh6Fhy4Nz"
			"D9lYRkZGJhS4VIS7g0MrG/TwGi6en4C7yMjIyPjlUhHuZper2+En/u/YcfK8hQ1ygBEZGRmZALhU"
			"hLvTxbVZ7cG2ITM4XE19QYwZJiMjIxMgl4pwBwJFbT3BvsmRdgOwwfQdJiMjIxMYl45wJ+/VNGPQ"
			"DoAI2b5R2TDJjsNkZGRkAGCihHsIWJAQ0m2y7G7qJEEIfCz4q2m12A81tAcUESK4hGhcXBkZmYlk"
			"IiSRTsGAwwUsN8l+V5SK7x04A0FxL0MA4KY9J6WxhicYRGA5cLrign8Wd8LwOlCNbvTykWq8hsOR"
			"lnYcaxcK+C558OoVSM5TrKkDIejCSJjV7rvp8g/rWr9q6SruNgo+FN0/93+YAD01IU19tqfPVf90"
			"Vs44+oYUstrb3HmswzBB03ZJ2MaBL9PDNZvTE1cnxcyK1odIFKExIrx7RqerqLW70+5EhCiVYn1q"
			"rF6hcDuM9VFNtzdz94dyg7m4x2QZMFelKZKr182K1msZGkQX+8hzaDB0t+dxIWGVyXKy02BleUBI"
			"D9esSox2R+cY6sYWAAwOZ1Fbd5fdBQgxKsX61LgwBRPI45MG0gWA/vjYfhJKquDXuXyANxKusrDs"
			"2S5jrdnq4oWI9xClUuRF6PIiwtzhucGf3/zhbif84uLxbLfxvMEMADQh82L1s6Ij3P0BhnhFdn+o"
			"MPad7Ox1cDwARKkUyxOi44QAGoSQkAm8NY4EXbgLLb4mOXZNcr9L7nM9posG81dt3a0We5XJYnS6"
			"GvtsvLAP2R82jAQroCIhz56rviE7OWV4t8ujwM5x/3vqooPjgjhECYHThKgGFEkN14YrmBy9Llmr"
			"Xp4QPSMqfGFcJDWkT39NEd5tg8P5TnXzSxfqz7Z2AQwMY4gAsDA57r5Z2VelJcSolT4CrwiN0GFz"
			"fNnc+WZl0/bGNnC4gFAeCRABISkq/IqU2Gsyk9ckx0T5DNRAv/gRuETWrnYH/uIWAKg09r1R2fTS"
			"hbp2Y594xKWUiutzku+emb0qMVosaIxO13s1LS+U1Z5ukdSOrM1IvLcw68q0BI3P086NFlvGy596"
			"zCeUzL5tq9wvmlcsLjbpjZ1ms1X4M0Kvbb55o87nivNAa/eaT4rAKao18g13bksL0yAiAQIELhjM"
			"H9S2/Ke6+XyHQRowQei0NDU7IWpreuLm9IRlCdE+BtFdzZ2bPj002MiIC9MSDl69SkWT/a1dL5TV"
			"fVDTwjucgxXnMVavu29W9o05KXkRYaLbIiGE5fmDbT2vVTS8W9NitdgGUyECYmZs5I05KddnJS+I"
			"i/Q7rn/tmKAwe8IHoe1mRetnReuvz0kBgE6bw8JynXZHc5/9RGfvkY6eEx29fVYbKIIVTLXeZP3h"
			"geLPr1w6Lg9SyOTRExcOtnQFS7IjAsvRSsXCuIil8dFLE6IzwjQJGpWWoRM9hyh3jb7uHVTL0Kc7"
			"e7+191SFwQwA0s6AeLKj5zt7DHPiIv65et6CuMjhooMSQvY0d95/+Nz5biMAACHgVXAjtlpsr19s"
			"eL2yqTAq/LElM7emDxvCOEyt6BuyZ/6fqqafHi1tM1uBoiSl5RHfqWz6sLbtO7mpL66eK0RuqjVZ"
			"t+48er7b5LV2+5o79rV0rk6KffvyhcOF8UPEeLVqdXbKgVZRx+Ox1GDyLdwPdxg4RFD3t4OLxyMd"
			"hstTfIVCLO4xARB3EkBcnhgT5w4aR+B3p8ufLa3pttiBEB+hREs6jSUdvX8+V70iIfrNdQvihgl+"
			"q6CITqWw0INSWK9kVDT1nX2n3q5udrGc9Dkidtkdvz52/sWyut8tnH5HfrpbTBscztv2n9nR2OF0"
			"sUANefoIdSbLk6fK/15Wtyk9/qVVc8MDWzN9XZhQHfHQVovTqOIAMsI0i+LINVlJwpeH23o2fXHE"
			"7ArOaSCKbK9tuXXfqX+vXQBjmOTiwFLxb2W1T50qD562naGol9bPu2N6xuCthynzFOmUhHzR2PHy"
			"hTohqpTXCwTxUdxlXP5JUfF1a6Z7i8FCCPmyqfOKzw8BgB91mZCQJgBQ2mPatuPYRxsWX52ZFFBp"
			"KfJRXeu3dxwFBQPeIn8KpXWyXLJOI3SYiwbz7Pf3uTjed+0OtHbNe2/fvbOyvcpKQoiKptamxB5o"
			"6RIvRA60dt81I5MZpr6IeLS9x+p0uRvE6nQVtXavT44drvO4eP5Qu6cNMcIVKXEquj/i1zd3H3+/"
			"sgkY2o+dGBGW48TKcrubOua+v//AtpU5el0gLyBNyIqPiw63dHmPby4kp6hepytVp3HPbzpsjpnv"
			"7u22OYAi3stGAIAATQxO138qmsp6zF9uWRGrVk4Z+T7pph0AUqmEyxOjVyXGBNErOkO/cbHhnoPF"
			"LD+opxsRiCiU+K+lNXcXFQdxHxUxNUwjluwwZYT4cFDUy+drA7qSEKeLXf5xUZvVMfQ5Fncbr/ik"
			"SLhsBHcnBBCv2XHsbJcRAtlwUyqu3XEUlD7jA3P8tqykR+blUYS02xxbdh5zcbz/UhHSbnM8evQ8"
			"DKOcIYSsTIzRKkV9j8CB1m4eh908dPL8jsZ2j1sTsqe50+mOhz0kCYd4oNVj/NAqmRUDKqaHjpe9"
			"X9U0XAl9VK3FbL1t/2kuEDFKyO6mjsOtXb4GD0RAfGpp4ca0eKEijX3Wwv/u67bZvY+gQ6FIcYdh"
			"4Qf726z2YBjUTQohIdzFCK364NxcCKqTFoq8cL524/bDZic70mfpHthv2XvqgcPnglZEAADg+AcK"
			"s2Gqb+tLEb+QiMDzwPHeXbJRlMHm/M7+UzBkzMsO1909OwecLo9ZAs+DiwWna+AfCywHPEr3qAnc"
			"sOfE0Dy9I9KwAyJwPPD8YIYcPysu8r+XL1LSFAA8XVJV3Wv2ItkRgRelxYGcfa45lidE6z0nFu3G"
			"vgpj33ALu14ne1hQ8Ys41NJpcDiHS1Jjsrb19om/jFAySxP6g47ekpuapg8DTvSqIgLHeTSyiwWO"
			"k87VKHKwseO50hoIsG+Li9ffHwYaGRFY7s8rZv9oZqbwu53j7j9c2mmzS1tP/PTZIUVi6HqT9Zu7"
			"Tzg5fmrMn0LOn7sgalclxSTpw1ottkAH3pHfBgD2NnfG//uLvVtWLI2PggBUNO4Lak2WK7Yfqe7t"
			"C244bEQg5P5ZOQBTZJ0YKAO7i0qajlEpVyZG6xTMRaO5uMto43jpfh1FjrUbjrT3LEvwCHMcpqCf"
			"XzlnZlT4z4+et7EcAChpem1q/A05ybOiIwTdd5+LPddjeru66URnr4MV7YcTUm+27Wrq2JAaH1Bp"
			"EYGQMAWTrdctios0ONkTHYY2m93F8UnhmgNbVwiSnUX8w5lKaYdBpCgSrlTMjAovjNKbnOzZbmOj"
			"xWYV1JI+bYG0DL06KebdqqZ+KUYIUNQblY1PLCkYaplDCHmrqgl4FBRQg4Xn8dXyhgfn5XlN8mZl"
			"I1Ci6PY8rk6MFXTTAFAQpW+4ecPmL45ub2gTcotUKb+bl7Y+JS5JqyYAFCHNFvvBtu53a5rrzFZ0"
			"PztCgKEfPXnx/lk5gUzehQIxFKVl6MXxUTl6ba3JdqzTYHK6EOCmGRn3FGS5TWVOdfZ+WNXkMdNH"
			"ZChqbVrCD6ZnZOp1CHCkvef587XVpj6OF3Unihxq73m7uvnWvLQp8L6FnHCHgenSsytmXf/5YQhq"
			"hA1C7Cy38uOiewuyf70gP0bty0xCKJiD454uqX7ybKVRvF8fJDj+wYXTAaTS7JKA5xcnRv9+4czL"
			"Uwf3+jpsjqdKqv54pgLAQ+qZHM4Drd1LPcMoCp/vKcjOjQj7yeFSg9P1wRWLliZI49yvToq5pyBr"
			"f0vXDV+e6LQ53Nk6ef5ga3dAwh2Roai7C7J+NjsnPUzr/vrT+ra/ltY8OC83UtWvxv2gpgVYFpQK"
			"cVoVQz86P/++guxwkYKltMf0yIkLn9S2SGoqRqjgvQXZ75Y3DHZFinqrqvmJJQVeA0w/e67Gy8YA"
			"TT9fVvfgvDxpEgAAeKOq2aOfc9z3ZqS7MxTq9fmVS/9wtvKRExeuTEt4c/2CcM/FxLzYiC0ZCU8s"
			"mfm70+X/K9YyEWJ2us50GefFRnitoAeIMWrVE0tm3pmf4S6mjeX+VFK9t6XzxZVzFBQFA4uAB46U"
			"esy6ELMjwl5fM29FYow7v0VxkfcVZj9/vuaXx8osLlY8ej1VUnVLbioEuG4LYUJOLeNmfUpsclRY"
			"0OOREsIjPltc8VpFYyCX72rqePjoeaNoSypYIDJK5sacFPj6d7IRw2NuZHjRtlWCZHcv2+M1qj8s"
			"Kfj3+kVD19RHOnqGqm0QERE3pMbv37riq60rliZED9UACNesSY793wXTPQ7ZIdaarVwg7vkJ+fmc"
			"ac8sn5UepsUBAGBrRuJHG5esSYqFgSe4o6lDojimCPnNgumPzMsLV/bPhYX/C6P1b6xdcJlPIxaB"
			"VUkxao0obC+BRpOloc869MribmOd0ezljSfQZLKc6zENrVdTn63B2DeocEfUaJSXp8SLLun/7Rdz"
			"c89ct+afl811T+rFCN/8en7+oqQYyUnGkh6j3zoKeqp9W1d8b3oGIYP9QcPQv5qf99GGxRFKhXva"
			"XtJtOulhuoaAsH3T0hWJMeKCCZ/vKch+bPFMWvwuEzjX3nOys3cKvHShK9z1CkWgFgvjALlrQGHn"
			"A0TcmpGknKhjqMvio3LCdRNzrxACEZDft3WFkqIkZ1IAABFvyE7enJPikYSQapOVH+LlghAipI3T"
			"qHIjwryq3YRrEHFGVBjluTFoYTnW79wCMU6temzxTHFu7rtoGVp8RKi4yyixetQrmQfn5rrTiisb"
			"rmQeKMyhA5hD3DUjE7gBiUkIEPJhbRt46LIRAN6qagJCuU8F0CIdFFDklfIGz2ohAHza0CbYhPV/"
			"y/G353ns7YuvL4zWD2fd6P5mTVKsZO+kxeLwUz1E4LjHlxQIR/NgyFxHr1SA6IjT3y/WeeiRXNzj"
			"S2fmR0qfvvvzfYXZGWEaj9OUhLxe6dEaX1NCV7jTFLkqLUE1AVHreP7m6Rlahg5w0/IPS2ZCkMw0"
			"RRBCrkxLFC/VLxUQr8pMStFphhMTSpq6JjOJ8tyM6bI7/D49H3MxQoiWpjVebRl9w3K/mpcHge0K"
			"Nlhsko3B7+al+0h7TVaShqH8Ll5vnpYGID7sDdsb28GjvsTF8180drjn4Cqa2paROBh4ksCXTZ0u"
			"bnBOLaT9pK7NY7sY4Pb8dK9lcN/L94RXNaSFHbx/uwlGobi3MMtv5sKv2xvaBzfqEIFh7inIHi6t"
			"0PI/nJnpsZ6gqB0NHRDYMw1lQle4A8BV6QnRyiBHtUYEIMLsye9CTLjgtvz0cJ3G7ys3RgiBO6d7"
			"f5GmOAjLEqJ9b24XRuu1jMewR435TDPCqPzb8Xhlejz46zxuPwoewp3DjWnDphWSLIyL8t3TEDFb"
			"r82N0Q9+RUit2dJh85gRl/SYmkVDi46hH5ybqx2cOZFmq61UODI2QKfdUW2yiAucGRmeHa4dm8gb"
			"Tdo5MREKKiCTtnabwyRuZIQlCVEaeth5m9Dy38hM8lhPEKg29kEAAiHECd2JISJShNxbmP3I0VLv"
			"x0PGiRXJselhmsCv1zH0jdnJL1+oD5aPBADg+CszE+OHWeROedLCtL5rHatSKgJrFncDsjz2uVgH"
			"z3OIQ/3DAECn3TEasYWYqvPfebxXB3FO9LB7iUKSeTER+xvafczBCCF6BbM8IbpSZLDYarFXGS3x"
			"A/7jEPFMl7HH5ujfKELMCNMujo/KjtCd6jAIorDH5jjRaZgbo3cXtcpoafMcIdYkx+iVjI9HY2M5"
			"K8uxiCzvZbOCIcTkYkfx1kQoGQIkkBeh2WJzet45WqVosdp8+8/RKxVSW1ge7RynDqbYmQBCV7gL"
			"z/Jns6c9cux88OxFCCHbMhL1I1kfMBR1XXbyG1VNdi5oTi5Z9unls+DrP3cYFcj4qzQGPAEkhHTZ"
			"nf+taS5q7a42WTvsDjvHObw9OJZH26geqIahAxmDWX7ImIKYrPPj4ygxAAefDEWtTop5o7KJG7hB"
			"n8NVajAtS4gSNNE8wOeCqaIAx39/RgYA3Jmfcaq1222+8ml92/emZ8CAB67zBrNZZBJGU9TKxBjJ"
			"2Ve3b5mSHtM71c1nu4z1fVYLy/W5WM7bSGljuVFYIgQ+5HbZnaxYwUJgb3PX3Pf3+05FARl6DnEK"
			"vHihK9wBABFVNPW9mVkvn/dmwjUeqGnqW9NSR5pqfXJcolZdZ/ZikzAO8PzKjESxCySZUSAI3A9r"
			"W39YdLbH4QzI7gVGeJx1MFFgqYgXQeV7YEgNC0gBeHlKnI6hTe6tIAJ7mju/Pz0DAAgQFvmPaltF"
			"+6KcoOu/Iz/t7r0nASlhF/Gz+jYWUUkoAECAPc2d4lvoGFritcYt2e8+WPKv8noHxwekqwzmfMXi"
			"8nzOhDg4zsEFcBxyKs6iQlrnLnT6X86ZJj1DOF7w/JrkWMG5XeCJEFFBU9/LT4cgzdx5/HFBdlBy"
			"vjRw21Q8V1rzjc8PddocHA74bPH7b8LxPTAEuJeQHqbN0uvEJh+7mjr7xRyB96qbwW3KzfOLUuMF"
			"8wEVTS9Li+9PRQi42Herm6Hffh32NIsMChGz9LocvYftFiHE6HQt+GD/34or+xdDk93CFnbIiiFU"
			"KqwEaAAAEMtJREFUn/sEENLCXXhLi9p6gtX6Lu6vK2bDCLUfwsU/nzMNaP+WDKOBkMPtPfD136yf"
			"XP5WVvvjorPBcy86MQRyQLvfZHtmptgNQK/Zet7Qb7r+53M1g0eHOP62vMFTSN/NFc1RGPqJs5UA"
			"AEDO95o7xRbuHP+DGRkg6pOIaOe4Ow+cPd3RO8kxakQwlF/v9JcQoSvcheVqi9V+x56TQFPj/4ry"
			"/LqsJMlkJPCyKWn6noKsoEzeKfLMmYq9zR1TxoHRBEMIaeiz/rG4ysPeGURuajjO27/AtArjje9H"
			"XGu2+u35gpi+Iz8DkAxOw2lKOJfXYrG7d00BERSM+NjtupRYomTcqc73mFotdgD4d0Uj0ANG8YiA"
			"cNeMTBBNgwghh9sN71c3DXGO77ORgxyLTa9gaElzCb5uRvpvcmPGjROhMuQOhRDC8vyGzw8HRbIj"
			"AuIv5k4bXWqhiz86L+/50prx3+wlBBh6845jDd/eMJUC5k0YiLi/tbvW2CeOzKBVMNdnp/xwRsbC"
			"uEiFtz29MoN58YdfWYLmro4eOqckpM1qT/QZNybATXtEpClyVXby9rrWftcxNPVGVdOflhW+Jcjf"
			"gZvPj4mIUQ+aD8SqlfNiIk539grlAcS3qpt+NnvaG2LfLIhr0xMoIo2j9PiZCiF0jPuy9HDtXTMy"
			"b8xJyR5mzvTYmYpHjpSO2ItkwOiVnsKd52+bnvnKmnmjy+3rbqsWojN34Qz3k2crz/eYgrSszo3S"
			"z4mOGPXUGBEjVYrNGYnjW6p+CLGz3H2HzrE8L0/eR8GOhnbxnwqaemb5rFfXzFuWEO1VsgOAyekK"
			"apG8RBcjUGe2DXe98NxPd/UG0v8FGXR7fvrglJOQDou9xmTZ1dghvnJ+XGSkctCHUpRKOS82UnzB"
			"Fw0dVUZLW59oxcDx9xR4nCESPnxZ3yaW7FEqZdG2lQ/NyxMku9d+awuqq1eARI3K8/mS8t4+NsC9"
			"9CF8rSU7hKxwJ4Q0We2/PV0evBtsSItP1KpH/fwIISqa/kZWEh0kv5UAb1c1ftnU+XXvYZPCOSF4"
			"0ADhCuZ7nj7xh2Lj+ODZtgqSjqGIh+aHova1dg6XRHjuh9t7AneMujAuMkp8vI7AM6U1NebBg0gM"
			"RV2WFCPpUGuTRAaOhNSaLc+X1Yq3UvVa9YI4jwEAAE519QIv8krPcT+bM03sN21S+m1muFZFeziK"
			"OdrRg+DdW/2UJ+SEu9t90qbPj7hcQYxKenveOJz/3JKeGBmkM7SEACE37jlpcLhA3lwdIQanS+zu"
			"ShA6vtoQ0cHxXNA0rYKkm6YP8zCFpKlXy335MDnd2WtwuAJ/BeI1qvlxHqeiXimvb+gbXBwoKLIu"
			"WeqMbF1KnEI0fjRabBI/MwvjIuOGOExt7JO4UsCCqHC/JWyQpBpXEJGhqMJo/eBxU0LQxT53vtb3"
			"9tVUfblCTrgLq9d7DpWUdRv9BO4aNTy/IjF66GRkpCBivEZ1XXZysLZfCDHZnVt2HIWv/wpxgpGc"
			"LWzss7mGj8AgOBkvM5iCvY02TWytCACEVBktH9a1wBD5Ivz5TGmN16NAw6Fl6BUJMYPVJMTsZAc9"
			"xvA4PSp86LGpJK26QCQQXRxvdDhBlMnyhOihEbSjVUqPgYqidjX58scifP9VW9BCDQ/a/6R5BA9h"
			"6EdOXKg0Wobz8SAo1nc2dTx+pgKmlqAPLeGOiEBgd1PHq/2b9UG5B7D8o/Pyxp6T0F1+t2B6EA0t"
			"aOpoR89fAw9YIwMAABI/fz0O52/PlA8nKAkhDo5/qqQ62G6c1yXHSsYPHvFHRSWVpj5xyYQH/a+L"
			"9a9XNIy0X12RGseI1ThiI26ev2MYt1/fyU0TK+vF8ldJEa9O7QsEd9zu4jH0387XnhreUy4h5NP6"
			"tvoec7DC7wxwa14aKBjx07e52M07jjT0Wb2+QYSQx85WbPrk4MNHzv34UMlUmkWFlrWMEA3jweNl"
			"tuA5TEfIidVvTEsYl61wREzQqq+elvpxTYtHgJvxg+fx/85UbMlIzArX+r9aBgAA1qfE7RVtJCLi"
			"709erDVav5uflhamGQhNR1ie73E4q03WX5240Gq2Bms+McC1WUk//uqMh3kVIe0WW/7be+4uyFqR"
			"EB2jVrp4bLLY3q9t2V3TMgoj/ZWJMdEqZbvVLk2ICIi35qZ5TXVbfvp9BzwLNpBKr1SuSoqRXI+I"
			"MWpVUlR4a59NvE982acHH56Xd1lSbLJWpaRpACRALCzbaXcWtXY/cuJCsC3ihZf6z8sKf1J0Ftyu"
			"5QipNJhnvbfv57OnrUmOTdaqVTTFIbRZ7We7jc+fry3pMAgGPM+draw2WV5dM39quHUKIeEutOa9"
			"h86dbusGJmgF4/lfzsmDcVJ0CJk8NDfv46qmYIXcI6Sjz3bz3pOHr149BTrcBEAIWZ8S94RaaR48"
			"jk8A4K3KhndrmmPVSjXTPw5ziBYX2213AWCwJTsipug01+amfVjd7DEPoChEfP5c9fPnqpUMwyFy"
			"glZh5Hs5Qve4JTftT6fLpeaGiAuTY4WgFpIuhIjhCmZJctyxtm5pB+b5b09Lcefs/rrfFHh+3t37"
			"TgM1+KpaXOwjR8+Hq5WRSoV7AeHgeLOLNTtcHq7hg4NQsFtyU1+6UHfRIIpVS1Emh+vRY2ValSJa"
			"pVBQFI/Y63QZ7U4AMvjoFcwXDe2XfXrwiyuXZX7951IhpJYhhHzW0Pby+ZogSnaAJL12TXLMOKo4"
			"EHF6VNiSAILmjB6aOtLc9duTF2XJHiBL4qPWJsdKXf1RFIvYZnPUma21Zmut2drQZ+t2Cx0MjouL"
			"wfsTQHx0Qb5erZTeiBCgKKAoJ89ziMJnABhpkYTucbfgnVycEBH4/mn7cJE0bpmWKnXygQgc/0Bh"
			"jtdUiHhtZlJebKRYASIcnjK72EaLrXagkVusdrOL7Z/6TIhqMVat+r9FM1QMLe0ANGVluSaLvdZs"
			"re+zGZ0sUNTQOZmN5SOmRByFEBLurVb7XUXFQfXuC4iL4qJyI8LGUUoSQiKUiqvS4oM7K2Hox85W"
			"nBQOm8j4RBi531y3YHZMRKBhVRBpijBB1rkjwLyYiCeXFAh39FskAFiWGD2ibV5EzNbr8uMjJR7K"
			"KAW9Jil2eAeLuCophpboTBAyoyOy9LrhVNWJWvXTywo1DBNoCXk+TOJcNzgg4nVZyX9ZVqiiaek4"
			"5zMZuNilidH7tiyPUimnwBZXqAh3RHzsTEVzkPwsirjTn73z6PjWtFR1kNf1To7/xbHz1iAfA5kC"
			"CHZvYQrmy83Lr8lNHRpwVQoicNzvFs5QBznslzCluGtm5seblgIhvmQiIgC8smb+PTOzR+TiQrjF"
			"rdPSJZkXRIUnaVXDNQMiJGvVUltGnhcOB/iYCW1OT/hq28ootcrDQMUrLDcvPupuScyjYHLXzKwD"
			"21amhuuA5/27DeZ54PnfLSvcdeWyLL0OpoR9WqgIdwDodbiC60UZMUGr2haEM6WImBsRtixhZJOs"
			"UdDnYr0GmvhaI7xEZOBfYH2AECJOIl01CW9mnEb14YYlf71sbrxGraIpwAFFh+ifgiJJOs3h69Zu"
			"SotHxME8hwkOIazhxbceKYi4LSOx4sb1C+KjNbRI/TKghFHR1JyYiLIb1t+Wny4ckfOoaQD5X5We"
			"QCuYwXISUhClj9OofJiyxGlUM6LChUr334uhr0qP9z2BRcRFcZFNt2y8JT9Dr2AYt3ZL9I8AaGjq"
			"iozEU9+4TElRHtUZpkDSh+uvykOrI3xYHB/VePOGXy+aEaVUqoc2NSIgMoSEKeg1KfFVN298dH5+"
			"WMg4QRs7IeSaqsfhvG73if2N0gjx44bD9camJTfnpgVpW7K42zj3rd2gCs6ZJp7PigjbddWyaVPL"
			"zzsi7m3pOt3V6z6dzyFuzUic6fNEjMHhfKOyyR1zAwHDFYrvz8iQOI1yP2gOcXdTx8nO3j4XJzp6"
			"CQxF5sZEbM1IVNFUs8X+35pm91F1BMiL0G1JT5ScQH6mtNrFDb4yNo57dH7+qKtf1NZ9qK2718G6"
			"/XqFK5k1STErEvsNVC72mj+obVUO6Is4xBy97pvZyb6zNTld71Q3G52DKqmVidFLE6J9pzraYTjY"
			"2u3+U69kbspJCTyOTWOfbV9rV0Vvn9jklEeMVauWJ0SvSIwGgINt3QfbepiBZ4AAKxKilyd6FKyh"
			"z/phbatr8EFgRpj2uqzkURwFd3cAJ8fvb+k6023scTjFPn4ogPyo8MsSYzKE7dOgBQWaFEJFuAuP"
			"gUNc9UnRkeauMbkW4nggILWkRIzVqFpu2Tica5ExIpR/0YdfnWzvkd6aR0Be6qFwRPB8cpj24g3r"
			"w5XMJWIw46OaI22BcWyx/9/e3f20VcYBHH/awgpt4YwgTGGCA5GwZIoOSQyDRFCTTcZ2sWmMMVET"
			"TfwDzIwxJl4Z/wCTZXF3yxJvNL5E58w0jIoQt2Ukk0BiwiDjZdYhM+t4KfTnxXG1G6WU0pbT376f"
			"O0h7znMO5ZvmvDwn4aLSW/6674rNSp/Ge9NY42b2UpKhprKK+N9n4+OdyjJT3IT84pTDMvZudRvT"
			"f6hj386KNM+6iPgLPO+3NL7ZVOuzz5XHliPyRmNNQdb+ePb432tu+P+SAxEj4nW7D9Q++Mkze3b4"
			"itLeqEeswJWjnYFCj4i2z99akmzmRvdAZk+eZ2r5677L5VrzqaHZWONm9lKSoaayitUXWWZWimPT"
			"95/llG/u8W4uRbq/HwhOhTZw5YyIWYrsf3Tnx627nyi3jDFDN24eH756cnQ8Elk2bnegsOBcd1tr"
			"ZVn2hi0iM/OLbV/1jf0TNiLGuI7UV72ze1dndYUx5tqt+Y8ujX429IfZtpE7U1aiD5f6env27Srx"
			"3yff2QFkhOPiLneez9vxdTDVvosYMcc7ml9vrImfE245Gp0ML7x1/vKPEzN7KsqGjjybgzS+9vPF"
			"UyPjTeXW6a6Wpu0l8eNZiUrvzI2DZ369neKEaNFodcA38nJXoPB+ORoDIFMcF3ebPar2b4K/TK+6"
			"a+7u1xljGqzAqc69rZVlaxXw7LU/K4u9zeVWDhI5FZ4PXp99qS7BfX32j9PhhcNnB38LzUnyszci"
			"daX+wcMd5UXbjLqjgQCyzaFxt/29uNRzZjA4GUp8flXE5XJ98NRj7z7ekORM4z2Pj8nqgOPXlbDH"
			"/71AzImRq8cGh+cWFhNPobMSrbX8515sq7c4GgMgHc6NeyxqT3/Ze2Fm9t7rI6PR7UXen7rbnnzA"
			"MjkJd6bEhjpx6/b+7wYSzGwclQqfd/zVF4o9njzaLgCO4ty420RkRaTz2/6+6TszQYsUuN1H66pO"
			"d+21x5+P+YsN+9jA758Oj4Ujy7Gtq7f8fT3tDxV7haMxANLl9LjbZheWDv4w2D8ZMsZUW/4T7c0H"
			"anaYvPrCvpo9eb3LuC6G5t7uu3xp6i/j8VSVFJ/vaa8v5WgMgE3Jg7jHMtf6RW+Vv+jz51q8WZ1c"
			"bCuIyIcXRk6OToy98rzX46bsADYpD+Ju0927u2/S03QLNICtkTdxj5Hszi62xXRvHYCcccr0A6nT"
			"3T7dWwcgZ/Iv7gCAdRF3AFCIuAOAQsQdABQi7gCgEHEHAIWIOwAoRNwBQCHiDgAKEXcAUIi4A4BC"
			"xB0AFCLuAKAQcQcAhYg7AChE3AFAIeIOAAoRdwBQiLgDgELEHQAUIu4AoBBxBwCFiDsAKETcAUAh"
			"4g4AChF3AFCIuAOAQsQdABQi7gCgEHEHAIWIOwAo9C9uDnNmafUxQgAAAABJRU5ErkJggg=="
		)
	)
	(text "Software Selectable Pins"
		(exclude_from_sim no)
		(at 425.45 303.53 0)
		(effects
			(font
				(size 2.0066 2.0066)
				(thickness 0.4013)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "0145f20b-ee43-412a-93be-905f33a73d1c")
	)
	(text "HSPICLK"
		(exclude_from_sim no)
		(at 278.765 273.685 0)
		(effects
			(font
				(size 0.635 0.635)
			)
			(justify left bottom)
		)
		(uuid "01fc77e8-685e-42e8-84b5-23b0f6998da6")
	)
	(text "Timing of SDIO Slave"
		(exclude_from_sim no)
		(at 513.842 360.172 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(thickness 0.1981)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "03555de1-d598-4bca-ac16-dc0312441fa0")
	)
	(text "GPIO0"
		(exclude_from_sim no)
		(at 482.854 347.98 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "044df920-df81-4639-9697-01117f48c83b")
	)
	(text "I2CEXT1_SDA_out"
		(exclude_from_sim no)
		(at 437.515 343.535 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "07387a4a-64d4-42c4-839a-b2eb41db61d4")
	)
	(text "GPIO15/MTDO"
		(exclude_from_sim no)
		(at 482.854 368.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "08b60288-56eb-48e3-8d07-6baf85ecc5c9")
	)
	(text "Pull-Down"
		(exclude_from_sim no)
		(at 494.792 350.266 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "095ada06-b05b-4ff7-a43c-619b2869d319")
	)
	(text "GPIO0:"
		(exclude_from_sim no)
		(at 537.337 312.166 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "09752bb0-5464-4439-bf41-a4669a2c075a")
	)
	(text "Debugging Log on U0TXD During Booting"
		(exclude_from_sim no)
		(at 506.222 352.552 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(thickness 0.1981)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "0bf4163c-16a3-4712-b996-29420d039111")
	)
	(text "For more information refer to \nesp_wroom_32_datasheet_en.pdf."
		(exclude_from_sim no)
		(at 430.53 385.445 0)
		(effects
			(font
				(size 1.1938 1.1938)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "0c010f68-3e41-4c06-8ec2-c03846daec72")
	)
	(text "GPIO2"
		(exclude_from_sim no)
		(at 482.854 350.266 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "0dd8937e-5a1e-443d-9ebd-92ba7e3d8b81")
	)
	(text "Pin"
		(exclude_from_sim no)
		(at 482.854 355.6 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "0f27131d-2905-4e5c-af55-6a0849a3aee2")
	)
	(text "Options: MCP2562-E/SN, MCP2551-I/SN, SIT1050T , SIT1042T/3, SIT1051T/3 or SN65HVD232D!"
		(exclude_from_sim no)
		(at 261.62 396.24 0)
		(effects
			(font
				(size 1.778 1.778)
			)
			(justify left bottom)
		)
		(uuid "11cb488f-d96a-481e-8232-b6e925569fe3")
	)
	(text "EMAC"
		(exclude_from_sim no)
		(at 426.72 317.5 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "12664c1b-7130-4e6d-a89a-e3f4298c4ee7")
	)
	(text "Default"
		(exclude_from_sim no)
		(at 494.792 337.185 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "1403eedc-d2b8-4959-a5b6-aec9e6e444d4")
	)
	(text "Ra"
		(exclude_from_sim no)
		(at 213.36 82.296 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left bottom)
		)
		(uuid "16f8ea29-3811-4a7a-81ca-e2545736f88f")
	)
	(text "Relays"
		(exclude_from_sim no)
		(at 337.82 160.02 0)
		(effects
			(font
				(size 4.4958 4.4958)
				(thickness 0.8992)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "18f66198-4e10-4e77-85c5-c71bb0d0a53b")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 494.792 370.586 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "19c408d0-7ff0-41d4-8f5f-2484f65b9356")
	)
	(text "I2CEXT0_SDA_out"
		(exclude_from_sim no)
		(at 437.515 338.455 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "1c435055-dac2-4d2e-a302-0973121115f4")
	)
	(text "0"
		(exclude_from_sim no)
		(at 203.835 353.06 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "1cb9668b-f175-4853-b9bc-adb5dac467c0")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 494.792 368.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "1cf01ec2-0c84-43aa-8eb3-42afdd75afb2")
	)
	(text "VSPI_CS2_out"
		(exclude_from_sim no)
		(at 437.515 378.46 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "1efa0b56-e3d0-491f-a200-7fe851a045f6")
	)
	(text "I2C"
		(exclude_from_sim no)
		(at 428.625 335.28 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "1fa3e1b3-e606-40b3-ac77-69ed1c2e8590")
	)
	(text "Pin"
		(exclude_from_sim no)
		(at 482.854 337.312 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "209652ee-6095-4acc-ab2c-aacb5a87045c")
	)
	(text "Rising-edge:Input"
		(exclude_from_sim no)
		(at 559.562 363.22 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "27230d95-6838-4e2c-8f98-54f95a771462")
	)
	(text "1"
		(exclude_from_sim no)
		(at 564.642 368.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "27a48b9e-e344-4e76-bdc4-7bc83844d5d6")
	)
	(text "Pull-Down"
		(exclude_from_sim no)
		(at 494.792 339.725 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "283acb5d-8958-4d64-a5fe-0ec60525e061")
	)
	(text "Battery\nMeasurement"
		(exclude_from_sim no)
		(at 187.96 29.21 0)
		(effects
			(font
				(size 2.54 2.54)
				(thickness 0.508)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "28c4ad58-4ccc-4c38-9950-a833f1dd7a67")
	)
	(text "Falling-edge:Output"
		(exclude_from_sim no)
		(at 541.528 364.998 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "28d4dbc8-66b7-44ef-9b41-8eade76b1458")
	)
	(text "USB to UART"
		(exclude_from_sim no)
		(at 99.06 317.5 0)
		(effects
			(font
				(size 4.4958 4.4958)
				(thickness 0.8992)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "297e0735-2561-4133-a6b4-fccbc1ae14f0")
	)
	(text "0"
		(exclude_from_sim no)
		(at 529.082 347.98 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "2e37b2e4-0255-422d-9d33-127b9421ec35")
	)
	(text "IBAT = 1000/Rprog = 500mA"
		(exclude_from_sim no)
		(at 111.76 91.44 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "30a8ef87-dd3c-4f65-a7fa-da0bde38d11e")
	)
	(text "Pull-Down"
		(exclude_from_sim no)
		(at 555.117 315.976 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "348b42e1-4ffa-442b-b96f-90310f620724")
	)
	(text "VSPID_in/_out"
		(exclude_from_sim no)
		(at 437.515 368.3 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "36067016-fc66-43d1-9528-e3a06218ecf1")
	)
	(text "Signal"
		(exclude_from_sim no)
		(at 438.785 308.61 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "3751fff5-00f8-4a7f-ab1d-94bf2f3fd1de")
	)
	(text "HSPI_CS2_out"
		(exclude_from_sim no)
		(at 437.515 363.22 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "376bb223-a9b8-4dc7-bbd8-c40c23479329")
	)
	(text "GPIO5:"
		(exclude_from_sim no)
		(at 537.337 323.596 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "3b142de6-9319-4ce0-a1f3-97d9bf9de70c")
	)
	(text "Power Supply"
		(exclude_from_sim no)
		(at 111.76 27.94 0)
		(effects
			(font
				(size 3.9878 3.9878)
				(thickness 0.7976)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "3f26bbf9-59f7-49d2-a90b-4a3add946575")
	)
	(text "HSPID_in/_out"
		(exclude_from_sim no)
		(at 437.515 353.06 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "40002839-5b60-412b-af42-eef069db9531")
	)
	(text "0"
		(exclude_from_sim no)
		(at 546.862 370.586 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "41800dc5-099d-47f3-afe4-a2005863e1a8")
	)
	(text "I2CEXT1_SCL_in"
		(exclude_from_sim no)
		(at 437.515 330.835 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "41e58e98-671f-455f-8965-0dff3ff575e8")
	)
	(text "Rprog"
		(exclude_from_sim no)
		(at 139.065 84.455 0)
		(effects
			(font
				(size 0.762 0.762)
				(thickness 0.1524)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "41f49fae-3e36-41aa-825f-74c7f6813ceb")
	)
	(text "I2CEXT0_SCL_in"
		(exclude_from_sim no)
		(at 437.515 325.755 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "42da1df4-5e6c-41f2-9d4c-479f76c1bed9")
	)
	(text "Auto program\n"
		(exclude_from_sim no)
		(at 200.025 344.805 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "42f33885-2fb4-43e1-9b79-56a9077792df")
	)
	(text "Internal Bootstrapping Resistors"
		(exclude_from_sim no)
		(at 524.002 303.403 0)
		(effects
			(font
				(size 2.0066 2.0066)
				(thickness 0.4013)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "4350044a-6217-44c2-ae99-d0a47499da28")
	)
	(text "HSPIQ"
		(exclude_from_sim no)
		(at 278.765 271.145 0)
		(effects
			(font
				(size 0.635 0.635)
			)
			(justify left bottom)
		)
		(uuid "49608d79-f47a-4bbe-9f15-bda2d13474bf")
	)
	(text "EMAC_MDC_out"
		(exclude_from_sim no)
		(at 437.515 311.785 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "4a563fb2-5216-4e0d-967f-c9bdce5bf384")
	)
	(text "1"
		(exclude_from_sim no)
		(at 197.485 355.6 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "4aeb1e23-e156-48c0-9540-8acd62352988")
	)
	(text "1"
		(exclude_from_sim no)
		(at 210.185 358.14 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "4aece6a9-d566-41bb-8ac3-ad47a367d478")
	)
	(text "Ethernet"
		(exclude_from_sim no)
		(at 147.32 137.16 0)
		(effects
			(font
				(size 4.4958 4.4958)
				(thickness 0.8992)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "4c6eb225-011c-4ed0-b613-e177f612c7b8")
	)
	(text "I2CEXT1_SDA_in"
		(exclude_from_sim no)
		(at 437.515 333.375 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "4cf20ccf-1375-4fe7-91cc-0c8c70fdcf03")
	)
	(text "Pull-Down"
		(exclude_from_sim no)
		(at 555.117 308.356 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "4f31729c-771e-4a73-9d5d-c33c43ddbefa")
	)
	(text "0"
		(exclude_from_sim no)
		(at 197.485 353.06 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "4fe726fd-89db-4f1f-b6f5-6646369151b5")
	)
	(text "1"
		(exclude_from_sim no)
		(at 529.082 339.725 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "503e7744-9819-4826-aedc-532bb3d86442")
	)
	(text "1"
		(exclude_from_sim no)
		(at 511.302 358.14 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "50dd9ee8-959b-4569-98db-990afb648b22")
	)
	(text "1"
		(exclude_from_sim no)
		(at 546.862 368.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "54cea064-c525-4fe8-9530-b0cf36d8e3f7")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 555.117 319.786 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "58b697ad-70b4-436b-b444-05b8b043ab74")
	)
	(text "DTR  RTS->EN  IO0"
		(exclude_from_sim no)
		(at 195.58 347.98 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "5a4ea9a3-3b09-4856-a261-cf4ef8bcf6b5")
	)
	(text "The PHY is setted up as follows:\nMODE: All capable(10/100Base)\n-Auto-negotiation enabled\n-RMII Configuration\n-SMI address: 0x00"
		(exclude_from_sim no)
		(at 208.28 233.68 0)
		(effects
			(font
				(size 1.1938 1.1938)
			)
			(justify left bottom)
		)
		(uuid "5daaf2cb-b5e9-4fb9-b98e-dc99633eec5b")
	)
	(text "LiPo Charger"
		(exclude_from_sim no)
		(at 114.3 58.42 0)
		(effects
			(font
				(size 2.9972 2.9972)
				(thickness 0.5994)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "5dbbfdae-ee65-4513-a71f-f61e3461b23e")
	)
	(text "1"
		(exclude_from_sim no)
		(at 215.9 353.06 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "5e55733a-bb14-4f72-a8bc-4252526359c0")
	)
	(text "EMAC_MDO_out"
		(exclude_from_sim no)
		(at 437.515 316.865 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "60b9a622-a74e-47cf-9b53-331214dcb1bf")
	)
	(text "U0TXD Silent"
		(exclude_from_sim no)
		(at 524.002 355.6 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "62f74de2-2e1e-4f2d-8d1b-e164738017b9")
	)
	(text "GPIO5"
		(exclude_from_sim no)
		(at 482.854 370.586 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "682da5dc-233c-4d03-82ca-88718e4459a4")
	)
	(text "EMAC_CRS_out"
		(exclude_from_sim no)
		(at 437.515 319.405 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "68dd5079-3a79-41f5-84a3-b8dbbcc7c7b1")
	)
	(text "0"
		(exclude_from_sim no)
		(at 511.302 370.586 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "6971a912-b54b-4e84-b3e3-76dba2ef66c7")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 555.117 323.596 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "6b87bd69-6b94-436f-91da-bfa446a3c502")
	)
	(text "I2CEXT0_SCL_out"
		(exclude_from_sim no)
		(at 437.515 335.915 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "6d867d4f-dbf6-45d0-b8fa-3753cc807a1d")
	)
	(text "NCP303LSN18T1G is OK too!"
		(exclude_from_sim no)
		(at 121.92 276.86 0)
		(effects
			(font
				(size 1.016 1.016)
				(thickness 0.2032)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "6f1a34cb-9d8b-4a25-878e-932a3d53f7c5")
	)
	(text "Pin"
		(exclude_from_sim no)
		(at 483.108 363.22 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "72f6e2dd-ae79-4d70-8129-6eca7ba40f49")
	)
	(text "HSPIQ_in/_out"
		(exclude_from_sim no)
		(at 437.515 350.52 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "74c52636-e3f9-47f1-b566-b77409b4734f")
	)
	(text "HSPID"
		(exclude_from_sim no)
		(at 298.45 271.145 0)
		(effects
			(font
				(size 0.635 0.635)
			)
			(justify left bottom)
		)
		(uuid "7533ae9a-0f01-4028-8557-0ed727b93b66")
	)
	(text "Don't-care"
		(exclude_from_sim no)
		(at 508.762 350.266 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "761cb370-f32c-4245-b179-af0bc17603a9")
	)
	(text "CAN Driver"
		(exclude_from_sim no)
		(at 307.34 312.42 0)
		(effects
			(font
				(size 4.4958 4.4958)
				(thickness 0.8992)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "78a9d949-547f-40ad-9d5d-b4e2f01108e3")
	)
	(text "Any GPIO"
		(exclude_from_sim no)
		(at 455.93 316.23 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "795898a8-bd6b-4131-82b7-98aa14edafce")
	)
	(text "Booting Mode"
		(exclude_from_sim no)
		(at 516.382 342.392 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(thickness 0.1981)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "7a4be15d-87ad-4297-bed1-5d4aa1695f57")
	)
	(text "VSPICLK_in/_out"
		(exclude_from_sim no)
		(at 437.515 370.84 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "7b0d0772-a81c-439a-976a-b4724be7dce8")
	)
	(text "0"
		(exclude_from_sim no)
		(at 529.082 358.14 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "7b81cfc6-6028-4e16-bbeb-232f5cdab7c4")
	)
	(text "1"
		(exclude_from_sim no)
		(at 564.642 370.586 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "7caf5ccb-7977-497b-8655-ec0e0c1a2d7e")
	)
	(text "Default"
		(exclude_from_sim no)
		(at 494.792 355.6 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "7cf4b274-4c43-4f50-8513-6044307a3682")
	)
	(text "Rising-edge:Output"
		(exclude_from_sim no)
		(at 523.494 364.998 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "7da247b6-dc56-4a2d-8a6f-cb963c9a22ff")
	)
	(text "Default"
		(exclude_from_sim no)
		(at 494.792 345.186 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "7fd94045-80a0-416c-8b3b-2f1bf543c48e")
	)
	(text "Pin"
		(exclude_from_sim no)
		(at 455.295 308.61 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "82352646-6021-4e1a-9121-029a2dca0812")
	)
	(text "GPIO15/MTDO"
		(exclude_from_sim no)
		(at 482.854 357.886 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "84cdd08d-b95f-477c-9ec3-17f855120887")
	)
	(text "EMAC_MDI_in"
		(exclude_from_sim no)
		(at 437.515 314.325 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "87956775-c4ef-4b4c-bfa2-91849a8ae7ea")
	)
	(text "1"
		(exclude_from_sim no)
		(at 529.082 370.586 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "88117b5c-6af5-4d9c-bf22-269205acab8b")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 494.792 347.98 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "8889fc3e-f2d0-4ed8-950c-4cb6c8bf8003")
	)
	(text "1"
		(exclude_from_sim no)
		(at 215.9 350.52 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "8c494254-551e-4c25-8be9-2fa7afad654f")
	)
	(text "0"
		(exclude_from_sim no)
		(at 511.302 368.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "8ce490c9-86fe-49ae-8448-1869a0374770")
	)
	(text "1"
		(exclude_from_sim no)
		(at 197.485 350.52 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "8fce901c-6612-42fd-baf7-5d14290cc815")
	)
	(text "1"
		(exclude_from_sim no)
		(at 210.185 353.06 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "90c4f0ca-9b4f-4e3d-b48f-7e16ec302962")
	)
	(text "Any GPIO"
		(exclude_from_sim no)
		(at 455.93 335.28 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "90c7628e-5cf3-4180-a65a-24e8ac9cbc10")
	)
	(text "Rising-edge:Output"
		(exclude_from_sim no)
		(at 559.308 364.998 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "93081397-7848-40a1-8795-4bb86b5f1f64")
	)
	(text "+"
		(exclude_from_sim no)
		(at 65.786 70.612 0)
		(effects
			(font
				(size 1.7018 1.7018)
				(thickness 0.3404)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "93f93f46-fe05-4d93-bfbb-6efc688376bf")
	)
	(text "0"
		(exclude_from_sim no)
		(at 197.485 358.14 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "9625c89e-f7a7-40bd-b2c6-ebe4a363d4bb")
	)
	(text "0"
		(exclude_from_sim no)
		(at 215.9 358.14 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "970548e1-40da-43bf-be63-c53e7bda7bf8")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 555.117 312.166 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "98437a61-693d-45b0-af1f-5cb70647882c")
	)
	(text "===================\nDesired Tdelay=500ms\n===================\n1. 49.9k/1%/R0603; 10uF/6.3V/20%/X5R/C0603; ===> Tdelay=750ms(Measured)\n2. 220k/R0603; 1uF/10V/10%/X5R/C0603; =======>  Tdelay=500ms(Measured) = OK!!!"
		(exclude_from_sim no)
		(at 114.3 298.45 0)
		(effects
			(font
				(size 0.762 0.762)
				(thickness 0.1524)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "98f19055-54ff-4c0a-97ea-cce578012c85")
	)
	(text "(Rs)"
		(exclude_from_sim no)
		(at 318.262 346.964 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left bottom)
		)
		(uuid "9c472eba-6016-4d0f-a603-79330183e7d7")
	)
	(text "UEXT"
		(exclude_from_sim no)
		(at 289.56 231.14 0)
		(effects
			(font
				(size 4.4958 4.4958)
				(thickness 0.8992)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "9ce0a951-f284-4990-baea-610add20e30c")
	)
	(text "Interface"
		(exclude_from_sim no)
		(at 426.085 308.61 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "9e72c95f-7224-4e6a-b8ad-cdcc8b4fa29c")
	)
	(text "-"
		(exclude_from_sim no)
		(at 65.786 75.946 0)
		(effects
			(font
				(size 1.7018 1.7018)
				(thickness 0.3404)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "9f3ba001-8e6c-47f2-bf2e-38942ed8adc6")
	)
	(text "Rb"
		(exclude_from_sim no)
		(at 213.36 87.376 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left bottom)
		)
		(uuid "a01321d0-b151-4d24-918b-576d74e18831")
	)
	(text "EMAC_COL_out"
		(exclude_from_sim no)
		(at 437.515 321.945 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "a162ce7f-dad7-416f-8cb0-17dfbc00b6df")
	)
	(text "In RMII\n Mode\n"
		(exclude_from_sim no)
		(at 157.48 152.4 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "a222352d-fa96-4164-8030-3f85aae515b1")
	)
	(text "(Vref)"
		(exclude_from_sim no)
		(at 318.135 357.505 0)
		(effects
			(font
				(size 0.762 0.762)
			)
			(justify left bottom)
		)
		(uuid "a312f644-10bc-4bf1-9bfa-f6a1445422c2")
	)
	(text "0"
		(exclude_from_sim no)
		(at 529.082 368.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "a8a635ef-b8f6-4d2c-9fa6-7627f1eca8c0")
	)
	(text "0"
		(exclude_from_sim no)
		(at 210.185 355.6 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "a94fe517-4d0e-4706-84fc-6106fae1dccb")
	)
	(text "General\nPurpose\nSPI"
		(exclude_from_sim no)
		(at 425.45 367.03 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "aa81d48f-a648-4a16-a6a1-7a5435132775")
	)
	(text "ESP-WROOM-32\n     MODULE"
		(exclude_from_sim no)
		(at 317.5 33.02 0)
		(effects
			(font
				(size 2.9972 2.9972)
				(thickness 0.5994)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "ad26f068-31f8-451f-a113-03160887d351")
	)
	(text "tD2 ≈ RD * CD\nRD = 1M Ohm -> typiclally\nCD = 470nF -> selected\nthen: tD2 approx. 470ms"
		(exclude_from_sim no)
		(at 121.92 271.78 0)
		(effects
			(font
				(size 1.27 1.27)
				(thickness 0.254)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "aea388e3-26f0-4989-bca6-5c58886e82f0")
	)
	(text "HSPICLK_in/_out"
		(exclude_from_sim no)
		(at 437.515 355.6 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "afbdae77-fe23-467b-85c4-a83fadfc7f6c")
	)
	(text "MTDO/GPIO15:"
		(exclude_from_sim no)
		(at 528.447 319.786 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "b039b903-fa0c-425f-a644-ae5b984d1a22")
	)
	(text "1"
		(exclude_from_sim no)
		(at 210.185 350.52 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "b0abb3f1-39ec-4774-af3e-46acab674767")
	)
	(text "1"
		(exclude_from_sim no)
		(at 511.302 347.98 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "b34fd51d-e067-4685-9127-30c5df83ef2a")
	)
	(text "+5V_Only!!!"
		(exclude_from_sim no)
		(at 22.86 50.8 0)
		(effects
			(font
				(size 2.54 2.54)
				(thickness 0.508)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "b3dc73b7-e101-40fe-83c2-54070e7399b0")
	)
	(text "U0TXD Toggling"
		(exclude_from_sim no)
		(at 506.222 355.6 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "b5536b3c-d566-44fe-84e9-fba8c5acadde")
	)
	(text "Voltage of Internal LDO(VDD_SDIO)"
		(exclude_from_sim no)
		(at 508.762 334.518 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(thickness 0.1981)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "b6f051cb-90f0-43dd-a7bd-3e17cacb0ae0")
	)
	(text "1"
		(exclude_from_sim no)
		(at 203.835 350.52 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "b7b6b9b5-dca2-4c2f-99fb-b9c3df13e085")
	)
	(text "SPI Flash Boot"
		(exclude_from_sim no)
		(at 507.492 344.805 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "bacebe6f-361c-4308-85f0-e64934a97af7")
	)
	(text "1"
		(exclude_from_sim no)
		(at 203.835 358.14 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "bbc8907c-77d8-430f-8ab5-63ac28cca079")
	)
	(text "VSPI_CS0_in/_out"
		(exclude_from_sim no)
		(at 437.515 373.38 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "bbdad589-5a0e-4cb4-a3f0-89dd59b8062b")
	)
	(text "Bootstrapping Pins \n     Settings"
		(exclude_from_sim no)
		(at 546.227 344.805 0)
		(effects
			(font
				(size 1.8034 1.8034)
				(thickness 0.3607)
				(bold yes)
			)
			(justify left bottom)
		)
		(uuid "bc664c57-7e88-463e-bcec-36a4313ac84e")
	)
	(text "3.3V"
		(exclude_from_sim no)
		(at 508.762 337.185 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "c03f7448-c604-489a-b611-3aa410b48bab")
	)
	(text "0"
		(exclude_from_sim no)
		(at 203.835 355.6 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "c0d6e164-8d22-44c9-a286-2687f5a3e26e")
	)
	(text "CD"
		(exclude_from_sim no)
		(at 107.95 262.89 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c3cfdb5f-01db-4950-8634-75b5d6743d22")
	)
	(text "Extension"
		(exclude_from_sim no)
		(at 502.92 27.94 0)
		(effects
			(font
				(size 3.5052 3.5052)
				(thickness 0.701)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "c5634b78-78a1-481c-8a8b-46f2829b4328")
	)
	(text "0"
		(exclude_from_sim no)
		(at 529.082 350.266 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "c699bad7-3e05-447e-b0e9-2bbb149eb4f9")
	)
	(text "Mounting Holes"
		(exclude_from_sim no)
		(at 485.14 304.8 0)
		(effects
			(font
				(size 2.4892 2.4892)
				(thickness 0.4978)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "c73da333-a9d3-418d-8311-3d0af8f3b613")
	)
	(text "GPIO2:"
		(exclude_from_sim no)
		(at 537.337 315.976 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "c895d84f-92fd-4933-b73b-6a33f493ce31")
	)
	(text "Download Boot"
		(exclude_from_sim no)
		(at 527.177 344.805 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "cceb6134-c86c-4252-848e-b9e3fadb05be")
	)
	(text "Rising-edge:Input"
		(exclude_from_sim no)
		(at 541.782 363.22 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "cebfcbdb-069f-4ac1-b22b-e29b1cd96fba")
	)
	(text "MTDI/GPIO12:"
		(exclude_from_sim no)
		(at 529.717 308.356 0)
		(effects
			(font
				(size 1.4986 1.4986)
			)
			(justify left bottom)
		)
		(uuid "cecb526f-d54d-4cf5-a442-55b75c776459")
	)
	(text "Any GPIO"
		(exclude_from_sim no)
		(at 455.93 364.49 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "cffb11ef-5ea2-4739-a476-96e692e6397a")
	)
	(text "SD/MMC Card"
		(exclude_from_sim no)
		(at 375.92 228.6 0)
		(effects
			(font
				(size 3.5052 3.5052)
				(thickness 0.701)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "d20add0a-3cfa-4346-b629-d9cd3d65d482")
	)
	(text "0"
		(exclude_from_sim no)
		(at 508.762 339.725 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "d3ad1109-e669-4634-ac15-b59286abe153")
	)
	(text "Default"
		(exclude_from_sim no)
		(at 494.792 363.22 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "d62768b4-0bbf-40d1-99e2-792afa83fe38")
	)
	(text "Pin"
		(exclude_from_sim no)
		(at 482.854 345.186 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "d8113079-1db8-44b4-b571-6f2b4452188f")
	)
	(text "VSPI_CS1_out"
		(exclude_from_sim no)
		(at 437.515 375.92 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "d8a2eb41-d423-4f23-ae4b-f20322190c47")
	)
	(text "I2CEXT1_SCL_out"
		(exclude_from_sim no)
		(at 437.515 340.995 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "dbec4bfb-eaa9-4406-a196-1339ed495a36")
	)
	(text "HSPI_CS1_out"
		(exclude_from_sim no)
		(at 437.515 360.68 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "dd57bc89-0b51-4844-9157-5fcc30e7e5df")
	)
	(text "Infrared Communication"
		(exclude_from_sim no)
		(at 480.06 134.62 0)
		(effects
			(font
				(size 3.5052 3.5052)
				(thickness 0.701)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "de5212f0-b097-4b98-9764-51b0c74cbe8a")
	)
	(text "Falling-edge:Input"
		(exclude_from_sim no)
		(at 523.748 363.22 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "deb3a243-3f28-44b8-9353-cdbd3b04e3d5")
	)
	(text "1.8V"
		(exclude_from_sim no)
		(at 529.082 337.185 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "e2716e89-b56a-4183-a19f-da863b756071")
	)
	(text "GPIO12/MTDI"
		(exclude_from_sim no)
		(at 482.854 339.852 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "e28a5d81-fc43-4aae-8263-6a3e02533a8d")
	)
	(text "Falling-edge:Output"
		(exclude_from_sim no)
		(at 504.19 364.998 0)
		(effects
			(font
				(size 0.9906 0.9906)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "e67832fa-43ac-453e-8086-59c1b4410725")
	)
	(text "Vout=0.6*(1+Ra/Rb)"
		(exclude_from_sim no)
		(at 190.5 91.44 0)
		(effects
			(font
				(size 1.2954 1.2954)
			)
			(justify left bottom)
		)
		(uuid "e869f093-0e04-4d01-befa-049e662494d4")
	)
	(text "Pull-Up"
		(exclude_from_sim no)
		(at 494.792 357.886 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "e9358a38-5006-4f6d-8030-1e920e9db1d9")
	)
	(text "VSPIQ_in/_out"
		(exclude_from_sim no)
		(at 437.515 365.76 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "e94a0dd8-8f9d-4b67-9bfc-addfad464291")
	)
	(text "Buttons"
		(exclude_from_sim no)
		(at 500.38 238.76 0)
		(effects
			(font
				(size 3.5052 3.5052)
				(thickness 0.701)
				(bold yes)
				(italic yes)
			)
			(justify left bottom)
		)
		(uuid "eb6e8661-4115-4a9c-974e-63850e14ccb1")
	)
	(text "I2CEXT0_SDA_in"
		(exclude_from_sim no)
		(at 437.515 328.295 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "ef16c073-0fc3-41e5-9da8-d6818fc70ff5")
	)
	(text "HSPI_CS0_in/_out"
		(exclude_from_sim no)
		(at 437.515 358.14 0)
		(effects
			(font
				(size 1.0922 1.0922)
			)
			(justify left bottom)
		)
		(uuid "f225a061-e3ef-4c1b-b96a-8e1267232b3a")
	)
	(text "1"
		(exclude_from_sim no)
		(at 215.9 355.6 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "fb069a91-241a-430e-a597-8c397daec21b")
	)
	(label "GPI35/CAN-RX"
		(at 378.46 355.6 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "045abfd8-9637-478b-993b-30d5f194dea1")
	)
	(label "BUT1"
		(at 231.14 33.02 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "05073d81-d1cf-4125-8335-42c13de4ed40")
	)
	(label "PHYAD1"
		(at 185.42 180.34 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "09ee43b7-bc21-49c4-b13c-d288d10e6284")
	)
	(label "GPIO1/U0TXD"
		(at 533.4 43.18 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "0a6feee0-2892-4dfd-af0e-5e55c7c38b74")
	)
	(label "GPIO26/EMAC_RXD1(RMII)"
		(at 210.82 170.18 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "0b95385b-2d60-40e7-ac29-31f629d549ad")
	)
	(label "OSC_DIS"
		(at 208.28 378.46 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "0ce607df-565b-4fcd-ab96-b55592d9ae15")
	)
	(label "GPIO18/MDIO(RMII)"
		(at 210.82 190.5 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "0e999c68-ac13-4515-8d69-38c5c3a913d2")
	)
	(label "GPI34/BUT1"
		(at 480.06 78.74 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "117075bf-928d-45e6-a23d-82e60d00f8fc")
	)
	(label "GPIO18/MDIO(RMII)"
		(at 396.24 93.98 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "11dcc886-6c34-4ad3-8c0b-ec2e6fe75b6f")
	)
	(label "GPIO0/XTAL1/CLKIN"
		(at 396.24 48.26 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "12a33153-d2b5-416a-89ae-f728a9a1aae4")
	)
	(label "PHYAD1"
		(at 208.28 241.3 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "1385731c-8551-48c8-afaf-b1c494f68fe6")
	)
	(label "GPI39/IR_RECEIVE"
		(at 396.24 127 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "180fb109-411d-4e45-a403-35c3a13995f3")
	)
	(label "GPIO26/EMAC_RXD1(RMII)"
		(at 480.06 73.66 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "18b9eb6e-1196-4379-9987-dc533c2ecc24")
	)
	(label "VDD1A-2A"
		(at 40.64 284.48 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "1d090896-1a8a-4b84-9e44-538eb4bb71c1")
	)
	(label "GPIO7/SD_DATA0"
		(at 533.4 50.8 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "1d4a2b91-ef76-498b-8d26-ae2acca7dbf4")
	)
	(label "GPIO11/SD_CMD"
		(at 533.4 55.88 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "1d676dda-51c0-41cc-acb7-b3eaa449fcfa")
	)
	(label "GPIO2/HS2_DATA0"
		(at 200.66 383.54 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "1eab6531-1c29-40f3-8abf-5666bb8f2a47")
	)
	(label "OSC_DIS"
		(at 53.34 170.18 90)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "1eef5eec-fa07-4583-b5f6-d58a4de26fc4")
	)
	(label "GPIO25/EMAC_RXD0(RMII)"
		(at 533.4 71.12 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "202b97e0-80b5-4a26-aec3-9df4bd1283d2")
	)
	(label "OSC_DIS"
		(at 78.74 246.38 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "24dd061c-2137-4644-aa08-1988f6847864")
	)
	(label "GPIO32/REL1"
		(at 480.06 76.2 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "24e1c9ec-0cc8-41d0-a51d-a358be46e331")
	)
	(label "ESP_EN"
		(at 480.06 83.82 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "263bde52-1282-439c-8806-f54ae6b356ec")
	)
	(label "GPIO9/SD_DATA2"
		(at 396.24 71.12 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "289ac335-5446-456a-934b-e89ba96f5e72")
	)
	(label "GPIO4/U1TXD"
		(at 261.62 266.7 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "289ae8d1-2ba8-4c8a-9c81-90d883cc67af")
	)
	(label "GPIO12/IR_Transmit"
		(at 396.24 78.74 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "2954f0f7-8c1a-4269-b6f7-b7ddb26bdd33")
	)
	(label "GPIO11/SD_CMD"
		(at 396.24 76.2 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "2c2af294-4d82-4398-b904-2ff12a375cae")
	)
	(label "GPI36/U1RXD"
		(at 480.06 81.28 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "2ea44a3e-5d70-4213-80ea-60f43cf4d1c6")
	)
	(label "GPIO2/HS2_DATA0"
		(at 396.24 53.34 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "2f35b2dd-7073-4d6a-a0a7-e04234860e5b")
	)
	(label "GPIO32/REL1"
		(at 396.24 114.3 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "2f8f5d3a-bc30-4be2-9435-90cb65017080")
	)
	(label "GPIO16/I2C-SCL"
		(at 480.06 63.5 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "34652de6-e6a0-4b7e-8179-557316b66640")
	)
	(label "GPI35/CAN-RX"
		(at 533.4 78.74 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "38e0264e-ccf9-481e-a524-69c83c8706a2")
	)
	(label "GPIO0/XTAL1/CLKIN"
		(at 198.12 363.22 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "3c300961-875d-4051-9b60-305d9dcea1a8")
	)
	(label "GPIO2/HS2_DATA0"
		(at 480.06 45.72 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "438c86e3-2607-4941-a7e7-4743d14e57f1")
	)
	(label "PHYAD0"
		(at 185.42 182.88 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "4694f3a3-0b2e-47a1-9689-5f0a84c58782")
	)
	(label "GPIO4/U1TXD"
		(at 480.06 48.26 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "4a920b5c-ddc0-4083-afc2-4bc7dc482fef")
	)
	(label "ESP_EN"
		(at 269.24 76.2 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "4c59a932-4a7c-4a3a-a1ba-690f4753bb14")
	)
	(label "PHYAD2"
		(at 208.28 243.84 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "4d5ad886-7851-4763-b937-7a05fe28b4b0")
	)
	(label "+5V_EXT"
		(at 53.34 60.96 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "4e265dbf-dbf1-4cc1-8ebe-c330b1d31f96")
	)
	(label "GPIO14/HS2_CLK"
		(at 480.06 60.96 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "4e306aba-80b6-4242-91ca-2be95ed23f28")
	)
	(label "GPIO3/U0RXD"
		(at 533.4 45.72 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "4fd7f85b-8799-421f-830a-74247effe7a8")
	)
	(label "GPIO21/EMAC_TX_EN(RMII)"
		(at 480.06 68.58 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "50647878-c422-4d72-9cae-0b23c49ff4e2")
	)
	(label "GPIO2/HS2_DATA0"
		(at 314.452 271.78 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "506d29f8-5081-4357-a7eb-5cabdd6b3c02")
	)
	(label "GPIO25/EMAC_RXD0(RMII)"
		(at 396.24 106.68 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "53b762a8-2529-44c3-9d50-f02f3c602eff")
	)
	(label "GPI36/U1RXD"
		(at 396.24 124.46 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "54044460-ca88-494d-a0e1-b17035c26259")
	)
	(label "GPI34/BUT1"
		(at 226.06 22.86 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "54adb9b4-cbf4-411b-8056-27e031177c2a")
	)
	(label "GPIO19/EMAC_TXD0(RMII)"
		(at 210.82 147.32 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "58cff928-a20e-4ab9-a272-294c1fa6a7b1")
	)
	(label "GPIO19/EMAC_TXD0(RMII)"
		(at 396.24 96.52 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "5be7a6fe-6ef5-44b7-96ca-19604ed8a21f")
	)
	(label "VDDCR"
		(at 121.92 165.1 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "658dcf44-6299-4611-88b7-4eb1d995aecb")
	)
	(label "GPIO5/CAN-TX"
		(at 533.4 48.26 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "661853ef-a764-4a4e-ad4c-ccce6833beff")
	)
	(label "GPIO13/I2C-SDA"
		(at 314.96 269.24 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "69804dac-d8f5-4de1-bc14-92544ddbe1b7")
	)
	(label "ESP_EN"
		(at 508 274.32 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "6e56db95-47ea-4191-904f-663faaba3396")
	)
	(label "GPIO17/SPI_CS"
		(at 396.24 91.44 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "6e6a9211-89b4-47ac-8fbe-d814a0d6fd83")
	)
	(label "RMIISEL"
		(at 208.28 246.38 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "703f27b6-e60d-4836-9daf-2867803564a1")
	)
	(label "GPIO33/REL2"
		(at 396.24 116.84 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "70a69f28-6097-4b86-b3f1-fc9c5ee33ded")
	)
	(label "GPIO0/XTAL1/CLKIN"
		(at 109.22 190.5 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "726f12ca-16f5-4bbf-aed8-1676b01c04c4")
	)
	(label "GPIO6/SD_CLK"
		(at 480.06 50.8 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "739126a2-4bd8-4a23-a73c-d87e8bc8497f")
	)
	(label "ESP_EN"
		(at 198.12 340.36 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "74191aa6-36a8-44e7-95b8-41311329468b")
	)
	(label "GPIO23/MDC(RMII)"
		(at 210.82 187.96 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "7501f3b0-882f-4da9-aec2-970579b8dfe3")
	)
	(label "GPIO32/REL1"
		(at 261.62 193.04 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "768f1bf0-6fe1-4b25-b106-1a61944abcf1")
	)
	(label "ESP_EN"
		(at 144.78 251.46 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "76cbead0-e399-49b4-910e-ebda18c3a118")
	)
	(label "GPIO33/REL2"
		(at 350.52 193.04 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "79f32e9a-c340-45d6-bbeb-b44eec28ead6")
	)
	(label "VDDCR"
		(at 40.64 289.56 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "7bccbcf8-91f0-4c20-a5b7-847f64a10e2e")
	)
	(label "GPIO27/EMAC_RX_CRS_DV"
		(at 533.4 73.66 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "7d82cba5-eb26-4cee-aba7-d78eaafececb")
	)
	(label "GPIO7/SD_DATA0"
		(at 396.24 66.04 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "82024a41-c99c-4373-9eeb-b4364f099248")
	)
	(label "GPIO10/SD_DATA3"
		(at 396.24 73.66 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "820332d2-25ee-4eaa-95fc-299cc98d488e")
	)
	(label "GPIO22/EMAC_TXD1(RMII)"
		(at 210.82 149.86 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "8254c185-c3a1-4999-812e-941ce8b5f5b1")
	)
	(label "GPI36/U1RXD"
		(at 314.96 266.7 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "83f0c405-5041-4e6f-994c-b7076ca82ce6")
	)
	(label "GPIO15/HS2_CMD"
		(at 533.4 60.96 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "85ac447b-b669-41b3-9c90-a31dd3018001")
	)
	(label "GPIO15/HS2_CMD"
		(at 261.62 271.78 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "861e0563-7207-4de5-92e8-3635b9a9ac4e")
	)
	(label "GPIO15/HS2_CMD"
		(at 388.62 243.84 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "86e45e3b-6f0c-4401-80c0-6b71077bdde7")
	)
	(label "VDD1A-2A"
		(at 119.38 154.94 180)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify right bottom)
		)
		(uuid "87ad690a-93ce-4cd5-a6ba-498fc5fd7108")
	)
	(label "GPIO10/SD_DATA3"
		(at 480.06 55.88 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "8b919200-675a-4a12-b749-e06ce771bbaf")
	)
	(label "GPIO21/EMAC_TX_EN(RMII)"
		(at 396.24 99.06 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "8bdf97f4-bf30-4274-a35b-f25814384f6c")
	)
	(label "GPIO1/U0TXD"
		(at 198.12 337.82 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "8ef4777d-83d8-4b32-9712-018e75a1a6ba")
	)
	(label "GPIO1/U0TXD"
		(at 396.24 50.8 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "913af0e6-7c35-4d3c-a05c-61046dccdeda")
	)
	(label "RMIISEL"
		(at 185.42 172.72 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "92a65f46-aa0d-46a5-aed4-b3919248c172")
	)
	(label "D_Com"
		(at 548.64 264.16 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "92cb122e-c3c7-42fd-9c3b-fd5397f2a499")
	)
	(label "GPIO25/EMAC_RXD0(RMII)"
		(at 210.82 167.64 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "9315d789-a712-4a62-88ad-e4490991eb28")
	)
	(label "GPIO9/SD_DATA2"
		(at 533.4 53.34 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "93550265-b695-4f9b-b020-40f0d002c1e1")
	)
	(label "GPIO8/SD_DATA1"
		(at 480.06 53.34 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "97fb699f-dc92-4842-a8ed-0cb2a43a18ef")
	)
	(label "GPIO17/SPI_CS"
		(at 533.4 63.5 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "98930a8f-a0e5-4bc3-88ff-e7642df94328")
	)
	(label "GPIO3/U0RXD"
		(at 198.12 335.28 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "9ac7ceab-5146-4b16-8297-e22ccce03121")
	)
	(label "GPI35/CAN-RX"
		(at 396.24 121.92 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "9d262d40-ab9b-4dc9-8f16-6f7b7dffdae9")
	)
	(label "GPIO26/EMAC_RXD1(RMII)"
		(at 396.24 109.22 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "9fc0d0a1-0c34-4870-9a39-c2f58a76f830")
	)
	(label "OSC_DIS"
		(at 208.28 398.78 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "a823c0b1-62db-4ba0-b46d-a95242cf06db")
	)
	(label "GPIO6/SD_CLK"
		(at 396.24 63.5 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "a89f6c67-15a2-4408-8f2b-e2439a4168d1")
	)
	(label "GPIO5/CAN-TX"
		(at 396.24 60.96 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "a95b4cae-4298-4364-b259-e3b8f0a646cc")
	)
	(label "GPIO13/I2C-SDA"
		(at 396.24 81.28 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "abf6d7dd-8d06-4814-9f5e-0f2efb461abb")
	)
	(label "GPIO2/HS2_DATA0"
		(at 388.62 259.08 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "acabc940-cfbc-43d1-9d5a-6e7355762d7c")
	)
	(label "PHYAD0"
		(at 208.28 238.76 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "ad89c824-4b10-4e60-9245-4bbc584c5d2c")
	)
	(label "GPI34/BUT1"
		(at 396.24 119.38 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b0330499-0376-4737-a73a-e483aa8cda9d")
	)
	(label "GPIO14/HS2_CLK"
		(at 363.22 256.54 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b0b8d613-8b64-4778-9c96-b2b6a376982c")
	)
	(label "GPIO27/EMAC_RX_CRS_DV"
		(at 396.24 111.76 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b198fb89-57cb-48fb-9392-57ebfb2b9c0b")
	)
	(label "GPIO23/MDC(RMII)"
		(at 480.06 71.12 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "b2bbd6a9-5191-44b4-b8a0-884aff0a25bd")
	)
	(label "TXN-"
		(at 137.16 208.28 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "b4e604f3-1bc6-4548-8fb0-2570f7b34138")
	)
	(label "GPIO27/EMAC_RX_CRS_DV"
		(at 210.82 203.2 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "b9d2251d-9db5-49fc-8574-6ad588e7fcc6")
	)
	(label "RXN-"
		(at 137.16 213.36 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "ba74e980-ae5d-4a49-9232-db5cc5729642")
	)
	(label "GPIO16/I2C-SCL"
		(at 396.24 88.9 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c0012dd4-e072-4571-ba6a-bd80e67b0cd3")
	)
	(label "GPIO14/HS2_CLK"
		(at 396.24 83.82 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c002606d-e960-4c8e-ae46-f4287b03d0c9")
	)
	(label "GPIO12/IR_Transmit"
		(at 480.06 160.02 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "c0baea1d-8a15-4d04-8259-aee1b07eae3d")
	)
	(label "RXP+"
		(at 137.16 210.82 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c1430463-056b-4b36-a098-50c93123aaed")
	)
	(label "GPI39/IR_RECEIVE"
		(at 500.38 198.12 180)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "c22208df-bf6f-4145-9536-03f856097c5b")
	)
	(label "GPIO22/EMAC_TXD1(RMII)"
		(at 533.4 68.58 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "c29862ef-c5b5-49d2-a41d-50af18468390")
	)
	(label "CANL"
		(at 269.24 365.76 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "c2c31478-2868-4de0-bba4-da9cd29f2c7b")
	)
	(label "GPIO4/U1TXD"
		(at 396.24 58.42 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "c507900b-0e98-48fc-ae6b-4dd365d50373")
	)
	(label "GPIO0/XTAL1/CLKIN"
		(at 480.06 43.18 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "ce69c60a-7e6a-494e-8323-1a1ec1e42c18")
	)
	(label "GPIO15/HS2_CMD"
		(at 396.24 86.36 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "ceb3e042-748c-4240-b128-54f18503a114")
	)
	(label "OSC_DIS"
		(at 175.26 287.02 180)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "d14c6485-f97b-4507-9e9c-d41b9cc69af7")
	)
	(label "GPIO0/XTAL1/CLKIN"
		(at 78.74 259.08 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "d1601278-d6ab-4c21-99f8-5908855dc1d4")
	)
	(label "D_Com"
		(at 171.45 391.16 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "d3b04385-b4b8-4c1f-9944-16d7977df1dd")
	)
	(label "GPIO33/REL2"
		(at 533.4 76.2 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "db14bce7-dbe0-403b-8f87-e4565589eeeb")
	)
	(label "CANH"
		(at 269.24 363.22 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "dfcb35a3-0626-4c43-932e-bdafaf5bd007")
	)
	(label "GPIO3/U0RXD"
		(at 396.24 55.88 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "dfcc8084-3096-4a7b-8d6f-2c1204d8eed0")
	)
	(label "OSC_DIS"
		(at 210.82 218.44 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "e094bb17-007c-4ae4-aa1f-1839455713bb")
	)
	(label "GPIO22/EMAC_TXD1(RMII)"
		(at 396.24 101.6 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "e2242927-5e41-4155-bf1f-1c66a707a750")
	)
	(label "GPIO16/I2C-SCL"
		(at 261.62 269.24 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "e36a0f16-1553-4313-a461-2cbb7fad1883")
	)
	(label "ESP_EN"
		(at 220.98 264.16 180)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify right bottom)
		)
		(uuid "e3f49060-3288-4237-a1d0-af589e055aa8")
	)
	(label "GPIO19/EMAC_TXD0(RMII)"
		(at 533.4 66.04 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "e548e72c-9cd3-4c80-b6c7-c5beafbc55ea")
	)
	(label "GPI39/IR_RECEIVE"
		(at 533.4 81.28 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "e79c8ed9-5dae-4c08-829f-3fa301a5a2d6")
	)
	(label "GPIO12/IR_Transmit"
		(at 480.06 58.42 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "ea9c74ab-c04d-451a-b1e3-76232a76e6f1")
	)
	(label "+5V_USB"
		(at 45.72 345.44 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "eeb4965e-4db9-407d-b3f3-d5444086eea8")
	)
	(label "GPIO8/SD_DATA1"
		(at 396.24 68.58 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "efa03703-b8ae-4268-857f-85a76dede9cf")
	)
	(label "PHYAD2"
		(at 185.42 175.26 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "f09081ef-e9ff-4aa0-9668-1c458f72ea94")
	)
	(label "GPIO21/EMAC_TX_EN(RMII)"
		(at 210.82 157.48 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "f229586b-7c0d-4378-9b0d-a2ba2550699a")
	)
	(label "BUT1"
		(at 508 259.08 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "f27faba0-cb73-4a9b-9b87-4bb43fca6f31")
	)
	(label "GPIO17/SPI_CS"
		(at 314.96 274.32 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "f282d505-a49e-41b8-a9ae-4d70e6d443b3")
	)
	(label "GPIO5/CAN-TX"
		(at 378.46 347.98 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "f344e4e4-c186-430e-94f2-1f11167b0b2d")
	)
	(label "GPIO18/MDIO(RMII)"
		(at 480.06 66.04 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "f49f15c3-d1ff-44e5-b1d5-50488e43e99e")
	)
	(label "+5V_USB"
		(at 50.8 35.56 0)
		(effects
			(font
				(size 1.524 1.524)
			)
			(justify left bottom)
		)
		(uuid "f4bc14a5-f048-40f3-b20c-6bdc85d42b2b")
	)
	(label "GPIO13/I2C-SDA"
		(at 533.4 58.42 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "f5a9932b-c5cd-4c93-9a51-6814938fa42c")
	)
	(label "TXP+"
		(at 137.16 205.74 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "fc972e53-fe00-4343-b064-5b0a16062fef")
	)
	(label "GPIO23/MDC(RMII)"
		(at 396.24 104.14 0)
		(effects
			(font
				(size 1.27 1.27)
			)
			(justify left bottom)
		)
		(uuid "fed1b312-e410-4661-9236-2a18f80c2c68")
	)
	(label "GPIO14/HS2_CLK"
		(at 261.62 274.32 0)
		(effects
			(font
				(size 0.9906 0.9906)
			)
			(justify left bottom)
		)
		(uuid "ff675535-75eb-4df5-9785-0587fb156580")
	)
	(symbol
		(lib_name "ESP32-EVB_Rev_K1:PWR-JAKPWR_JACK_UNI_MILLING")
		(lib_id "ESP32-EVB_Rev_K1:PWR-JAKPWR_JACK_UNI_MILLING")
		(at 27.94 63.5 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580db83c")
		(property "Reference" "PWR1"
			(at 27.94 55.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "PWRJ-2mm(YDJ-1134)"
			(at 34.29 58.42 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:PWRJ-2mm(YDJ-1136)"
			(at 27.178 59.69 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 27.94 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 27.94 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 27.94 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 27.94 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 27.94 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "+"
			(uuid "fd8809f5-7d87-4337-94f7-6d2dfb5fc088")
		)
		(pin "-"
			(uuid "86fbb308-974b-4ea8-aa77-bd3fe6acc4fd")
		)
		(pin "-"
			(uuid "d910cde2-ebce-4ec1-b639-bb498e4f8f1e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "PWR1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 40.64 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dbd62")
		(property "Reference" "#PWR01"
			(at 40.64 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 40.64 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 40.64 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 40.64 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 40.64 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "31bb4f39-b9e3-4a07-8ec3-d66b27717574")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR01")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:TESTPAD")
		(at 33.02 83.82 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dbda3")
		(property "Reference" "GND1"
			(at 30.48 81.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "TESTPAD"
			(at 35.56 80.899 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
				(hide yes)
			)
		)
		(property "Footprint" "OLIMEX_Other-FP:TESTPAD_40-ROUND"
			(at 39.116 81.915 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 33.02 83.82 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 33.02 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 33.02 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 33.02 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 33.02 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "12dc450b-fc8e-44a4-ab3e-74bdc6536085")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "GND1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 58.42 91.44 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dbee4")
		(property "Reference" "#FLG02"
			(at 58.42 89.027 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 58.42 85.7504 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 58.42 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 58.42 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 58.42 91.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7605fdae-fc49-487b-921c-1603664d997b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG02")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 58.42 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dbf00")
		(property "Reference" "#PWR03"
			(at 58.42 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 58.42 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 58.42 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 58.42 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 58.42 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ee115700-113f-404b-8656-0b67493cee2e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR03")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SMBJ6.0A")
		(at 73.66 66.04 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dc038")
		(property "Reference" "D2"
			(at 74.93 60.325 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "SMBJ6.0A(DO-214AA)"
			(at 74.93 69.85 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:DO214AA_1(K)-2(A)"
			(at 77.47 65.278 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 73.66 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 73.66 66.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 73.66 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 73.66 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 73.66 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1e3b705d-585c-41e6-b7b7-fb029695a3b7")
		)
		(pin "2"
			(uuid "fe9e5b92-f971-40b3-a37b-0f59299841e7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 73.66 43.18 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dc57f")
		(property "Reference" "#FLG04"
			(at 73.66 40.767 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 73.66 37.4904 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 73.66 43.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 73.66 43.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 73.66 43.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5d9c1b5b-2685-48e5-b0c7-cedb1b49be12")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG04")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 78.74 60.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dc741")
		(property "Reference" "C1"
			(at 77.724 59.182 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "NA(47uF/6.3V/20%/X5R/C0805)"
			(at 77.47 93.98 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0805_5MIL_DWS"
			(at 78.74 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 78.74 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 78.74 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 78.74 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 78.74 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 78.74 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6905d2e4-029d-4684-aa35-43c0b68875db")
		)
		(pin "2"
			(uuid "c96c1b1a-c0ec-4d13-8654-3fd2eee27a0e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 83.82 60.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dc771")
		(property "Reference" "C2"
			(at 82.804 59.182 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "47uF/6.3V/20%/X5R/C0805"
			(at 82.804 89.916 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0805_5MIL_DWS"
			(at 83.82 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 83.82 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 83.82 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 83.82 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 83.82 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 83.82 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "15b4f947-e0e1-4b68-a360-2fa9dcb56625")
		)
		(pin "2"
			(uuid "b2421b12-b47c-4fc9-b88d-23603d90802b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+5V")
		(at 88.9 38.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dd76c")
		(property "Reference" "#PWR05"
			(at 88.9 41.91 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 88.9 34.544 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 88.9 38.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 88.9 38.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 88.9 38.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0f0a095a-b302-4569-9a51-076206a4cf80")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR05")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 88.9 80.01 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580dd9e6")
		(property "Reference" "R4"
			(at 86.868 79.248 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "2.2k/R0603"
			(at 91.186 74.422 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 87.122 80.01 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 88.9 80.01 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 88.9 80.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 88.9 80.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 88.9 80.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 88.9 80.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "cad0ddcd-2b62-464d-9805-91a174ab54dc")
		)
		(pin "2"
			(uuid "4040ae6c-941a-4d20-8de1-7c69d6e1f6ee")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:LED")
		(at 88.9 53.34 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580de2d7")
		(property "Reference" "PWRLED1"
			(at 85.852 48.768 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "LED/RED/0603"
			(at 91.44 45.72 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_LEDs-FP:LED_0603_KA"
			(at 88.9 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 88.9 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 88.9 53.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 88.9 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 88.9 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 88.9 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8051e39e-ba2d-4718-927e-8c011b52b505")
		)
		(pin "2"
			(uuid "07f24dbd-03cc-4e19-a8f5-5ce84ed8d8f8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "PWRLED1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 88.9 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580de3c4")
		(property "Reference" "#PWR06"
			(at 88.9 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 88.9 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 88.9 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 88.9 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 88.9 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ac3d97c4-9b39-42e3-bbb2-afcf704b3795")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR06")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 83.82 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580df120")
		(property "Reference" "#PWR07"
			(at 83.82 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 83.82 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 83.82 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 83.82 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 83.82 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "28f048ff-bb1a-46f1-90e0-7ec8bc62b4d8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR07")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 78.74 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580df161")
		(property "Reference" "#PWR08"
			(at 78.74 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 78.74 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 78.74 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 78.74 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 78.74 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8dc34e45-6bd9-4e0c-8971-0d967f5cbdac")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR08")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 73.66 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580df187")
		(property "Reference" "#PWR09"
			(at 73.66 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 73.406 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 73.66 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 73.66 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 73.66 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8430b831-b548-4f75-8de2-97f941c50ddc")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR09")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 182.88 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e092e")
		(property "Reference" "#PWR010"
			(at 182.88 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 182.88 105.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 182.88 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 182.88 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 182.88 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b1b096b8-c3ee-4e04-b3d3-d74c744f58d3")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR010")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SY8009AAAC(SOT23-5)")
		(at 198.12 81.28 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e129e")
		(property "Reference" "U2"
			(at 195.326 74.422 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "SY8089AAAC(SOT23-5)"
			(at 198.12 87.63 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_Regulators-FP:SOT-23-5"
			(at 198.882 77.47 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 198.12 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 198.12 81.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 198.12 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 198.12 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 198.12 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f1f16537-40d3-42db-ab25-93760cd4fb43")
		)
		(pin "2"
			(uuid "a0b56033-4d46-438d-bb6f-45cb59917a90")
		)
		(pin "3"
			(uuid "f3007c88-ff47-4389-ac5e-03b888e4a373")
		)
		(pin "4"
			(uuid "93dc7b44-cc9d-48d6-a8ca-3b0b9355bbaa")
		)
		(pin "5"
			(uuid "0bcd0292-ca65-4cee-b0b5-5846b1f3f9ff")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:L")
		(at 213.36 78.74 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e1fa3")
		(property "Reference" "L2"
			(at 213.36 73.6854 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "2.2uH/1.5A/DCR=72mR/20%/3.00x3.00x1.50mm/CD32(NR3015T2R2M)"
			(at 214.884 76.073 0)
			(effects
				(font
					(size 0.381 0.381)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:CD32"
			(at 212.09 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 212.09 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 213.36 78.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 213.36 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 213.36 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 213.36 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0acfe543-e220-482f-8a09-054f1753a026")
		)
		(pin "2"
			(uuid "9b241e71-c870-43f5-a99a-70ac70166b93")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "L2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 214.63 81.28 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e2698")
		(property "Reference" "R19"
			(at 219.202 80.264 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "220k/R0603"
			(at 214.884 83.058 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 214.63 83.058 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 214.63 81.28 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 214.63 81.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 214.63 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 214.63 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 214.63 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6a979d95-984d-4ce4-ad99-63473165b5bd")
		)
		(pin "2"
			(uuid "f4b6b43e-a0ac-402f-b194-7d9af0bb71e8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R19")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 214.63 86.36 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e2cab")
		(property "Reference" "R20"
			(at 219.202 85.344 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "49.9k/1%/R0603"
			(at 214.884 88.138 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 214.63 88.138 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 214.63 86.36 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 214.63 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 214.63 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 214.63 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 214.63 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e4305a42-a88a-4c67-94ce-ba7087f65f86")
		)
		(pin "2"
			(uuid "8b56cb30-5d2b-433c-9a15-b496354e90f7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R20")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 226.06 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e37cf")
		(property "Reference" "#PWR011"
			(at 226.06 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 226.06 105.156 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 226.06 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 226.06 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 226.06 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "149f2c5a-995a-444c-8304-3a711b424953")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR011")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 233.68 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e3c89")
		(property "Reference" "#PWR012"
			(at 233.68 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 233.68 105.156 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 233.68 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 233.68 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 233.68 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5d722e36-ec80-4e40-b575-6f337b2c66a9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR012")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 220.98 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e3cb9")
		(property "Reference" "#PWR013"
			(at 220.98 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 220.98 105.156 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 220.98 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 220.98 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 220.98 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e3b11066-2ff4-47c2-88ca-aa55e569cb52")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR013")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 226.06 83.82 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e3ce9")
		(property "Reference" "C6"
			(at 224.536 82.804 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 228.6 101.6 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 226.06 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 226.06 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 226.06 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 226.06 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 226.06 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 226.06 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "adcbb1fb-81a5-4c69-b49c-2526ce492afa")
		)
		(pin "2"
			(uuid "d07ebd57-6ec3-4328-8a8e-faed9584eab8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C6")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 233.68 83.82 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e3d5e")
		(property "Reference" "C7"
			(at 232.41 82.804 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 236.22 101.6 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 233.68 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 233.68 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 233.68 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 233.68 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 233.68 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 233.68 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8cb2cdc0-a9a6-4f5a-957a-c6fe2c550719")
		)
		(pin "2"
			(uuid "eda0e0b6-d9cb-4450-9bf0-b41878bf3a86")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C7")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 233.68 73.66 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e51ca")
		(property "Reference" "#PWR014"
			(at 233.68 77.47 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 234.061 69.2658 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 233.68 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 233.68 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 233.68 73.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "9fc94cbc-6376-489a-bfaf-1aa95ddc5c2d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR014")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 226.06 73.66 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e51fe")
		(property "Reference" "#FLG015"
			(at 226.06 71.247 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 220.98 68.58 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 226.06 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 226.06 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 226.06 73.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "35bb08a1-3564-4abb-8ea1-afce90ced413")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG015")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 187.96 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e5d08")
		(property "Reference" "#PWR016"
			(at 187.96 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 187.96 105.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 187.96 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 187.96 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 187.96 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "48ae2147-f489-4489-8723-c702d7576ebc")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR016")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:CON2")
		(at 60.96 71.12 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580e9d4f")
		(property "Reference" "PWR2"
			(at 59.944 67.056 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "NA(TB2 DG306-5.0-2P)"
			(at 58.42 77.724 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:TB2-DG306-5.0_2P"
			(at 59.055 72.39 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 59.055 72.39 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 60.96 71.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 60.96 71.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 60.96 71.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 60.96 71.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c606bb15-217e-42fd-bc9e-017aaf212536")
		)
		(pin "2"
			(uuid "0ee46e99-16ab-4643-8119-5d29dce38735")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "PWR2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 68.58 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580eb7f2")
		(property "Reference" "#PWR017"
			(at 68.58 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 68.58 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 68.58 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 68.58 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 68.58 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b16024f9-70f0-40d6-9281-9ceb51af3af8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR017")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SIDE_WTCM-TR(3x4)")
		(at 492.76 259.08 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580f02b2")
		(property "Reference" "BUT1"
			(at 501.65 255.778 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "T1107A(6x3,8x2,5MM)"
			(at 501.904 260.858 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Buttons-FP:T1107A(6x3,8x2,5MM)"
			(at 492.7854 258.1148 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 492.7854 258.1148 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 492.76 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 492.76 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 492.76 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 492.76 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8d93c6d4-8f62-4203-9b61-7a619bf7493f")
		)
		(pin "2"
			(uuid "fdda0b13-7426-4c79-bca8-700c5a7a10d5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "BUT1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SIDE_WTCM-TR(3x4)")
		(at 492.76 274.32 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580f1a95")
		(property "Reference" "RST1"
			(at 501.65 271.272 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "T1107A(6x3,8x2,5MM)"
			(at 501.904 276.352 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Buttons-FP:T1107A(6x3,8x2,5MM)"
			(at 492.7854 273.3548 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 492.7854 273.3548 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 492.76 274.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 492.76 274.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 492.76 274.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 492.76 274.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1cdafe1d-c40f-4050-8f09-e5c9b81f10c7")
		)
		(pin "2"
			(uuid "c18a8a4d-8f57-40ac-990b-abc9b22fbc2d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RST1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 476.25 259.08 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580f34e3")
		(property "Reference" "R14"
			(at 477.774 257.048 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "220R/R0603"
			(at 481.076 261.112 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 476.25 257.302 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 476.25 259.08 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 476.25 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 476.25 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 476.25 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 476.25 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0fb7241b-8289-4a09-aeb7-58d9dc7df427")
		)
		(pin "2"
			(uuid "60c2a1f0-5eb8-44c2-9805-6397018c4d92")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R14")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 467.36 259.08 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580fa130")
		(property "Reference" "#PWR018"
			(at 461.01 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 463.55 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 467.36 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 467.36 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 467.36 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "00f613d2-b5b7-4bce-9143-ce11631fe711")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR018")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 467.36 274.32 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580fa16e")
		(property "Reference" "#PWR094"
			(at 461.01 274.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 463.55 274.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 467.36 274.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 467.36 274.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 467.36 274.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6e140947-516d-449f-81ba-a4fefed52689")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR094")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 369.57 193.04 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580ff4d4")
		(property "Reference" "R5"
			(at 365.506 191.77 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1k/R0603"
			(at 378.46 191.77 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 369.57 194.818 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 369.57 193.04 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 369.57 193.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 369.57 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 369.57 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 369.57 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "09116d55-a626-4a6c-ba31-bab04c8c0403")
		)
		(pin "2"
			(uuid "2f4ccce1-5e06-4793-b959-1b5a8d7133b7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 369.57 198.12 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000580ff550")
		(property "Reference" "R6"
			(at 365.506 196.596 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 377.19 196.85 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 369.57 199.898 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 369.57 198.12 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 369.57 198.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 369.57 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 369.57 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 369.57 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "888ba94e-505e-44c4-8cea-4d4887981153")
		)
		(pin "2"
			(uuid "b306e2c3-1d37-4b9f-bc2a-f462da408ed7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R6")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky")
		(at 182.88 52.07 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581010c5")
		(property "Reference" "D4"
			(at 184.8866 50.9016 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "1N5822/SS34/SMA"
			(at 185.42 53.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SMA-KA"
			(at 182.88 52.07 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 182.88 52.07 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 182.88 52.07 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 182.88 52.07 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 182.88 52.07 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 182.88 52.07 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "d9135e71-a725-40b1-9253-8fc2d79d5061")
		)
		(pin "2"
			(uuid "94c4fc2c-8872-4882-b12c-1827c25a88bb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Q_NPN_BEC")
		(at 386.08 193.04 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581014d7")
		(property "Reference" "Q2"
			(at 384.302 197.612 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "BC817-40(SOT23)"
			(at 392.176 205.994 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 391.16 190.5 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 386.08 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 386.08 193.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 386.08 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 386.08 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 386.08 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0d67c731-b45d-4664-87d3-0d288f03ceac")
		)
		(pin "2"
			(uuid "019fd733-a8a0-4ccb-a4b2-eb0a52eee02f")
		)
		(pin "3"
			(uuid "aa34f0e8-1ac5-4701-8162-261ef8d139a5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "Q2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 388.62 203.2 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058102d12")
		(property "Reference" "#PWR019"
			(at 388.62 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 388.62 207.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 388.62 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 388.62 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 388.62 203.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e66ab788-2032-4fca-98e1-d04f24b0900d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR019")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 363.22 203.2 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058102d56")
		(property "Reference" "#PWR020"
			(at 363.22 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 363.22 207.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 363.22 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 363.22 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 363.22 203.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "84118f73-c3e3-4128-8f9c-126d92d72f33")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR020")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Relay")
		(at 388.62 177.8 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058103e50")
		(property "Reference" "REL2"
			(at 382.778 172.72 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
				(justify left)
			)
		)
		(property "Value" "RAS-0515"
			(at 380.746 183.388 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Relays-FP:Relay_RAS-05-15"
			(at 388.62 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 388.62 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 388.62 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 388.62 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 388.62 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 388.62 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "96c8ca6e-45cc-403f-af7a-bb0004184934")
		)
		(pin "2"
			(uuid "9b879d3d-cbf4-4833-8edb-9f4d43525f29")
		)
		(pin "COM0"
			(uuid "6db3c501-1b83-4c18-bb26-1e28a93f58da")
		)
		(pin "NC0"
			(uuid "eed19767-58b3-4701-9d18-a70c786cae02")
		)
		(pin "NO0"
			(uuid "add216cf-e191-4913-aa8f-3d0e23bf69cb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "REL2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+5V")
		(at 388.62 165.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581046b1")
		(property "Reference" "#PWR021"
			(at 388.62 168.91 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 388.62 161.544 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 388.62 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 388.62 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 388.62 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1f0a77fc-1b1b-4079-b1b0-eb51aa6f3085")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR021")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky")
		(at 378.46 176.53 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581049fe")
		(property "Reference" "D3"
			(at 380.238 176.53 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "1N5819S4(SOD-123)"
			(at 375.92 166.37 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOD-123_1C-2A_KA"
			(at 378.46 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 378.46 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 378.46 176.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 378.46 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 378.46 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 378.46 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f19f63fe-0807-4ae2-9fd2-121b3588a3d2")
		)
		(pin "2"
			(uuid "6b5e5a89-d642-40b8-ba81-e647e97dbc17")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 398.78 171.45 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058106e4b")
		(property "Reference" "R11"
			(at 396.748 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "2.2k/R0603"
			(at 401.066 165.862 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 397.002 171.45 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 398.78 171.45 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 398.78 171.45 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 398.78 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 398.78 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 398.78 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7205f213-4c16-43a7-81d1-23ac7c3d047a")
		)
		(pin "2"
			(uuid "95025a93-0864-4cb2-b495-1314dd77cc21")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R11")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:LED")
		(at 398.78 182.88 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058106fdb")
		(property "Reference" "LED2"
			(at 395.732 180.086 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "LED/GREEN/0603"
			(at 398.78 190.5 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_LEDs-FP:LED_0603_KA"
			(at 398.78 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 398.78 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 398.78 182.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 398.78 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 398.78 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 398.78 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "d62d65eb-d402-401b-ad5b-4f713eea9482")
		)
		(pin "2"
			(uuid "e286181b-49be-41cc-91cb-0bda24a454fd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "LED2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 280.67 193.04 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c556")
		(property "Reference" "R1"
			(at 275.59 192.024 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1k/R0603"
			(at 288.925 191.77 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 280.67 194.818 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 280.67 193.04 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 280.67 193.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 280.67 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 280.67 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 280.67 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "54791257-3b0a-441c-a012-26be8e0fee77")
		)
		(pin "2"
			(uuid "6cf1f947-7199-488e-a49b-20c478b313c6")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 280.67 198.12 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c55c")
		(property "Reference" "R2"
			(at 275.59 197.104 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 288.544 197.358 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 280.67 199.898 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 280.67 198.12 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 280.67 198.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 280.67 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 280.67 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 280.67 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ecd3db55-4c7b-4a94-8583-f81d4f2dc689")
		)
		(pin "2"
			(uuid "01637e56-4d35-4e14-9f31-58666ac35f18")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Q_NPN_BEC")
		(at 297.18 193.04 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c562")
		(property "Reference" "Q1"
			(at 295.91 197.612 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "BC817-40(SOT23)"
			(at 303.53 206.502 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 302.26 190.5 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 297.18 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 297.18 193.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 297.18 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 297.18 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 297.18 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3cc2d653-345e-48e5-935b-f4cbdc2846b0")
		)
		(pin "2"
			(uuid "ea0f7282-1230-4358-ace6-702644c97095")
		)
		(pin "3"
			(uuid "fcc94b3e-fbbd-4485-a1d7-d60808e3956b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "Q1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 299.72 203.2 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c568")
		(property "Reference" "#PWR022"
			(at 299.72 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 299.72 207.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 299.72 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 299.72 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 299.72 203.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5ddf9dc0-efb4-479d-90f6-375c6b1b4f92")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR022")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 274.32 203.2 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c56e")
		(property "Reference" "#PWR023"
			(at 274.32 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 274.32 207.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 274.32 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 274.32 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 274.32 203.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "44722c5a-3e81-4610-a854-5dd81e7a441c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR023")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Relay")
		(at 299.72 177.8 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c574")
		(property "Reference" "REL1"
			(at 293.878 172.72 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
				(justify left)
			)
		)
		(property "Value" "RAS-0515"
			(at 291.846 183.388 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Relays-FP:Relay_RAS-05-15"
			(at 299.72 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 299.72 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 299.72 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 299.72 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 299.72 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 299.72 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "06f0d9bd-f770-4bee-a3c2-62423d733948")
		)
		(pin "2"
			(uuid "66a05256-c642-4c87-a2e6-45378f3aacfa")
		)
		(pin "COM0"
			(uuid "6de38017-a0ae-46ae-8074-df490fbbd417")
		)
		(pin "NC0"
			(uuid "ad4fee8f-2b27-440d-8d43-6d5157b1437e")
		)
		(pin "NO0"
			(uuid "f215649f-973c-41d8-b4e4-8b6a6f802527")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "REL1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+5V")
		(at 299.72 165.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c57a")
		(property "Reference" "#PWR024"
			(at 299.72 168.91 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 299.72 161.544 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 299.72 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 299.72 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 299.72 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c3ce9a27-c9e6-4252-bc48-d7d27a2e7e7b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR024")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky")
		(at 289.56 176.53 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c580")
		(property "Reference" "D1"
			(at 291.338 176.53 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "1N5819S4(SOD-123)"
			(at 287.02 166.37 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOD-123_1C-2A_KA"
			(at 289.56 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 289.56 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 289.56 176.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 289.56 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 289.56 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 289.56 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "58202afa-fdc4-4437-bacd-1f7bae713bac")
		)
		(pin "2"
			(uuid "3b482067-dd15-4670-8481-cfcefa559be5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 309.88 171.45 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c586")
		(property "Reference" "R3"
			(at 307.848 169.926 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "2.2k/R0603"
			(at 312.42 166.116 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 308.102 171.45 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 309.88 171.45 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 309.88 171.45 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 309.88 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 309.88 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 309.88 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1f8de1fb-1e1a-4dff-9efc-ed6089623499")
		)
		(pin "2"
			(uuid "b5800c7f-6732-44c0-91b3-2909cbd272c7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:LED")
		(at 309.88 182.88 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810c58c")
		(property "Reference" "LED1"
			(at 306.832 180.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "LED/GREEN/0603"
			(at 309.88 190.5 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_LEDs-FP:LED_0603_KA"
			(at 309.88 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 309.88 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 309.88 182.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 309.88 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 309.88 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 309.88 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e6f082bb-3187-4548-9671-91680cbacf1c")
		)
		(pin "2"
			(uuid "4919859b-e664-4285-9646-d96a83f500bd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "LED1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BH10S")
		(at 289.56 269.24 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810e685")
		(property "Reference" "UEXT1"
			(at 289.56 260.096 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "BH10S"
			(at 289.56 278.13 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:UEXT_ML10"
			(at 289.3568 270.4338 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 289.3568 270.4338 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 289.56 269.24 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 289.56 269.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 289.56 269.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 289.56 269.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c3cefd4f-48e5-486c-b59c-79c5dc849434")
		)
		(pin "10"
			(uuid "00b32c58-ef9c-485a-9ce9-ae7273f37553")
		)
		(pin "2"
			(uuid "1926de84-2003-4930-b9b4-19c4e9b36a38")
		)
		(pin "3"
			(uuid "db382db8-1172-40e5-9f4e-d7a06a15895b")
		)
		(pin "4"
			(uuid "b600cd01-b714-4fee-8e30-ccf28e7b651a")
		)
		(pin "5"
			(uuid "72152b81-b84a-412e-bd89-6c233b2e7030")
		)
		(pin "6"
			(uuid "e51884aa-bdd2-42c7-bb2e-3c7c6f5c3ba7")
		)
		(pin "7"
			(uuid "ebb3a336-47a1-417f-a218-b15647b6b25b")
		)
		(pin "8"
			(uuid "8c9b4296-b903-493e-8031-bb3876e325fc")
		)
		(pin "9"
			(uuid "e60799b3-ee8d-4657-b9f1-f97c67f54de2")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "UEXT1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 274.32 257.81 90)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005810f59c")
		(property "Reference" "R18"
			(at 268.986 256.794 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "2.2k/R0603"
			(at 261.112 259.08 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 276.098 257.81 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 274.32 257.81 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 274.32 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 274.32 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 274.32 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 274.32 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "41cacfbb-ddf3-4ca2-86f9-4333d4058a4d")
		)
		(pin "2"
			(uuid "89f97d4c-8052-4280-84fa-4d144b264a33")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R18")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 274.32 231.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005811121b")
		(property "Reference" "#PWR025"
			(at 274.32 234.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 274.701 226.7458 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 274.32 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 274.32 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 274.32 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "563c767d-1aa7-4c1d-a67a-0452771473d1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR025")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 302.26 264.16 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058112459")
		(property "Reference" "#PWR026"
			(at 308.61 264.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 299.466 262.636 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 302.26 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 302.26 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 302.26 264.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6123210f-776b-40c0-a3cb-b3473d172c16")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR026")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 330.2 257.81 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581137c2")
		(property "Reference" "R21"
			(at 329.438 261.112 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "2.2k/R0603"
			(at 329.692 245.11 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 328.422 257.81 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 330.2 257.81 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 330.2 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 330.2 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 330.2 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 330.2 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f4992d87-751c-4ff6-9ace-2b14f8d6f2ee")
		)
		(pin "2"
			(uuid "b12ba95b-3b7b-4f63-875c-322f27deca39")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R21")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 332.74 257.81 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058113859")
		(property "Reference" "R22"
			(at 331.978 261.112 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "10k/R0603"
			(at 332.232 245.618 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 330.962 257.81 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 332.74 257.81 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 332.74 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 332.74 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 332.74 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 332.74 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a7040385-79fa-4e7e-9ed3-8284876de36e")
		)
		(pin "2"
			(uuid "31bca329-9541-4487-b670-ea1b404f5f64")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R22")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Relay")
		(at 325.12 177.8 90)
		(mirror x)
		(unit 2)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005811c329")
		(property "Reference" "REL1"
			(at 327.66 167.64 90)
			(effects
				(font
					(size 1.1938 1.1938)
				)
				(justify left)
			)
		)
		(property "Value" "RAS-0515"
			(at 330.2 170.18 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Relays-FP:Relay_RAS-05-15"
			(at 325.12 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 325.12 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 325.12 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 325.12 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 325.12 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 325.12 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "77900874-5e68-4556-9e18-83dac62995ed")
		)
		(pin "2"
			(uuid "b5997e8b-f74b-4ee5-b604-50569e5947a9")
		)
		(pin "COM0"
			(uuid "42708c3c-8b71-468a-98f4-0a6eef2d5044")
		)
		(pin "NC0"
			(uuid "2e59319f-f7b1-4886-9960-1fe87e2844dc")
		)
		(pin "NO0"
			(uuid "13c50527-ada0-40c0-b56d-1b89d9bc0972")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "REL1")
					(unit 2)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Relay")
		(at 414.02 177.8 90)
		(mirror x)
		(unit 2)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005811c5e2")
		(property "Reference" "REL2"
			(at 416.56 167.64 90)
			(effects
				(font
					(size 1.1938 1.1938)
				)
				(justify left)
			)
		)
		(property "Value" "RAS-0515"
			(at 419.1 170.18 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Relays-FP:Relay_RAS-05-15"
			(at 414.02 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 414.02 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 414.02 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 414.02 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 414.02 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 414.02 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "bda79e94-f915-4fd3-86c3-97427cda83d1")
		)
		(pin "2"
			(uuid "7814adaa-b2fc-4946-9a7e-8b8ad39a3864")
		)
		(pin "COM0"
			(uuid "34e528e4-38f0-440e-9682-b2d7e81e81a2")
		)
		(pin "NC0"
			(uuid "0d221e7b-99c9-4580-a728-d953a38c30c8")
		)
		(pin "NO0"
			(uuid "642b4bfb-e3bd-40d4-9acc-a273574c25b3")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "REL2")
					(unit 2)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:CON3")
		(at 335.28 177.8 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005811ee95")
		(property "Reference" "CON1"
			(at 336.804 172.212 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "TB3-DG306-5.0-3P"
			(at 331.978 184.404 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:TB3-DG306-5.0_3P"
			(at 337.185 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 337.185 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 335.28 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 335.28 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 335.28 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 335.28 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "bd796b19-8ea5-4251-bc19-8d4c4ce36244")
		)
		(pin "2"
			(uuid "cb8abf47-b72c-48d5-b5bc-f51aca9ed52b")
		)
		(pin "3"
			(uuid "8e2c8770-97cb-4615-b0f0-892fa20fbc91")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "CON1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:CON3")
		(at 424.18 177.8 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005811f01f")
		(property "Reference" "CON2"
			(at 425.704 172.466 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "TB3-DG306-5.0-3P"
			(at 420.878 184.15 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:TB3-DG306-5.0_3P"
			(at 426.085 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 426.085 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 424.18 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 424.18 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 424.18 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 424.18 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "bef4289f-0e69-4a3c-924e-677846f11733")
		)
		(pin "2"
			(uuid "13817a11-0480-4e9f-9bc3-fcbc563078e0")
		)
		(pin "3"
			(uuid "00edd361-55ce-40fe-9eac-b38227eb7e1e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "CON2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 81.28 220.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058129115")
		(property "Reference" "C11"
			(at 77.47 219.202 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 58.166 222.758 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 81.28 220.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 81.28 220.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 220.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 81.28 220.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 81.28 220.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 81.28 220.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "797c7441-4000-496a-809a-509a6f69d9d5")
		)
		(pin "2"
			(uuid "726c5820-ec99-4470-90a7-ba927b640f1e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C11")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 81.28 231.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005812e829")
		(property "Reference" "#PWR047"
			(at 81.28 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 81.28 234.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 81.28 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 81.28 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8fb58e03-1785-4371-8d6d-7fe824644997")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR047")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 86.36 173.99 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005812f9f2")
		(property "Reference" "R26"
			(at 87.63 166.878 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "220R/R0603"
			(at 87.376 176.784 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 84.582 173.99 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 86.36 173.99 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 86.36 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 86.36 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 86.36 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 86.36 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "333c8377-b662-4ac4-81f9-5e25834eaaa6")
		)
		(pin "2"
			(uuid "0be76d04-9ed9-4276-81bb-9467d134e10d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R26")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 88.9 173.99 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005812fbbc")
		(property "Reference" "R28"
			(at 90.17 166.878 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "49.9R/1%/R0402"
			(at 89.916 176.784 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0402_5MIL_DWS"
			(at 87.122 173.99 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 88.9 173.99 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 88.9 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 88.9 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 88.9 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 88.9 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5c333bec-b163-4862-8ce6-d3f4f2cb121c")
		)
		(pin "2"
			(uuid "8c642f24-10ae-481a-977d-18173685de7d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R28")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 91.44 173.99 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005812fcdb")
		(property "Reference" "R31"
			(at 92.71 166.878 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "49.9R/1%/R0402"
			(at 92.456 176.784 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0402_5MIL_DWS"
			(at 89.662 173.99 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 91.44 173.99 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 91.44 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 91.44 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 91.44 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 91.44 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "65f70ba3-74fb-49ac-9ade-d3008d1a5fc1")
		)
		(pin "2"
			(uuid "aa1c2638-2b59-4754-8918-e9b2c97794bd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R31")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 93.98 173.99 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005812fdfd")
		(property "Reference" "R32"
			(at 95.25 166.878 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "49.9R/1%/R0402"
			(at 94.996 176.784 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0402_5MIL_DWS"
			(at 92.202 173.99 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 93.98 173.99 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 93.98 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 93.98 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 93.98 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 93.98 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "edec2792-7687-4c6b-80f4-1592c9338596")
		)
		(pin "2"
			(uuid "1970053a-f238-4a7a-ad08-4cde797cde0f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R32")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 96.52 173.99 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005813035e")
		(property "Reference" "R33"
			(at 98.044 166.878 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "49.9R/1%/R0402"
			(at 97.536 176.784 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0402_5MIL_DWS"
			(at 94.742 173.99 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 96.52 173.99 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 96.52 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 96.52 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 96.52 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 96.52 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "67b207f3-785d-4163-8574-fb6598925158")
		)
		(pin "2"
			(uuid "f07b4071-147b-44c0-aba8-2beb004f5c92")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R33")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Mounting_hole_Shield_3.3mm")
		(at 501.65 314.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058133f16")
		(property "Reference" "MH2"
			(at 504.9012 314.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "Mounting_hole_Shield_3.3mm"
			(at 499.11 317.881 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
				(hide yes)
			)
		)
		(property "Footprint" "OLIMEX_Other-FP:Mounting_hole_Shield_3.3mm"
			(at 495.554 316.865 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 501.65 314.96 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 501.65 314.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 504.9012 316.1284 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 501.65 314.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 501.65 314.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "GND1"
			(uuid "735ac41c-e8a4-4a2e-ae2a-632e076f7079")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "MH2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Mounting_hole_Shield_3.3mm")
		(at 501.65 320.04 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058134022")
		(property "Reference" "MH3"
			(at 504.9012 320.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "Mounting_hole_Shield_3.3mm"
			(at 499.11 322.961 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
				(hide yes)
			)
		)
		(property "Footprint" "OLIMEX_Other-FP:Mounting_hole_Shield_3.3mm"
			(at 495.554 321.945 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 501.65 320.04 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 501.65 320.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 504.9012 321.2084 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 501.65 320.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 501.65 320.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "GND1"
			(uuid "0c545fe3-c440-46aa-b3a5-03186eb6cd48")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "MH3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 494.03 314.96 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581353f7")
		(property "Reference" "#PWR061"
			(at 487.68 314.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 490.7788 315.087 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 494.03 314.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 494.03 314.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 494.03 314.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c6d4dfb8-0310-4af3-85dc-97070e0681c4")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR061")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 494.03 320.04 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058135570")
		(property "Reference" "#PWR062"
			(at 487.68 320.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 490.7788 320.167 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 494.03 320.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 494.03 320.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 494.03 320.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e9e925cb-9a1a-4458-9b2f-6622112bfd4f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR062")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:P-MOS+DIOD")
		(at 172.72 60.96 0)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005813e337")
		(property "Reference" "FET1"
			(at 172.72 50.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify right)
			)
		)
		(property "Value" "WPM2015-3/TR"
			(at 172.72 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 172.72 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c665ec50-89c2-4098-915c-1e6000610d91")
		)
		(pin "2"
			(uuid "e68a7ca5-f3fd-4f36-a0ab-a0a36c570465")
		)
		(pin "3"
			(uuid "2220a8e7-6fef-4d89-8341-5223ad4bbea8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "FET1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 121.92 170.18 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005813f14f")
		(property "Reference" "C17"
			(at 121.158 177.546 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 124.46 177.8 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 121.92 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 121.92 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 121.92 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 121.92 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 121.92 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 121.92 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "89b32e64-fc0c-4cc4-99ab-9247132d7d93")
		)
		(pin "2"
			(uuid "85943485-0412-494d-9487-4a5fc7323112")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C17")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 116.84 170.18 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005813f219")
		(property "Reference" "C16"
			(at 115.824 177.546 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "2.2uF/6.3V/10%/X5R/C0603"
			(at 119.126 178.054 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 116.84 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 116.84 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 116.84 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 116.84 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 116.84 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 116.84 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "026cc7a0-e2a5-42d7-afd1-c2639abdeb43")
		)
		(pin "2"
			(uuid "c68ed1b6-f65b-4d76-81e9-c6ecee6373ca")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C16")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BAT_CON")
		(at 167.64 87.63 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581425a7")
		(property "Reference" "BAT1"
			(at 164.846 82.296 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "DW02R"
			(at 164.084 92.964 0)
			(effects
				(font
					(size 1.2954 1.2954)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:LIPO_BAT-CON2DW02R"
			(at 167.64 87.63 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 167.64 87.63 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 167.64 87.63 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 167.64 87.63 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 167.64 87.63 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 167.64 87.63 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "85c4e0db-7849-477b-9e18-0c9650efc7f0")
		)
		(pin "2"
			(uuid "c45bbbc2-70da-4af9-9158-9949f7fd70e6")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "BAT1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 162.56 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058142b69")
		(property "Reference" "#PWR031"
			(at 162.56 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 162.56 105.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 162.56 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 162.56 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 162.56 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "d4e39b8f-58fe-4163-9e32-e0f623072399")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR031")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 168.91 73.66 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058144979")
		(property "Reference" "R17"
			(at 168.91 71.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA/R0603"
			(at 168.91 76.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 168.91 75.438 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 168.91 73.66 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 168.91 73.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 168.91 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 168.91 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 168.91 73.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "624fbc0c-abd9-4d01-b769-377e1bf2e551")
		)
		(pin "2"
			(uuid "431a8af3-6017-4ece-8ad9-fca32aaca0a0")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R17")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 175.26 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058146e88")
		(property "Reference" "#PWR032"
			(at 175.26 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 175.26 105.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 175.26 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 175.26 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 175.26 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "d74bf5d2-3cb8-4ad4-b439-cd8be8f6c326")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR032")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 111.76 165.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058147148")
		(property "Reference" "C15"
			(at 110.998 164.338 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 114.046 172.466 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 111.76 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 111.76 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 111.76 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 111.76 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 111.76 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 111.76 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6605d444-77f3-4b62-937b-15bf510f4e59")
		)
		(pin "2"
			(uuid "8c4c498d-d376-48fb-8f63-732ddecb2072")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C15")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 106.68 165.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058147214")
		(property "Reference" "C14"
			(at 105.918 164.338 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 108.966 172.466 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 106.68 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 106.68 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 106.68 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 106.68 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 106.68 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 106.68 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e203daad-fd29-4167-9f4d-41e746a72fa8")
		)
		(pin "2"
			(uuid "0d514d13-133b-4131-b921-4129fecfbb8d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C14")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 101.6 165.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058147339")
		(property "Reference" "C12"
			(at 100.584 164.338 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 103.886 172.466 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 101.6 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 101.6 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 101.6 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 101.6 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 101.6 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 101.6 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "aa1b23aa-0bd6-4dc8-9f2a-c321b93d8069")
		)
		(pin "2"
			(uuid "d0d5f36c-21e5-4e02-bbc5-52710240d51f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C12")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 284.48 48.26 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005815346c")
		(property "Reference" "#PWR095"
			(at 284.48 52.07 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 284.861 43.8658 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 284.48 48.26 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 284.48 48.26 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 284.48 48.26 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c08cefe9-ee76-48f4-8387-dc31f26a9aac")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR095")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 284.48 50.8 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058153b20")
		(property "Reference" "#PWR033"
			(at 278.13 50.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 281.2288 50.927 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 284.48 50.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 284.48 50.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 284.48 50.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b9c55e68-907d-42db-8de4-e22fb915808a")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR033")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 284.48 63.5 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005815405b")
		(property "Reference" "#PWR034"
			(at 278.13 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 281.2288 63.627 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 284.48 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 284.48 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 284.48 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f4608a1b-4b69-403c-99b7-fb9c8daf2f1e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR034")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 101.6 182.88 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058154b05")
		(property "Reference" "#PWR048"
			(at 101.6 189.23 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 101.727 187.2742 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 101.6 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 101.6 182.88 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 101.6 182.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b11ee39a-41fc-4c0c-8ddf-445af08eed9f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR048")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 266.7 63.5 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581571ab")
		(property "Reference" "#PWR035"
			(at 266.7 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 264.16 59.69 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 266.7 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 266.7 63.5 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 266.7 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ab3f91af-7873-4559-a39e-5fef3c34f2bc")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR035")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 86.36 219.71 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581578b5")
		(property "Reference" "R27"
			(at 88.138 218.7448 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "220R/R0603"
			(at 88.138 220.853 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 84.582 219.71 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 86.36 219.71 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 86.36 219.71 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 86.36 219.71 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 86.36 219.71 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 86.36 219.71 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "90273061-bc57-40b5-a8d6-bb19deb82f30")
		)
		(pin "2"
			(uuid "7bd0198b-817c-40f3-874a-206b92d29c43")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R27")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 86.36 231.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058158ed7")
		(property "Reference" "#PWR049"
			(at 86.36 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 86.36 234.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 86.36 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 86.36 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 86.36 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "82f255f3-d094-4a65-b006-b47d9fd9a06c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR049")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:LAN8710A-EZC(QFN32)")
		(at 162.56 180.34 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058160809")
		(property "Reference" "U4"
			(at 172.212 143.256 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "LAN8710A-EZC(QFN32)"
			(at 162.306 217.678 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:QFN32_EP(33)_5.00x5.00x0.90mm_Pitch_0.50mm"
			(at 172.72 180.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 172.72 180.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 162.56 180.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 162.56 180.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 162.56 180.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 162.56 180.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "58aeadaf-d1b6-40e7-8e02-ba4d87e1c8af")
		)
		(pin "10"
			(uuid "2d6977fc-7d50-444d-bdbb-1b2789e67b17")
		)
		(pin "11"
			(uuid "08dd1817-a4f7-480c-9542-838ab804948d")
		)
		(pin "12"
			(uuid "fbd4c776-d1b7-4056-8572-ac552a0c6f23")
		)
		(pin "13"
			(uuid "bdea8a10-7b6f-47c1-a281-b5e0090c05d6")
		)
		(pin "14"
			(uuid "0d1866be-b570-49ac-93ff-221adede37cf")
		)
		(pin "15"
			(uuid "38559c6d-0e9e-4403-b903-398df608d1ab")
		)
		(pin "16"
			(uuid "c6ff3daf-ca53-441d-a534-60d510139bf8")
		)
		(pin "17"
			(uuid "098ff278-23e0-492d-977b-6688d9ad1ef9")
		)
		(pin "18"
			(uuid "9702e064-9b5b-4c63-ad8f-12fef318beaa")
		)
		(pin "19"
			(uuid "00f9635a-e81a-45b3-add4-c830fe7d0b74")
		)
		(pin "2"
			(uuid "4917593a-16dc-4083-b553-4330ece8ee24")
		)
		(pin "20"
			(uuid "ccf0111c-fe2f-4faa-8c06-826c2c58ccae")
		)
		(pin "21"
			(uuid "d59c9df6-5d01-4b6b-b954-b36d7064d206")
		)
		(pin "22"
			(uuid "f0784981-9c06-4cca-ad05-b4cd0c80cac8")
		)
		(pin "23"
			(uuid "9857a40a-ef11-443a-a40d-ec5ddc250b20")
		)
		(pin "24"
			(uuid "e9e8929e-2009-4177-8d49-d66323532c7e")
		)
		(pin "25"
			(uuid "e943e9db-34a3-4465-8731-abcb33c3d894")
		)
		(pin "26"
			(uuid "84817f1c-e556-4274-8b3b-b56f7e3025b6")
		)
		(pin "27"
			(uuid "bbf1c0b5-06f4-48f1-919e-fcd632f21256")
		)
		(pin "28"
			(uuid "067f9db8-6646-4105-aa91-f28c25c6b1f5")
		)
		(pin "29"
			(uuid "342786ee-36f9-416e-99d9-6f9c0a63a931")
		)
		(pin "3"
			(uuid "2765bf6b-e800-46ea-97d8-a28968958453")
		)
		(pin "30"
			(uuid "1efa54c1-e1f1-40c3-b313-69139b90afb7")
		)
		(pin "31"
			(uuid "6fbbc530-87fc-4e70-ae03-6413b9835db7")
		)
		(pin "32"
			(uuid "ff710803-a1c6-47c4-a8c3-0a30a81569b1")
		)
		(pin "33"
			(uuid "4ced39b7-4096-4f98-b8df-9d3dc9a7aa9a")
		)
		(pin "4"
			(uuid "cab629d3-9deb-43b9-a095-967fd9781ac7")
		)
		(pin "5"
			(uuid "8092501a-e268-4bb6-b970-7db2fb50d27d")
		)
		(pin "6"
			(uuid "3ff2f9b0-75ac-49ca-b041-2a5604d563d3")
		)
		(pin "7"
			(uuid "14b2b513-c1b6-4f10-83ba-696803b0eadc")
		)
		(pin "8"
			(uuid "f5331298-39cd-46a2-abe2-44209cca4823")
		)
		(pin "9"
			(uuid "a95c11e7-17eb-4b43-801f-fd21e26fed93")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Oscillator-100MHZ_TXC-7W")
		(at 48.26 259.08 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058165c9f")
		(property "Reference" "CR1"
			(at 43.688 250.19 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "Q50MHz/25ppm/3V/4P/5x3.2mm"
			(at 58.42 268.732 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_Crystal-FP:5032-4P_HCX-3S"
			(at 49.022 255.27 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 48.26 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 48.26 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 48.26 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 48.26 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 48.26 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "08634574-206d-4803-9732-3d6af56b0ec1")
		)
		(pin "2"
			(uuid "f303e7f6-bc11-4996-bfbc-a281d2fb3735")
		)
		(pin "3"
			(uuid "2cac95aa-b6c9-43c9-bac9-337405a002ac")
		)
		(pin "4"
			(uuid "a5a7a73d-6b4f-498b-94e8-b54acffcb37b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "CR1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 35.56 243.84 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581681aa")
		(property "Reference" "#PWR050"
			(at 35.56 247.65 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 35.941 239.4458 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 35.56 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 35.56 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 35.56 243.84 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "4be12af4-5710-4401-83e7-268bf73aaebd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR050")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 46.99 246.38 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581684fa")
		(property "Reference" "R34"
			(at 41.148 245.364 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 57.15 245.11 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 46.99 248.158 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 46.99 246.38 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 46.99 246.38 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 46.99 246.38 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 46.99 246.38 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 46.99 246.38 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3191552f-de24-495d-8036-e8aed573a228")
		)
		(pin "2"
			(uuid "e9c46131-11d4-4964-bf2b-20165607abeb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R34")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 69.85 259.08 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058171ef1")
		(property "Reference" "R36"
			(at 69.85 257.175 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10R/R0603"
			(at 69.85 260.985 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 69.85 260.858 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 69.85 259.08 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 69.85 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 69.85 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 69.85 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 69.85 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3e11d398-5704-418c-b9cc-460be03a8686")
		)
		(pin "2"
			(uuid "fcb13518-82d4-4332-95e6-58b14b877ca2")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R36")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:MICRO_SD(TFC-WXCP11-08-LF)")
		(at 441.96 256.54 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005817a7cb")
		(property "Reference" "MICRO_SD1"
			(at 431.8 242.57 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "TFC-WXCP11-08-LF"
			(at 424.18 274.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:TFC-WXCP11-08-LF"
			(at 442.722 252.73 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 441.96 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 441.96 256.54 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 441.96 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 441.96 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 441.96 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e19d5dd6-5766-4df0-8ad8-6a39791e90b7")
		)
		(pin "2"
			(uuid "734e4f93-d97e-4453-902e-507b2f7c0949")
		)
		(pin "3"
			(uuid "448e630e-0085-4b45-9869-c4145421c2b5")
		)
		(pin "4"
			(uuid "093e8027-3294-492c-be0e-6a90ba903b63")
		)
		(pin "5"
			(uuid "e7a8e78f-3b5c-4fba-8b1e-9425249e4daf")
		)
		(pin "6"
			(uuid "8464e9ec-377a-4a01-80d9-5d6c2fbf6cfe")
		)
		(pin "7"
			(uuid "ed9762c3-d089-4f2f-8d41-be06b0c148d4")
		)
		(pin "8"
			(uuid "a4d280ce-91a8-4a16-98e0-aa0a01825bfa")
		)
		(pin "SH1"
			(uuid "41adcc35-7845-4421-b444-dd0f674577ab")
		)
		(pin "SH2"
			(uuid "ae30a05d-61e7-4b3f-9a5d-81523cbc34f9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "MICRO_SD1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 223.52 152.4 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581809ae")
		(property "Reference" "#PWR036"
			(at 229.87 152.4 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 226.7712 152.273 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 223.52 152.4 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 223.52 152.4 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 152.4 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "69aba386-2d41-4d0d-8a07-2725b4abed6e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR036")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 195.58 245.11 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005818206d")
		(property "Reference" "RM2"
			(at 202.946 240.284 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 180.34 240.284 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 196.85 247.65 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 196.85 247.65 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 195.58 245.11 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "7f81be17-6e53-4678-8524-1874499fd00a")
		)
		(pin "1.2"
			(uuid "d589506c-8c46-4ced-a535-1e645c52cb56")
		)
		(pin "2.1"
			(uuid "bc439cef-1957-482c-b7c4-51ae35148e79")
		)
		(pin "2.2"
			(uuid "d281f87d-b545-4da3-aaf5-a9ab379f89c7")
		)
		(pin "3.1"
			(uuid "5eb493c5-7220-4b22-a5ac-fff1a59bf666")
		)
		(pin "3.2"
			(uuid "8e4feb0d-57de-407f-acee-f3dcdfe08f11")
		)
		(pin "4.1"
			(uuid "d5e397cb-58c6-43b1-9bd6-500aef74209b")
		)
		(pin "4.2"
			(uuid "ce266581-f47e-4230-8d20-84b5f0e381be")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 195.58 247.65 0)
		(unit 2)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058182187")
		(property "Reference" "RM2"
			(at 202.946 242.824 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 180.594 242.824 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 196.85 250.19 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 196.85 250.19 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 195.58 247.65 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "9faa4f8c-e1fc-4e6f-b959-adee2b93b240")
		)
		(pin "1.2"
			(uuid "9b96f2ee-ca23-4b30-b2ba-6312fa878863")
		)
		(pin "2.1"
			(uuid "b59b1199-2a88-4365-b796-0766ddceef2c")
		)
		(pin "2.2"
			(uuid "6d960968-123a-4f52-8f10-8205c59081b4")
		)
		(pin "3.1"
			(uuid "4858d10c-cb34-4b4d-aa92-703e12daf1b6")
		)
		(pin "3.2"
			(uuid "3917daae-3644-4f02-8801-5546fccd707b")
		)
		(pin "4.1"
			(uuid "9acbd5d5-7b2f-498e-ab66-8f2de8c77435")
		)
		(pin "4.2"
			(uuid "ce132c21-cfeb-4a8b-aebc-1d0ed177019e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM2")
					(unit 2)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 195.58 250.19 0)
		(unit 3)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058182312")
		(property "Reference" "RM2"
			(at 202.946 245.11 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 180.594 245.364 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 196.85 252.73 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 196.85 252.73 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 195.58 250.19 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "962a33b5-7073-4c8e-a41e-6464e8899027")
		)
		(pin "1.2"
			(uuid "02da16ba-d46a-4a92-b916-a0c413706a6b")
		)
		(pin "2.1"
			(uuid "97a0379a-1203-4b3d-ad34-279d82897940")
		)
		(pin "2.2"
			(uuid "710186b5-3c53-4614-8548-958c7e324b34")
		)
		(pin "3.1"
			(uuid "4e533378-bfe4-4183-8d7f-82e39cf2e385")
		)
		(pin "3.2"
			(uuid "b6c7d384-fe29-4cfc-b47b-b202442e867e")
		)
		(pin "4.1"
			(uuid "7479731a-01f8-483f-8184-5831224fc916")
		)
		(pin "4.2"
			(uuid "e76656cb-4b48-48b8-a167-970334526d54")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM2")
					(unit 3)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 210.82 158.75 180)
		(unit 4)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058182428")
		(property "Reference" "RM2"
			(at 217.932 161.544 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 195.58 161.29 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 209.55 156.21 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 209.55 156.21 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 210.82 158.75 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "1e76e44e-de8c-4676-abd7-883f69d50bde")
		)
		(pin "1.2"
			(uuid "602a0eba-3194-4964-9072-859caf5790f3")
		)
		(pin "2.1"
			(uuid "dbcabb3d-c04c-4bc0-a320-fcf59f016ad7")
		)
		(pin "2.2"
			(uuid "51e2f379-c26c-4841-a281-3652f52dd35b")
		)
		(pin "3.1"
			(uuid "03b6b0a5-b0c3-41bb-ace6-66cc25857c79")
		)
		(pin "3.2"
			(uuid "63d2885a-6d55-4fa7-b601-2a1a5edc9d5f")
		)
		(pin "4.1"
			(uuid "0f9765d1-c3ae-4721-870b-ec5e8151ed98")
		)
		(pin "4.2"
			(uuid "cff705af-83ea-45a2-9bc9-868888b3284b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM2")
					(unit 4)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 167.64 259.08 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005818bcd7")
		(property "Reference" "#PWR051"
			(at 167.64 265.43 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 167.64 262.89 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 167.64 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 167.64 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 167.64 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a6635c08-b098-4807-b7b0-d7ab2ae5381b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR051")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 203.2 196.85 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058191f56")
		(property "Reference" "RM3"
			(at 210.312 192.024 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 197.104 194.818 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 204.47 199.39 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 204.47 199.39 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 203.2 196.85 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "d1725857-8c46-4859-9109-3e4d3a0dc1ed")
		)
		(pin "1.2"
			(uuid "2fcecf7c-acbd-4c41-91ce-3126b96f9c92")
		)
		(pin "2.1"
			(uuid "8b82e3ad-858f-4b67-bb24-ba8a56a5fdc1")
		)
		(pin "2.2"
			(uuid "3d09a9b9-a636-4eef-b84e-12ceef32f58d")
		)
		(pin "3.1"
			(uuid "6b482158-c7e6-4f98-bcc3-3a967d5f0ddb")
		)
		(pin "3.2"
			(uuid "740d6cbe-a2a8-428e-a8da-fa7c3dde9a71")
		)
		(pin "4.1"
			(uuid "90925cc1-0f8d-437b-840e-6f00ab52406b")
		)
		(pin "4.2"
			(uuid "9fa8a269-a7f7-4722-8aa9-653a35002e09")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 203.2 204.47 0)
		(unit 2)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005819206c")
		(property "Reference" "RM3"
			(at 210.312 199.644 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 197.104 197.866 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 204.47 207.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 204.47 207.01 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 203.2 204.47 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "441f54f5-9c2b-4368-b377-d7d153d31fb2")
		)
		(pin "1.2"
			(uuid "e60d2205-e1b9-49a7-95ae-2efa00779894")
		)
		(pin "2.1"
			(uuid "d9a23649-561b-4499-afcb-377c52644ea1")
		)
		(pin "2.2"
			(uuid "76b05ca9-dd07-4e95-8ac8-5e3492a01ca7")
		)
		(pin "3.1"
			(uuid "c9bb5678-0441-457a-9179-4a728817676d")
		)
		(pin "3.2"
			(uuid "781bbf43-55d6-4bd0-8cea-9f12f611e5a6")
		)
		(pin "4.1"
			(uuid "da853de5-fb4d-4cc9-9af7-12b22ff048c2")
		)
		(pin "4.2"
			(uuid "0432d8eb-4f21-49b3-90c1-54f60ec24a49")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM3")
					(unit 2)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 210.82 168.91 0)
		(unit 3)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005819217a")
		(property "Reference" "RM3"
			(at 218.44 163.83 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 195.58 163.83 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 212.09 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 212.09 171.45 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 210.82 168.91 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "4bd280ff-ca51-4f03-95f1-edee2aa05e32")
		)
		(pin "1.2"
			(uuid "b238bda2-9bcb-41c1-8a16-b2be920750f2")
		)
		(pin "2.1"
			(uuid "eecdfcc2-a304-412d-a797-71257f91c75c")
		)
		(pin "2.2"
			(uuid "bab87b04-94ff-4ae8-8a4b-2f1ccd57f17a")
		)
		(pin "3.1"
			(uuid "3be683ed-cd2e-4809-a790-0fbd8ebd4396")
		)
		(pin "3.2"
			(uuid "31d2928d-4cc7-4cb0-8b08-140059b7af72")
		)
		(pin "4.1"
			(uuid "42d7533b-57ac-4e76-a838-9b3b55d640ae")
		)
		(pin "4.2"
			(uuid "428535ae-7835-4448-b160-aa59639d08f6")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM3")
					(unit 3)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 195.58 234.95 180)
		(unit 4)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058192296")
		(property "Reference" "RM3"
			(at 203.2 237.49 0)
			(effects
				(font
					(size 1.1938 1.1938)
				)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 180.34 237.49 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 194.31 232.41 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 194.31 232.41 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 195.58 234.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 195.58 234.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 195.58 234.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 195.58 234.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "58b7258f-e6c2-4080-b595-beb204cdc032")
		)
		(pin "1.2"
			(uuid "de708856-3967-41a2-b799-a552f851ee32")
		)
		(pin "2.1"
			(uuid "3b1dc347-ce51-4ae3-918c-dc1074c7d351")
		)
		(pin "2.2"
			(uuid "7522920b-4e77-42f8-8bc1-938b0f1e75c9")
		)
		(pin "3.1"
			(uuid "1968abd1-e872-4d6e-9c82-0468bbd10840")
		)
		(pin "3.2"
			(uuid "ffaefc72-88db-4487-91cf-c0ee26aa3164")
		)
		(pin "4.1"
			(uuid "149c80ad-9eda-4c09-9955-21dbf4b4a3d8")
		)
		(pin "4.2"
			(uuid "2ca2d91c-fb56-4462-9bc8-2df1d3190840")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM3")
					(unit 4)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 358.14 236.22 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058194e17")
		(property "Reference" "#PWR063"
			(at 358.14 240.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 358.521 231.8258 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 358.14 236.22 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 358.14 236.22 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 358.14 236.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "61444892-e20d-4514-ac3e-e87c8ea488dc")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR063")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 367.03 243.84 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058196627")
		(property "Reference" "R29"
			(at 360.934 242.824 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 375.666 242.824 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 367.03 245.618 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 367.03 243.84 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 367.03 243.84 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 367.03 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 367.03 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 367.03 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1c648964-acbb-4532-b304-86d5d0b88911")
		)
		(pin "2"
			(uuid "0d24bed5-480d-429b-9f4f-60dcd014ff90")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R29")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 384.81 256.54 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581b0269")
		(property "Reference" "R43"
			(at 384.81 256.54 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10R/R0603"
			(at 393.954 255.524 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 384.81 258.318 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 384.81 256.54 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 384.81 256.54 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 384.81 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 384.81 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 384.81 256.54 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "dca16fef-13b2-444c-b8ae-11e955e84864")
		)
		(pin "2"
			(uuid "a6a9a873-0369-405b-8e32-7c6e4ec44607")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R43")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 201.93 208.28 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581b5e6f")
		(property "Reference" "R38"
			(at 206.756 207.264 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 194.056 207.518 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 201.93 210.058 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 201.93 208.28 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 201.93 208.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 201.93 208.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 201.93 208.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 201.93 208.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0bad8270-6650-42f1-8fb3-065f3daaa187")
		)
		(pin "2"
			(uuid "83eefc07-7900-4efd-8885-42ede2782229")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R38")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 201.93 213.36 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581b5f19")
		(property "Reference" "R39"
			(at 206.756 212.598 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "12.1k/1%/R0603"
			(at 201.93 215.392 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 201.93 215.138 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 201.93 213.36 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 201.93 213.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 201.93 213.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 201.93 213.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 201.93 213.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "903983f4-5348-4236-935f-ff16de3be327")
		)
		(pin "2"
			(uuid "3424d509-1301-4e28-aa9b-81354ac4ba06")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R39")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 223.52 213.36 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581be755")
		(property "Reference" "#PWR041"
			(at 229.87 213.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 226.7712 213.233 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 223.52 213.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 223.52 213.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 213.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "aca074a1-289a-4408-9125-4321e27e718c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR041")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 195.58 210.82 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581bf7f5")
		(property "Reference" "C18"
			(at 191.008 209.804 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1nF/50V/5%/NPO(COG)/C0603"
			(at 206.502 210.058 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 195.58 210.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 195.58 210.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 195.58 210.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 195.58 210.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 195.58 210.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 195.58 210.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "17ce9c2a-37bd-4625-9b17-0bf3c212c43d")
		)
		(pin "2"
			(uuid "2fc592cf-47d5-4842-ba47-7277795d91ae")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C18")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 408.94 276.86 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581c1790")
		(property "Reference" "#PWR064"
			(at 408.94 283.21 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 410.972 280.416 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 408.94 276.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 408.94 276.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 408.94 276.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0b6b715f-12df-4288-94eb-a04916d7b63e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR064")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:L")
		(at 373.38 248.92 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581c8fde")
		(property "Reference" "L4"
			(at 367.284 247.904 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "FB0805/600R/2A"
			(at 383.794 248.158 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:L_0805_5MIL_DWS"
			(at 372.11 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 372.11 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 248.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 373.38 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 373.38 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 373.38 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c0305837-76c0-45e5-86bf-d31415d0c2ad")
		)
		(pin "2"
			(uuid "1b5fe566-43ec-4fa0-ae27-bcf184e2e4b8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "L4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 373.38 251.46 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581d0018")
		(property "Reference" "C10"
			(at 369.062 250.444 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "47uF/6.3V/20%/X5R/C0805"
			(at 386.08 250.444 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0805_5MIL_DWS"
			(at 373.38 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 373.38 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 251.46 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 373.38 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 373.38 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 373.38 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "883f27ef-94d6-46ae-be6f-93d312399e52")
		)
		(pin "2"
			(uuid "3060e8b3-8df8-4ad4-87d9-041f87cb9325")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C10")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RJLBC-060TC1_GND")
		(at 45.72 203.2 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581d1b06")
		(property "Reference" "LAN1"
			(at 36.195 184.15 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "RJLD-060TC1(LPJ4013EDNL)"
			(at 59.055 186.69 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:RJLBC-060TC1"
			(at 44.958 199.39 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 45.72 203.2 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 45.72 203.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 45.72 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 45.72 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 45.72 203.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a414c8ed-ecf5-44a9-affb-1772adbc6d30")
		)
		(pin "2"
			(uuid "80f7abb0-8fa7-4604-b313-dd07d304b900")
		)
		(pin "3"
			(uuid "530abb86-b556-4c79-802c-5aaa4778ef73")
		)
		(pin "6"
			(uuid "62eec412-576a-4c56-83df-67b3e1128125")
		)
		(pin "7"
			(uuid "f8a50cef-f0a6-4e9d-b66e-65eb85dc6aab")
		)
		(pin "8"
			(uuid "638dd0dc-74d5-4e25-aab5-7008fb43a09b")
		)
		(pin "AG1"
			(uuid "f7ce37d6-2f6a-4695-bb4f-e3b037443d40")
		)
		(pin "AY1"
			(uuid "fba4dd87-33d5-4e0f-87ea-58a59510b8ba")
		)
		(pin "GND1"
			(uuid "50407db8-20c3-4ec2-9c9f-a1eb8b9a1911")
		)
		(pin "GND2"
			(uuid "cc237342-0a54-49b0-b60e-660ef89cd7f9")
		)
		(pin "KG1"
			(uuid "022f89cb-754e-4061-8d4b-ebae813cfa37")
		)
		(pin "KY1"
			(uuid "a62e08d6-c2bd-4862-bb37-ef4c96e4c9d8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "LAN1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 104.14 149.86 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581d7f72")
		(property "Reference" "C13"
			(at 100.584 148.844 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 117.602 148.844 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 104.14 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 104.14 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 104.14 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 104.14 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 104.14 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 104.14 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5dfd48ac-dded-4a3c-9f5b-8bd2d0986b21")
		)
		(pin "2"
			(uuid "623e7412-393f-46d5-be8d-fd4beb3e1bb1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C13")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 365.76 251.46 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581d887c")
		(property "Reference" "#PWR065"
			(at 359.41 251.46 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 362.5088 251.587 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 365.76 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 365.76 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 365.76 251.46 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "703773d3-cc30-42d7-81a6-db9e8fe31930")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR065")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 43.18 231.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581db812")
		(property "Reference" "#PWR043"
			(at 43.18 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 43.18 234.696 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 43.18 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 43.18 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 43.18 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5956e8ce-38c4-43b7-b7e5-800fd93c2350")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR043")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 96.52 149.86 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581de9a6")
		(property "Reference" "#PWR044"
			(at 90.17 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 93.2688 149.987 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 96.52 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 96.52 149.86 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 96.52 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "93ae2166-91da-4cbb-b1d5-f49ea89a7e2b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR044")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 60.96 162.56 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e240d")
		(property "Reference" "C8"
			(at 62.23 167.386 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 58.166 177.546 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 60.96 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 60.96 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 60.96 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 60.96 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 60.96 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 60.96 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "63cdd9f6-6a1c-448e-b91d-562b516fe0dd")
		)
		(pin "2"
			(uuid "fd4604e2-a013-45e5-96f2-51a90814ac5a")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C8")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 66.04 162.56 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e24eb")
		(property "Reference" "C9"
			(at 64.77 160.274 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 68.58 177.546 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 66.04 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 66.04 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 66.04 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 66.04 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 66.04 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 66.04 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "bd31d735-e40e-4b8f-82eb-8dc308256be0")
		)
		(pin "2"
			(uuid "99209767-02b5-406f-9e9e-cdde68bbba06")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C9")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 60.96 177.8 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e5c3a")
		(property "Reference" "#PWR045"
			(at 60.96 184.15 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 61.087 182.1942 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 60.96 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 60.96 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 60.96 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "366e9040-4ee1-4baa-b9ca-33bfebf9d64f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR045")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 66.04 177.8 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e5ce8")
		(property "Reference" "#PWR046"
			(at 66.04 184.15 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 66.167 182.1942 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 66.04 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 66.04 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 66.04 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1be6903e-014c-47d8-bb8c-ad6ea3257bdb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR046")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:L")
		(at 73.66 154.94 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e7670")
		(property "Reference" "L3"
			(at 73.66 149.479 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "FB0805/600R/2A"
			(at 73.66 151.7904 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:L_0805_5MIL_DWS"
			(at 72.39 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 72.39 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 73.66 154.94 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 73.66 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 73.66 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 73.66 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c4392a85-ab1b-4edf-b6e3-14ba7192b7e5")
		)
		(pin "2"
			(uuid "4d29da24-a025-4a45-9e66-ac3fa18557c3")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "L3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 373.38 255.27 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e802f")
		(property "Reference" "RM1"
			(at 368.554 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 393.7 266.7 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 372.11 252.73 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 372.11 252.73 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 255.27 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 373.38 255.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 373.38 255.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 373.38 255.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "ac9d5368-0f8b-4f75-9101-de3dccfa8eab")
		)
		(pin "1.2"
			(uuid "f086684b-96bf-4d02-b283-c80183de0aba")
		)
		(pin "2.1"
			(uuid "186e8c58-c80f-470e-8ac6-b27f5cf56f2c")
		)
		(pin "2.2"
			(uuid "4ab0e332-c3b9-4380-813a-f684bdbb4111")
		)
		(pin "3.1"
			(uuid "87a5a795-f89a-4a92-ae24-9b2fe2dfef80")
		)
		(pin "3.2"
			(uuid "f1c6b60c-41ce-442f-950d-fe8a517ccebf")
		)
		(pin "4.1"
			(uuid "d3eeaa84-0081-4d54-9892-0582a2ef2888")
		)
		(pin "4.2"
			(uuid "e997609b-b5ea-4407-a7f3-6b567833e070")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 373.38 257.81 180)
		(unit 2)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e8768")
		(property "Reference" "RM1"
			(at 368.808 260.604 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 393.7 266.7 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 372.11 255.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 372.11 255.27 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 373.38 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 373.38 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 373.38 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "d3b85104-f9f3-4de6-b48a-64a6ab29ebd5")
		)
		(pin "1.2"
			(uuid "1ed5c125-e305-4dc1-b2e2-28dfd34426a3")
		)
		(pin "2.1"
			(uuid "25a6b18d-bbef-4d21-b1b0-35bafc5372ce")
		)
		(pin "2.2"
			(uuid "ef562d1a-ef3b-4f94-b581-fa74e819e6dc")
		)
		(pin "3.1"
			(uuid "5a8b5772-4d55-4865-a939-94cb534919de")
		)
		(pin "3.2"
			(uuid "b153c95a-6647-44fd-b59a-a691c0c23e19")
		)
		(pin "4.1"
			(uuid "729c9024-4c1e-43b3-95ff-f185dff75d3a")
		)
		(pin "4.2"
			(uuid "fc71c344-1513-44c3-9436-1318f0a3c7ba")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM1")
					(unit 2)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 373.38 237.49 180)
		(unit 3)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e88db")
		(property "Reference" "RM1"
			(at 368.808 240.284 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 392.43 238.76 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 372.11 234.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 372.11 234.95 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 373.38 237.49 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 373.38 237.49 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 373.38 237.49 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "4c912fb5-45d2-4e13-9658-2811dea7bf86")
		)
		(pin "1.2"
			(uuid "181b2e30-04b0-4570-9a5b-dc24c4a47047")
		)
		(pin "2.1"
			(uuid "ee60c8a3-4b04-4f47-9854-979d0825b18f")
		)
		(pin "2.2"
			(uuid "405251ba-21a3-45b6-bd35-894c3964797a")
		)
		(pin "3.1"
			(uuid "38ebce33-7484-451c-959c-bf2b1ee2adf5")
		)
		(pin "3.2"
			(uuid "a109c2d9-c68a-4a4f-bc8a-194a21449a91")
		)
		(pin "4.1"
			(uuid "053b4bdf-fce4-4160-88ed-8148cda93e80")
		)
		(pin "4.2"
			(uuid "09061db7-6399-4384-a7af-b965bc5165c1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM1")
					(unit 3)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RA1206_(4x0603)_4B8_Smashed")
		(at 373.38 260.35 180)
		(unit 4)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581e8a47")
		(property "Reference" "RM1"
			(at 368.808 263.144 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "RA1206_(4X0603)_4B8_2.2k"
			(at 393.7 266.7 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_MATRIX_4"
			(at 372.11 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 372.11 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 260.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 373.38 260.35 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 373.38 260.35 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 373.38 260.35 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1.1"
			(uuid "468d7b8f-98fb-4215-a2ec-20b007c2c2a9")
		)
		(pin "1.2"
			(uuid "480ea7bd-f06c-4a57-b9b0-6e2ee3fd1c98")
		)
		(pin "2.1"
			(uuid "23bc4e5d-4cd1-4e85-9a27-08765c70ff61")
		)
		(pin "2.2"
			(uuid "cdc6d21e-4df4-4941-b78f-d53d06d9059f")
		)
		(pin "3.1"
			(uuid "49f7da9a-56e7-43f6-a698-07434d40f6b9")
		)
		(pin "3.2"
			(uuid "d967dccf-257e-4298-a308-9a0d0ba5cce4")
		)
		(pin "4.1"
			(uuid "dbd0b562-63d5-48d0-a408-a514ee76c177")
		)
		(pin "4.2"
			(uuid "e6012a07-06b2-4e5b-88e0-bf7e846f8480")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "RM1")
					(unit 4)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 81.28 173.99 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000581ecf77")
		(property "Reference" "R25"
			(at 82.55 166.624 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "0R(board_mounted)"
			(at 79.248 164.592 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:0R_0603"
			(at 79.502 173.99 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 81.28 173.99 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 81.28 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 81.28 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 81.28 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 81.28 173.99 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a1313431-1c48-428d-a016-1b38ad0ed8ed")
		)
		(pin "2"
			(uuid "5888e0af-3e91-4d5f-86e3-c9757df0fd69")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R25")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 38.1 284.48 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058211fd0")
		(property "Reference" "#FLG066"
			(at 35.687 284.48 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 30.988 284.48 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" ""
			(at 38.1 284.48 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 38.1 284.48 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 38.1 284.48 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a8560910-e982-40f7-98ba-624a839fe88d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG066")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 38.1 289.56 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000582123ac")
		(property "Reference" "#FLG067"
			(at 35.687 289.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 31.242 289.56 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" ""
			(at 38.1 289.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 38.1 289.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 38.1 289.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e0bbab67-2e5c-45d9-beb1-ee0c7eea42e3")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG067")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 411.48 236.22 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058216434")
		(property "Reference" "#FLG068"
			(at 411.48 233.807 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 411.48 231.648 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" ""
			(at 411.48 236.22 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 411.48 236.22 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 411.48 236.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a40b88d5-6f48-41d8-a2be-bf313eb9a58d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG068")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:ESP-WROOM-32")
		(at 337.82 86.36 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005821f429")
		(property "Reference" "U3"
			(at 299.212 43.942 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "ESP-WROOM-32"
			(at 373.888 131.572 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Cases-FP:ESP-WROOM-32_MODULE"
			(at 314.96 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 314.96 81.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 337.82 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 337.82 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 337.82 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 337.82 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f4f50a1e-466d-46e4-8bd5-f355b209f334")
		)
		(pin "10"
			(uuid "fc199be7-5fa0-48d0-8350-83de54899603")
		)
		(pin "11"
			(uuid "769407a9-b834-4733-8447-d32015816177")
		)
		(pin "12"
			(uuid "ef8e8ec0-fa39-43d9-bfee-6a2fdc91a71b")
		)
		(pin "13"
			(uuid "16781684-80d1-44ad-aea8-89e33ede44d2")
		)
		(pin "14"
			(uuid "96b663f7-5223-48b3-8dd3-3d3a8190e356")
		)
		(pin "15"
			(uuid "09a783a4-7233-4df6-90e7-7b05792bfb18")
		)
		(pin "16"
			(uuid "21030755-4255-49f3-b1f5-ad9c8e6e8866")
		)
		(pin "17"
			(uuid "e9ce99d5-7c91-4c7c-bf47-dd187c99d68f")
		)
		(pin "18"
			(uuid "68ea64dd-8427-459f-b6d5-dd9fa42a99c1")
		)
		(pin "19"
			(uuid "e5e96983-f6a7-4414-b26e-71326611ffbb")
		)
		(pin "2"
			(uuid "cc55a81b-20f7-483b-b9c0-81522318ec82")
		)
		(pin "20"
			(uuid "773af9c9-acfa-46c2-a704-7610f8cb76fe")
		)
		(pin "21"
			(uuid "69efb112-85f4-42ea-93f3-31091e7e9b83")
		)
		(pin "22"
			(uuid "ab2d4164-5928-4bf6-a9cb-8384e24b49ca")
		)
		(pin "23"
			(uuid "c9b81069-56fd-4e69-bd1d-bc208c3ae8b1")
		)
		(pin "24"
			(uuid "057fe710-d20e-40dc-989d-912cf1bbcbdc")
		)
		(pin "25"
			(uuid "e05ecca6-9f0c-4762-8669-e0efb80742f4")
		)
		(pin "26"
			(uuid "ff10ef1c-3c7f-4275-9d0e-40c31cd3a0dc")
		)
		(pin "27"
			(uuid "c45a759b-bd46-4e51-b868-1b3541b1e496")
		)
		(pin "28"
			(uuid "ff7972e4-a705-403a-a331-24849213fd07")
		)
		(pin "29"
			(uuid "51fc4614-33d9-460e-8c69-a7e165750cc5")
		)
		(pin "3"
			(uuid "ea1bc4b3-be8a-43bd-afce-bf6111314850")
		)
		(pin "30"
			(uuid "175c56b4-5c74-4f07-a971-74cff683a8a0")
		)
		(pin "31"
			(uuid "195b7876-9e7b-4721-9c55-75cf4295e146")
		)
		(pin "32"
			(uuid "3c50c372-6ca0-4efc-a521-00c98e13868d")
		)
		(pin "33"
			(uuid "b795822b-84e3-4946-ac1d-bfcecbb788b7")
		)
		(pin "34"
			(uuid "ad2c6439-cb01-4583-9a47-6c28d30efd59")
		)
		(pin "35"
			(uuid "df06036a-1cb6-4f75-9078-9872523f4ce9")
		)
		(pin "36"
			(uuid "95478a25-9625-40c0-ae23-f3f46a7fe814")
		)
		(pin "37"
			(uuid "05f92f00-7acd-43c8-b177-cab24d074220")
		)
		(pin "38"
			(uuid "dd97b09f-1710-4607-855d-5dc17156796f")
		)
		(pin "39"
			(uuid "0c4b1e48-214e-4ce5-b8bb-7fd20efc22d8")
		)
		(pin "4"
			(uuid "37554fc5-eb01-4521-8e8e-693461244e48")
		)
		(pin "5"
			(uuid "26cdf270-c23c-4461-9fd3-d7a9502e3c0e")
		)
		(pin "6"
			(uuid "3528676a-1b0c-4084-b2b6-485a1a0ba529")
		)
		(pin "7"
			(uuid "a8bd9f5e-000f-4ab1-9404-9b17353eb2d0")
		)
		(pin "8"
			(uuid "8a5296df-a6ed-48a0-8383-a11ae0a2ae49")
		)
		(pin "9"
			(uuid "e30b9b9e-c9ae-4f93-a304-612883379036")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:L")
		(at 274.32 238.76 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005824a75d")
		(property "Reference" "L1"
			(at 276.3012 237.5916 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "FB0805/600R/2A"
			(at 276.3012 239.903 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:L_0805_5MIL_DWS"
			(at 274.32 237.49 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 274.32 237.49 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 274.32 238.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 274.32 238.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 274.32 238.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 274.32 238.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ea3411a9-58b1-4aac-a91d-ae42b88b8ace")
		)
		(pin "2"
			(uuid "8eef1cb5-1172-4967-a98b-f91bd67d5f0f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "L1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 287.02 251.46 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005824b8b4")
		(property "Reference" "C5"
			(at 282.956 250.444 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 300.482 250.444 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 287.02 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 287.02 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 287.02 251.46 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 287.02 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 287.02 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 287.02 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "10ef0349-0d03-438d-9085-ae7d677f4fd9")
		)
		(pin "2"
			(uuid "0a28f906-cbb4-4115-90fc-66f9628d913f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 525.78 83.82 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058251ee0")
		(property "Reference" "#PWR069"
			(at 532.13 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 529.0312 83.693 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 525.78 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 525.78 83.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 525.78 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1fbe4059-b7ab-4936-b9af-ac1c590ade10")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR069")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky_Small")
		(at 309.88 266.7 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005825d356")
		(property "Reference" "D5"
			(at 310.134 262.636 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1N5819S4(SOD-123)"
			(at 311.15 264.16 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOD-123_1C-2A_KA"
			(at 309.88 266.7 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 309.88 266.7 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 309.88 266.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 309.88 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 309.88 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 309.88 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "695981d4-327f-4e80-aeb7-0eade385aeaf")
		)
		(pin "2"
			(uuid "03d27040-190d-4965-b494-75a13c2e41a6")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 35.56 226.06 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058265411")
		(property "Reference" "C19"
			(at 36.576 225.298 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "1nF/2000V/10%/X7R/C1206"
			(at 32.766 234.442 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_1206_5MIL_DWS_ISO"
			(at 35.56 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 35.56 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 35.56 226.06 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 35.56 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 35.56 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 35.56 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c44a87a2-ffaf-4947-8ae8-f9577dcb73b9")
		)
		(pin "2"
			(uuid "a0351450-e21f-45c7-b7df-99b90836f971")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C19")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 335.28 257.81 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000582660ef")
		(property "Reference" "R23"
			(at 334.518 261.112 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "10k/R0603"
			(at 334.772 245.618 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 333.502 257.81 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 335.28 257.81 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 335.28 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 335.28 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 335.28 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 335.28 257.81 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f3bbb66a-eac5-4e44-bf2b-d06da129598c")
		)
		(pin "2"
			(uuid "01874465-821b-41df-92d8-964950e7d677")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R23")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 43.18 226.06 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058266265")
		(property "Reference" "C20"
			(at 42.418 225.298 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "NA(1nF/2000V/10%/X7R/C1206)"
			(at 45.974 235.966 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_1206_5MIL_DWS_ISO"
			(at 43.18 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 43.18 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 43.18 226.06 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 43.18 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 43.18 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 43.18 226.06 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a1efc393-aaed-42fa-a4ae-bf559c03150b")
		)
		(pin "2"
			(uuid "c0b1c324-fc90-468d-9880-c01d2858faa9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C20")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 35.56 231.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058270dd6")
		(property "Reference" "#PWR070"
			(at 35.56 237.49 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 35.56 234.696 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 35.56 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 35.56 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 35.56 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "51f3e006-f4b6-4108-9120-383c84aa87a8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR070")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BH40S")
		(at 518.16 68.58 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000582864f3")
		(property "Reference" "EXT1"
			(at 517.398 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA(HN2x20)"
			(at 517.144 94.234 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:HN2x20"
			(at 517.398 69.85 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 518.16 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 518.16 68.58 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 518.16 68.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 518.16 68.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 518.16 68.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "81e66338-365d-45a0-9cca-affec7a7e22b")
		)
		(pin "10"
			(uuid "552f7d9b-be6e-43e6-a40c-89ef9a1f21cd")
		)
		(pin "11"
			(uuid "26d10e1c-c8ca-481e-8698-1237e9f61ec6")
		)
		(pin "12"
			(uuid "214d0135-22c6-426e-97fc-b44287afe02a")
		)
		(pin "13"
			(uuid "eaccabf0-d9fa-463a-98f1-a3c42d1d5ee7")
		)
		(pin "14"
			(uuid "2ee92136-2cd7-42b3-b990-a74b7d100a43")
		)
		(pin "15"
			(uuid "3c83a6bb-76eb-44ac-b842-47b114f4e3da")
		)
		(pin "16"
			(uuid "49c33f11-9e49-4f18-aa18-43d4f9ea867e")
		)
		(pin "17"
			(uuid "ab08b938-412f-48c6-abeb-2e1ded9a5301")
		)
		(pin "18"
			(uuid "8819a75b-c76d-4a9b-8063-132a821f2870")
		)
		(pin "19"
			(uuid "a21b427e-1856-456d-a966-4bf5bc8e93ac")
		)
		(pin "2"
			(uuid "430a3d2d-8388-4172-bb4b-bb67b5961bbf")
		)
		(pin "20"
			(uuid "b41ccb3f-e212-4608-8ad2-0d9a32494ef4")
		)
		(pin "21"
			(uuid "20014b9d-7d32-4518-99c2-6a2ac6b6ec20")
		)
		(pin "22"
			(uuid "5d6bd2a6-00b5-4725-a24e-dc170c4b0e7b")
		)
		(pin "23"
			(uuid "6853429a-8a54-4f10-9fe0-c50290e2d4d7")
		)
		(pin "24"
			(uuid "74cd10f0-7c4a-495b-9db6-3fa0735bbe5a")
		)
		(pin "25"
			(uuid "2689380a-2cf7-4d52-877e-e18a78d18f63")
		)
		(pin "26"
			(uuid "da25fecf-1cee-4644-8614-ffa230dfce7d")
		)
		(pin "27"
			(uuid "38debd0d-4cdc-42ba-981e-3dcb4d735c07")
		)
		(pin "28"
			(uuid "9aef4e9f-358c-423d-9673-d6b234dbb841")
		)
		(pin "29"
			(uuid "b527e30b-502e-45ac-8e69-ec50d7e5deb2")
		)
		(pin "3"
			(uuid "f9c5af7a-d27c-4f9d-82aa-b909d53ec3f0")
		)
		(pin "30"
			(uuid "adf1d58f-5dbe-4fd5-8c7b-e9b7a5eff275")
		)
		(pin "31"
			(uuid "bc1db924-fb3b-4606-af7d-73c7e94d4146")
		)
		(pin "32"
			(uuid "4dcca97a-eb0c-4a45-bc52-160320545c5a")
		)
		(pin "33"
			(uuid "24abb524-f8ef-477b-8efd-d89eb2d116b8")
		)
		(pin "34"
			(uuid "f061b9cd-6d05-40f8-8d01-4785d94aee44")
		)
		(pin "35"
			(uuid "65911373-4f37-4681-b4cc-94fb2af0359e")
		)
		(pin "36"
			(uuid "0b822b67-07e2-424e-8eab-d805e14a9e59")
		)
		(pin "37"
			(uuid "9407f05e-c0d0-4681-9f83-74c9e9166a15")
		)
		(pin "38"
			(uuid "58270c48-8d69-423b-a94c-da7ae2ccb70b")
		)
		(pin "39"
			(uuid "c8d2c43c-881a-41c2-9ace-5206932b9f7f")
		)
		(pin "4"
			(uuid "510b053e-659a-44d9-a20d-cd25eebf2d7b")
		)
		(pin "40"
			(uuid "d2b9a83c-a520-4f28-85e7-fd1f1aff0147")
		)
		(pin "5"
			(uuid "3dbc3e56-f9fa-489f-9a1f-353b679951b0")
		)
		(pin "6"
			(uuid "4c6f3989-317f-4108-9e37-99e99a4a6dd3")
		)
		(pin "7"
			(uuid "1aaf1b06-1a5a-46a1-a0a5-fdcaf34c1b6d")
		)
		(pin "8"
			(uuid "61d434f0-2232-4558-aa07-ea84faddda0d")
		)
		(pin "9"
			(uuid "917e304c-4797-49e6-a42c-d2678a6a28d1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "EXT1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 275.59 68.58 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058292085")
		(property "Reference" "R24"
			(at 275.59 66.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 275.59 71.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 275.59 70.358 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 275.59 68.58 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 275.59 68.58 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 275.59 68.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 275.59 68.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 275.59 68.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1de92264-0809-4310-9c17-f709af0d18df")
		)
		(pin "2"
			(uuid "2ddfbd9d-abb6-4374-a349-84b731c47f2b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R24")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SJ")
		(at 182.88 223.52 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000582c1134")
		(property "Reference" "PHY_RST1"
			(at 180.9496 222.3516 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Value" "Opened"
			(at 180.9496 224.663 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" "OLIMEX_Jumpers-FP:SJ"
			(at 184.4548 223.3168 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 182.88 223.52 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 182.88 223.52 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 182.88 223.52 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 182.88 223.52 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 182.88 223.52 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "4abaf95d-ce01-4b12-89ae-b3a9713b2509")
		)
		(pin "2"
			(uuid "d56b16a3-cc14-497c-b2d6-0f6ba145cfa5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "PHY_RST1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 182.88 228.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000582c25d3")
		(property "Reference" "#PWR053"
			(at 182.88 234.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 182.88 232.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 182.88 228.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 182.88 228.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 182.88 228.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8836e2bf-0a88-46bb-9408-4cf47831f546")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR053")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 35.56 266.7 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000582c4f84")
		(property "Reference" "#PWR054"
			(at 35.56 273.05 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 35.56 270.51 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 35.56 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 35.56 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 35.56 266.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a3296e91-d091-47f5-a611-e8f7d7f9ecfd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR054")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 508 86.36 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005833727f")
		(property "Reference" "#PWR055"
			(at 501.65 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 504.7488 86.487 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 508 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 508 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 508 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5f0c55d5-2199-47ee-a17a-e75027a6512c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR055")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 525.78 86.36 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000583373ec")
		(property "Reference" "#PWR056"
			(at 532.13 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 529.0312 86.233 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify right)
			)
		)
		(property "Footprint" ""
			(at 525.78 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 525.78 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 525.78 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f3ff1430-b87c-4464-9ce1-69750dc2e4c9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR056")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 525.78 88.9 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005833fa8a")
		(property "Reference" "#PWR057"
			(at 521.97 88.9 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 529.0312 89.281 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 525.78 88.9 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 525.78 88.9 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 525.78 88.9 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7d7c882e-53cd-4da1-9352-e7623112f9fb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR057")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 508 88.9 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005833fcdd")
		(property "Reference" "#PWR058"
			(at 511.81 88.9 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 504.7488 88.519 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 508 88.9 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 508 88.9 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 508 88.9 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ab4a5e94-9853-4af5-be43-13d85366caad")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR058")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+5V")
		(at 508 91.44 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005834e135")
		(property "Reference" "#PWR059"
			(at 511.81 91.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 504.7488 91.059 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 508 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 508 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 508 91.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "33beae63-9962-4b18-853c-5b45467890b8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR059")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+5V")
		(at 525.78 91.44 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005834e388")
		(property "Reference" "#PWR060"
			(at 521.97 91.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 529.0312 91.821 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 525.78 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 525.78 91.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 525.78 91.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a585998a-a687-4cfd-bbd4-3447086bcc56")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR060")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:CH340T(SSOP20W)")
		(at 119.38 347.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d41048")
		(property "Reference" "U5"
			(at 119.38 331.47 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "CH340T(SSOP20W)"
			(at 119.38 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:SSOP-20W"
			(at 119.38 367.03 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 0 695.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 119.38 347.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "10"
			(uuid "95dd16ed-d45c-4a54-87f5-c07652eee523")
		)
		(pin "11"
			(uuid "1d5d1038-c6c7-4524-9607-2a8c759cd77c")
		)
		(pin "12"
			(uuid "3f89a87f-e513-4036-bf92-97a41b61f79d")
		)
		(pin "13"
			(uuid "9ea1aef1-7952-4452-b466-441187c2e2e6")
		)
		(pin "14"
			(uuid "81866cbe-65eb-4e98-91bd-d2fdb0b546d7")
		)
		(pin "15"
			(uuid "4da89fc8-6d82-4e45-bc6a-9ec5c62a2bce")
		)
		(pin "16"
			(uuid "c9641e20-d192-4ac7-aae1-15b2154be129")
		)
		(pin "17"
			(uuid "c3d7d532-4f64-40fe-9cb9-bae59bac068e")
		)
		(pin "19"
			(uuid "8634df1e-260f-449b-8c95-ed307dd3d742")
		)
		(pin "20"
			(uuid "79d5ab82-69af-449d-b0f9-8fbe7f0399ba")
		)
		(pin "3"
			(uuid "65506149-62a2-4425-a583-d8cf7aebe417")
		)
		(pin "4"
			(uuid "ace9891b-dfcf-45f9-9029-9d258590cafb")
		)
		(pin "5"
			(uuid "3634d92e-5c99-488f-8b47-34359064accf")
		)
		(pin "6"
			(uuid "0d509949-0730-4fac-b303-55c7e046834c")
		)
		(pin "7"
			(uuid "324bb70c-718d-4cd4-8a85-3335f680a0c5")
		)
		(pin "8"
			(uuid "10f5fac1-86e0-4275-9371-9018fdf8c618")
		)
		(pin "9"
			(uuid "99af2384-1ba0-46b6-985a-80a05239452f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_name "ESP32-EVB_Rev_K1:USB-MINI")
		(lib_id "ESP32-EVB_Rev_K1:USB-MINI")
		(at 30.48 350.52 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d440a7")
		(property "Reference" "USB-UART1"
			(at 40.64 332.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "MISB-SWMM-5B-LF(USB_MICRO)"
			(at 65.405 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:USB-MICRO_MISB-SWMM-5B_LF"
			(at 25.9588 353.2124 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 27.94 350.52 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 30.48 350.52 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "0"
			(uuid "b80bfb94-0410-4d68-bdc8-10dec7d30b26")
		)
		(pin "0"
			(uuid "986fbf04-756b-4117-8474-4a917627ecc7")
		)
		(pin "0"
			(uuid "5d370ff6-a9d0-4f25-9759-a8f689967bc9")
		)
		(pin "0"
			(uuid "e6dd0b59-e3c9-477f-9a5d-9eeb2eab3666")
		)
		(pin "1"
			(uuid "75080471-2788-4c58-a8ea-1242116a72a9")
		)
		(pin "2"
			(uuid "7140c129-89e2-4306-b94a-558f5b92c984")
		)
		(pin "3"
			(uuid "38df4c8c-0057-4049-8b7d-c5bf3ea3f5dd")
		)
		(pin "4"
			(uuid "6ff92ebc-9344-4b80-bda6-6deab2c6b6a9")
		)
		(pin "5"
			(uuid "e2e45dce-d2b4-4015-ae59-088bf31a1f07")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "USB-UART1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 561.34 251.46 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d45c48")
		(property "Reference" "#PWR071"
			(at 561.34 255.27 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 563.88 247.65 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 561.34 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 561.34 251.46 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 561.34 251.46 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c12f0017-2fc8-4192-93e0-71fd452ad893")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR071")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 537.21 259.08 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d45c51")
		(property "Reference" "R45"
			(at 542.544 258.064 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 528.955 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 537.21 260.858 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 537.21 259.08 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 537.21 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 537.21 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 537.21 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 537.21 259.08 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "9281c43b-adcc-4db6-94c1-499ebba31006")
		)
		(pin "2"
			(uuid "6b92eada-ceee-4d25-b7b9-5fd40847bdbd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R45")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 40.64 365.76 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d478c6")
		(property "Reference" "#PWR072"
			(at 40.64 372.11 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 40.64 369.57 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 40.64 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 40.64 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 40.64 365.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a3452783-d310-4128-b2b0-35ddfb1ccfda")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR072")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 86.36 335.28 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d54432")
		(property "Reference" "C23"
			(at 80.645 334.01 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 87.63 334.01 90)
			(effects
				(font
					(size 0.635 0.635)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 86.36 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 86.36 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 86.36 335.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 86.36 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 86.36 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 86.36 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "494d658a-5b96-4c48-bbba-4f8027a5009d")
		)
		(pin "2"
			(uuid "457b95ed-c268-4911-9d1c-f55c3075b04f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C23")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 81.28 342.9 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d54438")
		(property "Reference" "#PWR073"
			(at 74.93 342.9 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 76.8858 343.027 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 81.28 342.9 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 81.28 342.9 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 342.9 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "889dc073-4295-44bd-9f74-6b64604c2332")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR073")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 119.38 322.58 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d5af61")
		(property "Reference" "R35"
			(at 113.03 321.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 128.905 321.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 119.38 324.358 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 119.38 322.58 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 119.38 322.58 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 119.38 322.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 119.38 322.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 119.38 322.58 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1bb58b70-30cb-45a2-9f02-e7de1d7be0e7")
		)
		(pin "2"
			(uuid "2b06af0f-05f5-4f4e-b5c9-a5ec978bead0")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R35")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 119.38 327.66 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d5bb65")
		(property "Reference" "R40"
			(at 113.03 326.39 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 128.905 326.39 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 119.38 329.438 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 119.38 327.66 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 119.38 327.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 119.38 327.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 119.38 327.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 119.38 327.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6a0438af-b138-412c-aa66-089c7b9f6139")
		)
		(pin "2"
			(uuid "7fa29efa-4a60-406a-af53-43f8bd675b77")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R40")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 86.36 337.82 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d603a7")
		(property "Reference" "C24"
			(at 80.645 336.55 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 87.63 336.55 90)
			(effects
				(font
					(size 0.635 0.635)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 86.36 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 86.36 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 86.36 337.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 86.36 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 86.36 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 86.36 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6d8e6130-0f02-40e2-bf98-62a8bf81a3de")
		)
		(pin "2"
			(uuid "1e2bb264-c5fe-4f2b-9ffb-62e730773753")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C24")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 81.28 335.28 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d65d8c")
		(property "Reference" "#PWR074"
			(at 74.93 335.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 76.8858 335.407 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 81.28 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 81.28 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 335.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "705093e1-680b-4e3f-8f1b-832bcbf9ee10")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR074")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 81.28 337.82 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d6665c")
		(property "Reference" "#PWR075"
			(at 74.93 337.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 76.8858 337.947 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 81.28 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 81.28 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 337.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "88fef759-80c4-4eb5-9964-63de77843bf5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR075")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Q_NPN_BEC")
		(at 167.64 347.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d6b1bc")
		(property "Reference" "Q4"
			(at 172.4914 346.8116 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "BC817-40(SOT23)"
			(at 172.4914 349.123 0)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 172.72 345.44 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 167.64 347.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 167.64 347.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c4d087f8-6c17-4cef-ab1a-a68d469ec1d4")
		)
		(pin "2"
			(uuid "a5ec4c79-c21c-4bbf-915f-f12fdf703095")
		)
		(pin "3"
			(uuid "a3779a87-b37a-486b-b83f-007f10414454")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "Q4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Crystal")
		(at 99.06 358.14 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d6dbce")
		(property "Reference" "Q3"
			(at 101.1174 357.1748 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "Q12MHz/20pF/30ppm/2P/HC-49SM(SMD)"
			(at 76.2 363.22 90)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Crystal-FP:Q_49U3HMS"
			(at 99.06 358.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 99.06 358.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 99.06 358.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1816e828-c055-42a0-a326-d3b8bcf9b3d2")
		)
		(pin "2"
			(uuid "b1437097-8878-462d-851a-c9d5f41e0eaf")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "Q3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 156.21 347.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d713ec")
		(property "Reference" "R41"
			(at 156.21 345.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1k/R0603"
			(at 156.21 350.52 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 156.21 349.758 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 156.21 347.98 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 156.21 347.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 156.21 347.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 156.21 347.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 156.21 347.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "76b42ed3-bcc2-465c-aba9-058b181a6a4b")
		)
		(pin "2"
			(uuid "c054ab48-42a3-4b4b-95d7-2231a11ceac8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R41")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 81.28 355.6 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d7490c")
		(property "Reference" "C21"
			(at 75.565 354.33 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "27pF/50V/5%/C0G/C0603"
			(at 82.55 354.33 90)
			(effects
				(font
					(size 0.635 0.635)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 81.28 355.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 81.28 355.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 355.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 81.28 355.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 81.28 355.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 81.28 355.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ae5f8b83-4bb5-46da-87ab-b3a63ede2506")
		)
		(pin "2"
			(uuid "1f428523-cbee-49c8-bbb9-942359132e8c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C21")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Q_NPN_BEC")
		(at 167.64 365.76 0)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d74bc0")
		(property "Reference" "Q5"
			(at 172.4914 364.5916 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "BC817-40(SOT23)"
			(at 172.4914 366.903 0)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 172.72 368.3 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 167.64 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 167.64 365.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e9b053b0-f950-402d-ad74-39104d423c07")
		)
		(pin "2"
			(uuid "133c325b-d2e9-45fa-90ae-0f09fc219719")
		)
		(pin "3"
			(uuid "c88603fc-9a9a-471d-a0e5-5e0acf900296")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "Q5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 156.21 365.76 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d74bc9")
		(property "Reference" "R42"
			(at 156.21 363.22 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1k/R0603"
			(at 156.21 368.3 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 156.21 367.538 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 156.21 365.76 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 156.21 365.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 156.21 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 156.21 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 156.21 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "314361af-d82f-4443-b200-e4eeb79c5662")
		)
		(pin "2"
			(uuid "9cedb665-1d79-45ee-a9c3-2930195a4891")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R42")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 81.28 360.68 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d751c0")
		(property "Reference" "C22"
			(at 75.565 359.41 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "27pF/50V/5%/C0G/C0603"
			(at 82.55 359.41 90)
			(effects
				(font
					(size 0.635 0.635)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 81.28 360.68 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 81.28 360.68 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 360.68 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 81.28 360.68 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 81.28 360.68 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 81.28 360.68 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6f6c9a6c-ffbf-4cfe-843a-f11b435a2d10")
		)
		(pin "2"
			(uuid "d6d0dd82-d711-4c48-9b95-7570f740d000")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C22")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 73.66 365.76 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d76952")
		(property "Reference" "#PWR076"
			(at 73.66 372.11 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 73.66 369.57 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 73.66 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 73.66 365.76 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 73.66 365.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "2595d8de-339a-4a8a-81d2-493ea847eb61")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR076")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:RPM7236-H8")
		(at 513.08 198.12 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d99bb2")
		(property "Reference" "U7"
			(at 513.08 190.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "VS1838B"
			(at 513.08 205.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:RPM7236-H8"
			(at 513.08 196.85 0)
			(effects
				(font
					(size 2.9972 2.9972)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 513.08 196.85 0)
			(effects
				(font
					(size 2.9972 2.9972)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 513.08 198.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "0"
			(uuid "35084f6a-2f62-4718-b032-030da84cb98a")
		)
		(pin "1"
			(uuid "f493b4b1-e417-4323-b641-11025b73ca21")
		)
		(pin "2"
			(uuid "bb945b30-c82c-48ab-866b-7e18577ed791")
		)
		(pin "3"
			(uuid "700cad8c-50fe-4692-aa20-c04535243c26")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U7")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:P-MOS+DIOD")
		(at 58.42 43.18 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058d9f018")
		(property "Reference" "FET2"
			(at 48.26 40.64 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "WPM2015-3/TR"
			(at 43.18 43.18 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 55.0926 48.6664 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 58.42 43.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 58.42 43.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "488b90db-c198-4cf8-9521-182a7e0e4338")
		)
		(pin "2"
			(uuid "4c9765b8-f0e4-42cc-a749-1525af6f3224")
		)
		(pin "3"
			(uuid "5a4ca147-b809-4f17-a6cf-dd21d087cfc0")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "FET2")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 530.86 198.12 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058da0036")
		(property "Reference" "C27"
			(at 537.21 198.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 548.64 200.025 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 530.86 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 530.86 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 530.86 198.12 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 530.86 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 530.86 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 530.86 198.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3aa47267-8645-418a-856a-d26048c8f89f")
		)
		(pin "2"
			(uuid "eca1bf65-298d-445e-9dcf-1a5517cc3dd7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C27")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 530.86 205.74 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058da2b30")
		(property "Reference" "#PWR090"
			(at 530.86 212.09 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 530.86 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 530.86 205.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 530.86 205.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 530.86 205.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "203a4980-fdfe-4d6c-8613-43dd75b3c747")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR090")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky")
		(at 59.69 53.34 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058da405c")
		(property "Reference" "D6"
			(at 59.69 50.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1N5822/SS34/SMA"
			(at 59.69 55.88 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SMA-KA"
			(at 59.69 49.9872 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 59.69 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 59.69 53.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "98f70617-037a-43de-b01e-8f6b79597e4d")
		)
		(pin "2"
			(uuid "a68ebf36-834e-4a67-89dc-177087355500")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D6")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 530.86 187.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058da466e")
		(property "Reference" "#PWR091"
			(at 530.86 191.77 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 530.86 184.15 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 530.86 187.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 530.86 187.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 530.86 187.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "844671b8-9f13-4ae8-aec4-1b8ebd6d0349")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR091")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 400.05 40.64 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058dc0f9b")
		(property "Reference" "R54"
			(at 400.05 38.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA/R0603"
			(at 400.05 43.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 400.05 42.418 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 400.05 40.64 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 400.05 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 400.05 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 400.05 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 400.05 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f601d9b7-21cd-47f3-89bf-d22bd49dd48b")
		)
		(pin "2"
			(uuid "5049af42-66e7-44a3-beba-4375b2571d52")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R54")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 48.26 77.47 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058dc1a49")
		(property "Reference" "R30"
			(at 46.99 82.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "10k/R0603"
			(at 46.99 65.405 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 46.482 77.47 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 48.26 77.47 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 48.26 77.47 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 48.26 77.47 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 48.26 77.47 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 48.26 77.47 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8fe44dcb-77c8-4e62-91e3-2e5693de9fac")
		)
		(pin "2"
			(uuid "48ef115a-d0f3-41f2-bd11-6bcae034f395")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R30")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 408.94 40.64 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058dc2d7f")
		(property "Reference" "#PWR080"
			(at 405.13 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 412.115 40.64 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 408.94 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 408.94 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 408.94 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "2b11f4b1-68e1-4add-8da2-56885816e894")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR080")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 48.26 93.98 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058dc3098")
		(property "Reference" "#PWR079"
			(at 48.26 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 48.26 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 48.26 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 48.26 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 48.26 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "235f6bdb-df62-47ca-a2a2-957763a858c8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR079")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 511.81 160.02 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058df2d22")
		(property "Reference" "R55"
			(at 506.73 159.004 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1k/R0603"
			(at 520.065 158.75 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 511.81 161.798 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 511.81 160.02 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 511.81 160.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 511.81 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 511.81 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 511.81 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c62e91eb-35c0-4766-af46-d413d9cc674d")
		)
		(pin "2"
			(uuid "00816a80-b1c2-477d-a1c3-f8ae82c1858a")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R55")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 511.81 165.1 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058df2d2b")
		(property "Reference" "R56"
			(at 506.73 164.084 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 519.684 164.338 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 511.81 166.878 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 511.81 165.1 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 511.81 165.1 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 511.81 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 511.81 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 511.81 165.1 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1980033a-24f3-4e4f-a19c-1f73da8ea136")
		)
		(pin "2"
			(uuid "a28ece88-1fe1-4269-9dc2-962776689676")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R56")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:Q_NPN_BEC")
		(at 528.32 160.02 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058df2d34")
		(property "Reference" "Q7"
			(at 527.05 164.592 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "BC817-40(SOT23)"
			(at 533.4 170.18 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 533.4 157.48 0)
			(effects
				(font
					(size 0.7366 0.7366)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 528.32 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 528.32 160.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 528.32 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 528.32 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 528.32 160.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5d807156-5df1-47a8-8918-a164494eba55")
		)
		(pin "2"
			(uuid "7c269af9-245c-4310-beba-094c6d693c96")
		)
		(pin "3"
			(uuid "5b4a17aa-420d-4542-8d77-62937869e4c9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "Q7")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 530.86 170.18 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058df2d3a")
		(property "Reference" "#PWR092"
			(at 530.86 176.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 530.86 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 530.86 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 530.86 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 530.86 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "fbee3069-6a43-41ca-ba41-173069a84249")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR092")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 505.46 170.18 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058df2d40")
		(property "Reference" "#PWR093"
			(at 505.46 176.53 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 505.46 173.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 505.46 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 505.46 170.18 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 505.46 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "9d047b69-becf-4643-9eef-dfc561bff115")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR093")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 496.57 147.32 0)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058df2d61")
		(property "Reference" "R53"
			(at 495.046 145.288 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "6.8R/R1206"
			(at 491.236 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_1206_5MIL_DWS"
			(at 496.57 145.542 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 496.57 147.32 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 496.57 147.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 496.57 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 496.57 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 496.57 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "fc6e7565-d1b7-4d2a-a2b6-7b9bdc77c047")
		)
		(pin "2"
			(uuid "4bcffc28-e466-4ffc-bd1e-0501e210e1d5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R53")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:LED_AK")
		(at 513.08 147.32 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058e1520b")
		(property "Reference" "LED3"
			(at 513.08 144.78 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "LED/IR333-A/5mm"
			(at 515.62 149.86 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_LEDs-FP:LED-5mm-PTH-AK"
			(at 513.08 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 513.08 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 513.08 147.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3e5e24b6-2014-485c-8783-d17e89beb8a6")
		)
		(pin "2"
			(uuid "a86671a4-a185-4e0a-b726-cd77559f2333")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "LED3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 175.26 86.36 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058e5245c")
		(property "Reference" "C3"
			(at 174.244 84.582 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "NA(47uF/6.3V/20%/X5R/C0805)"
			(at 179.07 106.68 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0805_5MIL_DWS"
			(at 175.26 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 175.26 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 175.26 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 175.26 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 175.26 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 175.26 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "41452965-2945-44f8-b0fc-43c62b044e5e")
		)
		(pin "2"
			(uuid "cd9cd13d-f404-43b2-8607-43bfbb72a942")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 182.88 86.36 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058e558f6")
		(property "Reference" "C4"
			(at 181.864 84.582 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "47uF/6.3V/20%/X5R/C0805"
			(at 185.42 102.87 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0805_5MIL_DWS"
			(at 182.88 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 182.88 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 182.88 86.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 182.88 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 182.88 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 182.88 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "64498fca-eab6-4cb5-bf24-fcdb412ff797")
		)
		(pin "2"
			(uuid "8d8b97f6-4b45-43a6-bd6c-d3b5fc91d2c1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:CON3")
		(at 264.16 365.76 0)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3a9")
		(property "Reference" "CAN1"
			(at 262.89 360.045 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "TB3-3.5mm"
			(at 266.7 371.475 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Connectors-FP:TB3-3.5mm"
			(at 262.255 367.03 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 262.255 367.03 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 264.16 365.76 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c2402998-0fce-4b9d-94d4-cdde5139becc")
		)
		(pin "2"
			(uuid "3b6c98d0-6c66-44f3-a441-464ad7cace18")
		)
		(pin "3"
			(uuid "29d924ce-8591-4640-9d40-bb83b8a51a4a")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "CAN1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 287.02 367.03 90)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3b0")
		(property "Reference" "R47"
			(at 285.115 367.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "120R/R1206"
			(at 289.56 368.3 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_1206_5MIL_DWS"
			(at 287.02 365.252 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 287.02 367.03 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 287.02 367.03 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "fbc8e4cd-f8d0-44dc-aec7-748d62eabffc")
		)
		(pin "2"
			(uuid "7850003c-6a6d-4980-ae91-d8167a5b1625")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R47")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 274.32 381 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3b7")
		(property "Reference" "#PWR081"
			(at 274.32 387.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 274.32 384.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 274.32 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 274.32 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 274.32 381 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "cbbbe021-7345-4280-ab8c-b00e67bff13b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR081")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 353.06 373.38 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3c4")
		(property "Reference" "C26"
			(at 351.79 368.935 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "10uF/6.3V/20%/X5R/C0603"
			(at 355.6 357.505 90)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 352.0948 369.57 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 353.06 373.38 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 353.06 373.38 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c6f6c368-cbed-4811-bee5-75ffc09c1ac5")
		)
		(pin "2"
			(uuid "f9abbeba-bcd7-461b-a00b-37349a151a22")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C26")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 353.06 381 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3cb")
		(property "Reference" "#PWR082"
			(at 353.06 387.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 353.06 384.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 353.06 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 353.06 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 353.06 381 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "bb4ff774-a9a0-472a-8d28-64876eaea231")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR082")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SJ2W_Closed(1-2)")
		(at 322.58 332.74 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3d1")
		(property "Reference" "5.0V/3.3V1"
			(at 328.93 325.12 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
			)
		)
		(property "Value" "Closed(1-2)/Opened(2-3)"
			(at 336.55 327.66 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
			)
		)
		(property "Footprint" "OLIMEX_Jumpers-FP:SJ_2_SMALL_12_TIED"
			(at 318.77 331.978 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 322.58 332.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 322.58 332.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5bf58f70-427a-4533-85a0-7dff00825f51")
		)
		(pin "2"
			(uuid "77b1623f-9541-4e60-9ac6-802c95fa05a2")
		)
		(pin "3"
			(uuid "38bff4eb-76ce-4d78-bca5-fff121a5cb65")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "5.0V/3.3V1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 353.06 330.2 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3d8")
		(property "Reference" "#PWR083"
			(at 353.06 334.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 353.06 326.39 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 353.06 330.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 353.06 330.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 353.06 330.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8ee795ca-0355-4ffb-9596-d3ef73475454")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR083")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 279.4 330.2 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3de")
		(property "Reference" "#FLG084"
			(at 279.4 327.787 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 279.4 325.628 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 279.4 330.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 279.4 330.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 279.4 330.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "55b0ac8a-9b05-497c-935b-57864688b893")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG084")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+5V")
		(at 292.1 330.2 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead3ee")
		(property "Reference" "#PWR085"
			(at 292.1 334.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+5V"
			(at 292.1 326.644 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 292.1 330.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 292.1 330.2 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 292.1 330.2 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "9a86fc2f-7630-4d06-9f40-bdbed712f27c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR085")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 295.91 347.98 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead406")
		(property "Reference" "R49"
			(at 291.465 346.71 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "10k/R0603"
			(at 304.165 346.71 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 297.688 347.98 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 295.91 347.98 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 295.91 347.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6c220815-5034-4921-824a-4544959495ad")
		)
		(pin "2"
			(uuid "5341bcd6-fcf4-4f33-bb2b-c7525e24ac67")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R49")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SJ")
		(at 287.02 358.14 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead40d")
		(property "Reference" "CAN_T1"
			(at 285.115 360.68 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
			)
		)
		(property "Value" "Opened"
			(at 289.56 361.315 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
			)
		)
		(property "Footprint" "OLIMEX_Jumpers-FP:SJ"
			(at 285.4452 357.9368 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 287.02 358.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 287.02 358.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "32776a96-6a6f-4927-a870-1fc35e0e3dbe")
		)
		(pin "2"
			(uuid "c34212cf-7831-4ea1-b761-cbc40a9662de")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "CAN_T1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 287.02 347.98 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead432")
		(property "Reference" "#PWR086"
			(at 280.67 347.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 282.575 347.98 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 287.02 347.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 287.02 347.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 287.02 347.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "acbb5a15-54dd-417e-adb4-97e2896c695f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR086")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 295.91 345.44 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead439")
		(property "Reference" "R48"
			(at 291.465 344.17 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA/R0603"
			(at 304.165 344.17 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 297.688 345.44 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 295.91 345.44 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 295.91 345.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5c01a5a4-0a35-4d82-b82f-6c440c7d4437")
		)
		(pin "2"
			(uuid "a28fee85-ec2e-4db1-b2b1-1df42c5c59e7")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R48")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 345.44 373.38 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead450")
		(property "Reference" "C25"
			(at 344.17 368.935 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 347.98 358.14 90)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 344.4748 369.57 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 345.44 373.38 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 345.44 373.38 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6dabd123-6003-4ddb-a7a0-9c1c6517336e")
		)
		(pin "2"
			(uuid "02b555a6-94a8-4750-a0ae-070e82433451")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C25")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 345.44 381 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead457")
		(property "Reference" "#PWR087"
			(at 345.44 387.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 345.44 384.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 345.44 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 345.44 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 345.44 381 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a3d03c25-789f-4bd5-9f52-da440377b699")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR087")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 340.36 381 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ead462")
		(property "Reference" "#PWR088"
			(at 340.36 387.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 340.36 384.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 340.36 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 340.36 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 340.36 381 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b5c4b748-1863-47e9-ad2b-1ca070ba1fd1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR088")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 170.18 379.73 90)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058eb833e")
		(property "Reference" "R37"
			(at 172.72 379.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "220R/R0603"
			(at 167.64 379.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 170.18 377.952 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 170.18 379.73 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 170.18 379.73 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "302a9bd3-3559-4887-9660-54a75f4b1a57")
		)
		(pin "2"
			(uuid "084b60ca-9adc-4f10-94ad-2c85554ff20a")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R37")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BD5230G-TR(SSOP5_SOT-23-5)")
		(at 134.62 254 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058ef58a3")
		(property "Reference" "U8"
			(at 134.62 247.65 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "NA(NCP303LSN27T1G(SOT-23-5))"
			(at 134.62 260.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:SOT-23-5"
			(at 134.62 254 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 134.62 254 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 134.62 254 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 134.62 254 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 134.62 254 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 134.62 254 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "90e7bc27-414f-45bf-9234-a4fdf5ef8ba6")
		)
		(pin "2"
			(uuid "86ecfafd-dd64-49c3-b16b-e1f1538a3ce4")
		)
		(pin "3"
			(uuid "0473385a-1e29-4318-82d7-648e0e4ef26e")
		)
		(pin "5"
			(uuid "e4d96a1d-2a04-4c7d-93cb-a9ee6b41dc46")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U8")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 154.94 266.7 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058efa272")
		(property "Reference" "#PWR096"
			(at 154.94 273.05 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 154.94 270.51 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 154.94 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 154.94 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 154.94 266.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f095be7d-ea35-4d37-bf4d-4a7deaf3ef9c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR096")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 114.3 261.62 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058efb2ef")
		(property "Reference" "C28"
			(at 107.95 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "NA(470nF/16V/10%/X7R/C0603)"
			(at 87.63 264.16 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 114.3 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 114.3 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 114.3 261.62 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 114.3 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 114.3 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 114.3 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3271ded0-74c5-440b-83ea-963c86ccd605")
		)
		(pin "2"
			(uuid "e2cebb90-7ed9-410b-aace-8a75aafd35cd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C28")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 114.3 266.7 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058efb2f5")
		(property "Reference" "#PWR097"
			(at 114.3 273.05 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 114.3 270.51 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 114.3 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 114.3 266.7 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 114.3 266.7 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ce1b2934-77f7-429a-beca-bb87bd90ec0f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR097")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 417.83 259.08 0)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058f59dc8")
		(property "Reference" "R16"
			(at 422.275 257.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "220R/R0603"
			(at 417.83 262.89 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 416.052 259.08 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 417.83 259.08 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 417.83 259.08 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "72056b26-c12d-4a83-884c-b86becf47caf")
		)
		(pin "2"
			(uuid "1387d606-3b6f-49b8-ba00-d2207a262489")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R16")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 485.14 147.32 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058f77a4d")
		(property "Reference" "#PWR099"
			(at 488.95 147.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 481.33 147.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 485.14 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 485.14 147.32 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 485.14 147.32 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "eb7cff0e-e4a0-46a2-bb18-7a52b4575729")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR099")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BAT54C(SOT23-3)")
		(at 190.5 370.84 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058f77bd8")
		(property "Reference" "U9"
			(at 193.7512 372.1862 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "BAT54C(SOT23-3)"
			(at 194.31 369.57 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOT23-3"
			(at 190.5 370.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 190.5 370.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 190.5 370.84 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "aa07e6c5-2b79-4746-86ac-e357607d8f7e")
		)
		(pin "2"
			(uuid "5a02ba03-8232-4aa6-8eb1-4abace3e4e0e")
		)
		(pin "3"
			(uuid "d1b4bfa5-486b-4b1c-9588-0969afe999fa")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U9")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BAT54C(SOT23-3)")
		(at 190.5 391.16 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058f77f0c")
		(property "Reference" "U10"
			(at 193.7512 389.8138 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Value" "BAT54C(SOT23-3)"
			(at 193.7512 392.5062 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOT23-3"
			(at 190.5 391.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 190.5 391.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 190.5 391.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e7d96a23-8fed-4e75-8bf4-b96b8ba956f1")
		)
		(pin "2"
			(uuid "6b15e0e1-4ad9-44d1-a5cb-a03072049dfe")
		)
		(pin "3"
			(uuid "e38bc2e0-5be9-47d9-9c54-948b038ae40d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U10")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 201.93 378.46 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058f7b857")
		(property "Reference" "R44"
			(at 201.93 375.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA/R0603"
			(at 201.93 381 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 203.708 378.46 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 201.93 378.46 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 201.93 378.46 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "1e2ce05d-6f7e-47e5-88e5-12059ec3b5a3")
		)
		(pin "2"
			(uuid "9bc42493-17d3-4011-9da8-9b3cf03fa2eb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R44")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 154.94 243.84 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000058f8e01d")
		(property "Reference" "#FLG098"
			(at 154.94 241.427 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 154.94 238.1504 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 154.94 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 154.94 243.84 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 154.94 243.84 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "23669ee2-bf6a-40df-8624-fe3cf73ff24b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG098")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 537.21 264.16 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000059031de1")
		(property "Reference" "R46"
			(at 537.21 261.62 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA/R0603"
			(at 537.21 266.7 0)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 537.21 265.938 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 537.21 264.16 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 537.21 264.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 537.21 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 537.21 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 537.21 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "368a608b-2033-4c63-8aa4-e10c0b2f914e")
		)
		(pin "2"
			(uuid "57dbb58f-c246-4b09-bf19-1b6948867e2e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R46")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 500.38 205.74 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000592e8e03")
		(property "Reference" "#PWR0100"
			(at 500.38 212.09 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 500.38 209.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 500.38 205.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 500.38 205.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 500.38 205.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "200024af-4432-45ca-bc46-9d47afe040f9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0100")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 201.93 218.44 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005a132cc8")
		(property "Reference" "R57"
			(at 196.596 217.424 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA(1k/R0603)"
			(at 201.93 220.726 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 201.93 220.218 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 201.93 218.44 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 201.93 218.44 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 201.93 218.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 201.93 218.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 201.93 218.44 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e3018fc6-9d43-4645-82c9-b5ba5b55b292")
		)
		(pin "2"
			(uuid "1f5a55da-94ff-4aee-9200-98a7e5d94327")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R57")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:N-MOS+DIOD")
		(at 43.18 170.18 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b1ecec5")
		(property "Reference" "FET4"
			(at 43.18 164.465 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "BSS138"
			(at 43.18 176.53 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 44.45 170.18 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 44.45 170.18 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 43.18 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "4a567c3d-e32e-4a94-a8ea-aa37b745ef55")
		)
		(pin "2"
			(uuid "b01b89f9-6526-4a43-ad0e-3e2dbc2eda65")
		)
		(pin "3"
			(uuid "3f30a11c-7feb-4245-9bf7-9a2ccca3ba86")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "FET4")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:P-MOS+DIOD")
		(at 43.18 152.4 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b1fb79c")
		(property "Reference" "FET3"
			(at 43.18 143.51 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "WPM2015-3/TR"
			(at 43.18 146.05 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Transistors-FP:SOT23"
			(at 37.6936 155.7274 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(justify left)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 43.18 152.4 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 43.18 152.4 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "061a2db6-4e03-42d2-a662-5539fa29a437")
		)
		(pin "2"
			(uuid "40efbef7-a72e-4532-8ccc-54e836b24f69")
		)
		(pin "3"
			(uuid "8514b6f2-3986-4f95-ae7d-c39358e2709b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "FET3")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 325.12 375.92 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b27c8d3")
		(property "Reference" "#PWR0101"
			(at 321.31 375.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 328.295 375.92 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 325.12 375.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 325.12 375.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 325.12 375.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "133e3c7b-4e2c-4b29-af2d-24bd9d0962b9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0101")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:L")
		(at 43.18 142.24 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b5138d3")
		(property "Reference" "L5"
			(at 43.18 136.779 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA(FB0805/600R/2A)"
			(at 43.18 139.0904 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:L_0805_5MIL_DWS"
			(at 41.91 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 41.91 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 43.18 142.24 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 43.18 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 43.18 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 43.18 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "5fdcdf85-bf8d-41e5-bafc-ccd1b07e36e5")
		)
		(pin "2"
			(uuid "d1e00dec-d61c-4f88-b82f-56f7a77e6326")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "L5")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3VLAN")
		(at 60.96 137.16 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b6a13a3")
		(property "Reference" "#PWR0102"
			(at 60.96 140.97 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3VLAN"
			(at 61.341 132.7658 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 60.96 137.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 60.96 137.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 60.96 137.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "81dd88e8-b784-4921-9b19-ea8bf7ddd3e6")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0102")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 25.4 137.16 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b72a157")
		(property "Reference" "#PWR0103"
			(at 25.4 140.97 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 25.781 132.7658 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 25.4 137.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 25.4 137.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 25.4 137.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "be28f907-0c36-4305-acec-d5f8c652d03a")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0103")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:MCP2562-E_SN(SOIC-8_150mil)")
		(at 322.58 350.52 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b95f8a9")
		(property "Reference" "U6"
			(at 322.58 344.17 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "SIT1050T(SOIC-8_150mil)"
			(at 322.58 359.41 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:SOIC-8_150mil"
			(at 322.58 350.52 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "http://hades.mech.northwestern.edu/images/5/5e/MCP2562.pdf"
			(at 322.58 350.52 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 322.58 350.52 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Note" "PTB"
			(at 322.58 350.52 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "fba0fe60-c501-4e9b-92e9-73421cfa8d3f")
		)
		(pin "2"
			(uuid "fd61ff62-7817-436e-ac4b-3d25e0a9041d")
		)
		(pin "3"
			(uuid "6c44504f-1815-4307-9403-f68457f6a4c4")
		)
		(pin "4"
			(uuid "ab0373f6-7c26-4c4d-9e32-16735b1d72ac")
		)
		(pin "5"
			(uuid "5e79817b-f581-415e-a99e-05a4314101f9")
		)
		(pin "6"
			(uuid "3d275341-f63b-4c37-8f2b-3adf132be793")
		)
		(pin "7"
			(uuid "b3b97e7a-4a49-48c5-997c-7db8e007b9d9")
		)
		(pin "8"
			(uuid "4407e4a6-7f72-44f5-9c16-68b093b16261")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U6")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 25.4 154.94 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005b9cc7ee")
		(property "Reference" "C29"
			(at 24.384 154.178 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "22uF/6.3V/20%/X5R/C0603"
			(at 27.686 162.306 90)
			(effects
				(font
					(size 0.7874 0.7874)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 25.4 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 25.4 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 25.4 154.94 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 25.4 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 25.4 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 25.4 154.94 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7fac7084-6187-4149-a89c-d505912fba3a")
		)
		(pin "2"
			(uuid "48c95193-1fda-45de-80a3-3187fd66a3f8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C29")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 31.75 167.64 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005ba562b8")
		(property "Reference" "R50"
			(at 33.02 165.735 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "1k/R0603"
			(at 36.83 170.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 31.75 165.862 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 31.75 167.64 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 31.75 167.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 31.75 167.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 31.75 167.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 31.75 167.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "26542a85-ad23-4343-be9f-d1acd76cd3be")
		)
		(pin "2"
			(uuid "f253ad0a-96c5-4c76-9039-b8767772562e")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R50")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 25.4 177.8 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bbec002")
		(property "Reference" "#PWR0104"
			(at 25.4 184.15 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 25.527 182.1942 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 25.4 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 25.4 177.8 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 25.4 177.8 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "76fc83c5-7049-4242-92be-834c0dfc931c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0104")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 33.02 156.21 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bcfd0eb")
		(property "Reference" "R51"
			(at 31.115 154.94 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "10k/R0603"
			(at 35.56 151.13 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 31.242 156.21 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 33.02 156.21 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 33.02 156.21 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 33.02 156.21 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 33.02 156.21 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 33.02 156.21 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "22e50020-cc0b-42ff-bc94-cfd92b298c4f")
		)
		(pin "2"
			(uuid "85d66b04-239b-4e28-8c0f-bf4772a609f8")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R51")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BL4054B-42TPRN(SOT23-5)")
		(at 124.46 78.74 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bfe170b")
		(property "Reference" "U?"
			(at 124.46 71.12 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "BL4054B-42TPRN(SOT23-5)"
			(at 124.46 86.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:SOT-23-5"
			(at 124.46 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "https://datasheet.lcsc.com/szlcsc/BL4054B-42TPRN_C83783.pdf"
			(at 124.46 78.74 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 124.46 78.74 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7aa819d3-91e7-4310-8279-3f88f5af9432")
		)
		(pin "2"
			(uuid "0789ec37-4306-428f-abbf-80ba3e2899af")
		)
		(pin "3"
			(uuid "1102154e-1378-4289-8936-643f7b3edb6e")
		)
		(pin "4"
			(uuid "79f920f8-ba25-41c2-a046-2dcb0f764dfb")
		)
		(pin "5"
			(uuid "c1f1ee59-6f69-483a-b8c0-17cd56c7f136")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 101.6 93.98 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bfe171d")
		(property "Reference" "#PWR?"
			(at 101.6 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 101.6 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 101.6 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 101.6 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 101.6 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "26fee90d-d7f3-4689-be96-449b58448833")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0110")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 140.97 83.82 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bfe1742")
		(property "Reference" "R?"
			(at 135.89 82.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "2k/1%/R0603"
			(at 151.13 82.55 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 142.748 83.82 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 140.97 83.82 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 140.97 83.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "c7651eb2-28c0-45e4-ba2e-9ca39b25ac35")
		)
		(pin "2"
			(uuid "87f9fc8d-018d-4ae6-9e31-e016cacfa724")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R8")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 152.4 93.98 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bfe1749")
		(property "Reference" "#PWR?"
			(at 152.4 100.33 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 152.4 97.79 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 152.4 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 152.4 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 152.4 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "2068775e-abaa-44d9-8230-b0448381b3c5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0111")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:LED")
		(at 121.92 66.04 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bfe1753")
		(property "Reference" "CHARGE?"
			(at 121.92 62.865 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "LED/Yellow/0603"
			(at 121.92 68.58 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Footprint" "OLIMEX_LEDs-FP:LED_0603_KA"
			(at 121.92 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 121.92 66.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 121.92 66.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e740e1dc-48b2-472e-9d54-98928c52717a")
		)
		(pin "2"
			(uuid "eec19105-18c0-4f08-96c5-3765525bf767")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "CHARGE1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 135.89 66.04 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005bfe1759")
		(property "Reference" "R?"
			(at 135.89 63.5 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "2.2k/R0603"
			(at 135.89 68.58 0)
			(effects
				(font
					(size 1.016 1.016)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 137.668 66.04 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 135.89 66.04 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 135.89 66.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "ee235b94-9734-40f0-8edf-7639f9691ea0")
		)
		(pin "2"
			(uuid "4ade40b9-a972-4c79-ae63-5bd47100272f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R7")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3VLAN")
		(at 223.52 162.56 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005c38ef0a")
		(property "Reference" "#PWR0105"
			(at 219.71 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3VLAN"
			(at 226.695 162.56 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 223.52 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 223.52 162.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 162.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3079f98e-ee4f-4f1c-81ae-7b15cdb3a11d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0105")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3VLAN")
		(at 223.52 193.04 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005c41de61")
		(property "Reference" "#PWR0106"
			(at 219.71 193.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3VLAN"
			(at 226.695 193.04 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 223.52 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 223.52 193.04 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 193.04 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a7f5988b-487e-4cff-aeca-413b5c5f40b5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0106")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3VLAN")
		(at 223.52 200.66 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005cd80164")
		(property "Reference" "#PWR0107"
			(at 219.71 200.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3VLAN"
			(at 226.695 200.66 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 223.52 200.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 223.52 200.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 200.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b946b293-bdfa-4c41-bec1-41ef6d3d9f96")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0107")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3VLAN")
		(at 223.52 208.28 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005ce0d85b")
		(property "Reference" "#PWR0108"
			(at 219.71 208.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3VLAN"
			(at 226.695 208.28 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 223.52 208.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 223.52 208.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 208.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0e94c9ce-a206-4d71-87e6-475f14748f7c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0108")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 71.12 327.66 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005ce36750")
		(property "Reference" "#FLG0102"
			(at 71.12 325.247 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 71.12 321.9704 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 71.12 327.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 71.12 327.66 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 71.12 327.66 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "91f24483-bdc6-4132-a308-070600ef52bb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG0102")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3VLAN")
		(at 185.42 248.92 90)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005ce9dc99")
		(property "Reference" "#PWR0109"
			(at 189.23 248.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3VLAN"
			(at 182.245 248.92 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Footprint" ""
			(at 185.42 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 185.42 248.92 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 185.42 248.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "8a0c9154-37d7-499f-ba3a-40d248a2077f")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0109")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 81.28 142.24 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005cfc1632")
		(property "Reference" "#FLG0101"
			(at 81.28 139.827 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 81.28 136.5504 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 81.28 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 81.28 142.24 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 81.28 142.24 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "73f44d3b-2f83-4745-8df3-6ce578887bda")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG0101")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky_Small")
		(at 152.4 337.82 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d0fbe95")
		(property "Reference" "D8"
			(at 148.59 339.09 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1N5819S4(SOD-123)"
			(at 161.29 339.09 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOD-123_1C-2A_KA"
			(at 152.4 337.82 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 152.4 337.82 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 152.4 337.82 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 152.4 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 152.4 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 152.4 337.82 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "698f649c-2117-493c-8a06-4ae07730613e")
		)
		(pin "2"
			(uuid "92ad857b-d52e-4fde-b5a2-3ea66990be46")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D8")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky_Small")
		(at 152.4 335.28 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d0fde8a")
		(property "Reference" "D7"
			(at 148.59 334.01 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1N5819S4(SOD-123)"
			(at 161.29 334.01 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOD-123_1C-2A_KA"
			(at 152.4 335.28 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 152.4 335.28 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 152.4 335.28 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 152.4 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 152.4 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 152.4 335.28 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f5f27d44-c4e3-4f3b-9223-13546f38f296")
		)
		(pin "2"
			(uuid "356480cc-8b16-4dde-892a-acbdcb1ac0a5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D7")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 101.6 340.36 90)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d449ad1")
		(property "Reference" "#FLG0103"
			(at 99.187 340.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 92.71 340.36 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 101.6 340.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 101.6 340.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 101.6 340.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e7406a10-b675-4951-ba75-21ea0bb15ffd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG0103")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 200.66 40.64 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d5dd3eb")
		(property "Reference" "R9"
			(at 198.12 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "470k/R0603"
			(at 204.47 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 198.882 40.64 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 200.66 40.64 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 200.66 40.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 200.66 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 200.66 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 200.66 40.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7bef6e04-d229-4514-8eb2-1f7c75aa101a")
		)
		(pin "2"
			(uuid "457d1d9c-6498-4232-a35b-f72c656aa84b")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R9")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 200.66 53.34 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d5ddef8")
		(property "Reference" "R10"
			(at 198.12 53.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "470k/R0603"
			(at 204.47 54.61 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 198.882 53.34 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 200.66 53.34 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 200.66 53.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 200.66 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 200.66 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 200.66 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "692a1569-aacb-4861-94d4-106d9f082cf7")
		)
		(pin "2"
			(uuid "09009a9c-7758-4be7-8e40-01a2ec90806c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R10")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:SJ2W_Closed(1-2)")
		(at 223.52 33.02 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d5de486")
		(property "Reference" "BAT/BUT1"
			(at 218.44 40.64 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left bottom)
			)
		)
		(property "Value" "Opened(2-3)/Soldered(1-2)"
			(at 214.63 36.83 90)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left bottom)
			)
		)
		(property "Footprint" "OLIMEX_Jumpers-FP:SJ_2_SMALL"
			(at 227.33 33.782 0)
			(effects
				(font
					(size 0.508 0.508)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 223.52 33.02 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 223.52 33.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "379cfede-7728-4b51-bfb2-c11c161f68c5")
		)
		(pin "2"
			(uuid "d576fb25-97dc-4c1c-abe0-a4ef1c3cc991")
		)
		(pin "3"
			(uuid "3cfc21df-943c-4650-a42d-6ea07cbe5926")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "BAT/BUT1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 213.36 53.34 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005d5e2804")
		(property "Reference" "C30"
			(at 209.55 54.61 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "100nF/50V/20%/Y5V/C0603"
			(at 217.17 63.5 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 213.36 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 213.36 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 213.36 53.34 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 213.36 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 213.36 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 213.36 53.34 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "9c1a00bc-15fd-4a52-b258-b329cb393f9c")
		)
		(pin "2"
			(uuid "0005e6fa-17ee-4d90-906a-c124b608b9da")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C30")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 213.36 60.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005e33f1eb")
		(property "Reference" "#PWR0112"
			(at 213.36 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 213.36 64.516 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 213.36 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 213.36 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 213.36 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "217c6668-2f91-4fff-a1d7-9d9fa31cb063")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0112")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 200.66 60.96 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005e6b26d0")
		(property "Reference" "#PWR0113"
			(at 200.66 67.31 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 200.66 64.516 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 200.66 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 200.66 60.96 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 200.66 60.96 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "57216705-8028-4578-ae51-ba3f01b81c03")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0113")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 284.48 93.98 180)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005e7a796c")
		(property "Reference" "C31"
			(at 283.21 88.9 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "1uF/10V/10%/X5R/C0603"
			(at 285.75 71.755 90)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 283.5148 90.17 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 284.48 93.98 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 284.48 93.98 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "72383113-73f6-4aa0-8bd1-6cfc999d1bb8")
		)
		(pin "2"
			(uuid "ffd94f7d-af16-4663-8c67-b1f0e242d8f4")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C31")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 284.48 101.6 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00005e7a7976")
		(property "Reference" "#PWR02"
			(at 284.48 107.95 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 284.48 105.41 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 284.48 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 284.48 101.6 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 284.48 101.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "0e549d54-a6dc-4d66-a1a0-e84ee3e525f1")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR02")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:ESDS314DBVR(SOT-23-5)")
		(at 114.3 231.14 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000061dc430f")
		(property "Reference" "TVS1"
			(at 114.3 219.329 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "ESDS314DBVR(SOT-23-5)"
			(at 114.3 221.6404 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOT-23-5"
			(at 114.3 221.4626 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" "https://www.ti.com/lit/gpn/esds314"
			(at 114.3 221.4626 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 114.3 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "d09e9b67-f5c9-4fa1-a036-707649f12af7")
		)
		(pin "1"
			(uuid "2458ecdd-1698-41ac-9153-b9f65ed5bb3f")
		)
		(pin "2"
			(uuid "fb4ea5e4-511a-4eae-bb3e-735b762c4f2a")
		)
		(pin "3"
			(uuid "a3140815-7ff6-459a-b746-7988a3d2cb08")
		)
		(pin "4"
			(uuid "ce381949-f2d3-4bf6-8a9d-19938e79e829")
		)
		(pin "5"
			(uuid "c95c2304-396f-4b8c-ab35-e125e5722af5")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "TVS1")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 308.61 375.92 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000061e14deb")
		(property "Reference" "R12"
			(at 304.165 374.65 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "NA/R0603"
			(at 316.865 374.65 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 310.388 375.92 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 308.61 375.92 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 308.61 375.92 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "b90a62e3-3fbc-47cc-bf3f-6914670d25c9")
		)
		(pin "2"
			(uuid "c09daaf8-90f2-4d87-8d3a-ec75c77935b4")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R12")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:VDA2710NTA(SOT-23)")
		(at 185.42 287.02 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000061f3d753")
		(property "Reference" "U11"
			(at 185.42 280.035 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "HX7027(SOT-23)"
			(at 185.42 293.37 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_IC-FP:SOT-23"
			(at 182.88 297.18 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 182.88 289.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 185.42 287.02 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "e99bdb87-5bb3-4ebc-b3c2-33b183ec8da7")
		)
		(pin "2"
			(uuid "3c522df6-0048-4b5e-baf2-4da88b028d9e")
		)
		(pin "3"
			(uuid "d44a55e4-14f7-4960-ba07-ac3d2b2c53c2")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "U11")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 364.49 355.6 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000061f68edf")
		(property "Reference" "R13"
			(at 364.49 353.06 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "330R/R0603"
			(at 364.49 358.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 366.268 355.6 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 364.49 355.6 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 364.49 355.6 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "bb3677af-0f8c-42a0-bddb-53b34486a9da")
		)
		(pin "2"
			(uuid "5ce94404-f0ea-4acb-aae2-ee4955ff0dfd")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R13")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 373.38 372.11 90)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000062097524")
		(property "Reference" "R15"
			(at 376.555 370.84 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "680R/R0603"
			(at 381 373.38 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 373.38 370.332 90)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 373.38 372.11 0)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 373.38 372.11 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3d478fa1-62e2-4313-b6b7-9311d025d945")
		)
		(pin "2"
			(uuid "ae2ec405-49f5-48e7-9787-0497a91aba8c")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R15")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 210.82 275.59 270)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00006211230a")
		(property "Reference" "R52"
			(at 214.63 274.32 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "100k/R0603"
			(at 217.17 276.86 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0603_5MIL_DWS"
			(at 209.042 275.59 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 210.82 275.59 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 210.82 275.59 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 210.82 275.59 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 210.82 275.59 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 210.82 275.59 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "033b3c23-4a5f-4286-9c66-b7bf01eeeee9")
		)
		(pin "2"
			(uuid "4c972585-0a7c-4583-bf91-09f3543c0b17")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R52")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 101.6 231.14 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00006219442c")
		(property "Reference" "#PWR015"
			(at 95.25 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 97.79 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 101.6 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 101.6 231.14 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 101.6 231.14 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "6c360665-e4a1-401e-b586-e99fa5dac684")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR015")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 373.38 381 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000621c2de6")
		(property "Reference" "#PWR04"
			(at 373.38 387.35 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 373.38 384.81 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 373.38 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 373.38 381 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 373.38 381 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "a9ebdb20-9ecc-4a59-a491-d85f3bb13c11")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR04")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 210.82 294.64 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00006225017c")
		(property "Reference" "#PWR0114"
			(at 210.82 300.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 210.82 298.45 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 210.82 294.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 210.82 294.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 210.82 294.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "952297a6-73e0-4a7b-923c-b4b639c95477")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0114")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:GND")
		(at 203.2 294.64 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00006225165a")
		(property "Reference" "#PWR0115"
			(at 203.2 300.99 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "GND"
			(at 203.2 298.45 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 203.2 294.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 203.2 294.64 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 203.2 294.64 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "be18dffd-388e-4f15-b92e-aa55217beeb4")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0115")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:BAT54A(SOT23-3)")
		(at 203.2 264.16 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-000062255547")
		(property "Reference" "D10"
			(at 203.2 256.8702 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Value" "BAT54A(SOT23-3)"
			(at 203.2 259.5626 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOT23-3"
			(at 203.2 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 203.2 264.16 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Description" ""
			(at 203.2 264.16 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "f1c0fcd0-5c05-419f-815f-c5a2846fd5de")
		)
		(pin "2"
			(uuid "5e4f5ccd-dacd-404e-85ee-50caa6cb28eb")
		)
		(pin "3"
			(uuid "9f297cfe-556b-43e0-ae6d-3fb23dd37eae")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D10")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:+3.3V")
		(at 190.5 261.62 0)
		(mirror y)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-00006239b1be")
		(property "Reference" "#PWR0116"
			(at 190.5 265.43 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "+3.3V"
			(at 190.119 257.2258 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 190.5 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 190.5 261.62 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 190.5 261.62 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "677eeb93-44f6-4a8e-aba3-6b4b746b12b6")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#PWR0116")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:PWR_FLAG")
		(at 304.8 368.3 270)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000623aac3a")
		(property "Reference" "#FLG0104"
			(at 307.213 368.3 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Value" "PWR_FLAG"
			(at 313.69 368.3 90)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Footprint" ""
			(at 304.8 368.3 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Datasheet" ""
			(at 304.8 368.3 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 304.8 368.3 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "17c07c61-dee5-47f1-9f14-5d238f47a19d")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "#FLG0104")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:D_Schottky_Small")
		(at 180.34 340.36 0)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000627a196e")
		(property "Reference" "D9"
			(at 176.53 339.09 0)
			(effects
				(font
					(size 1.27 1.27)
				)
			)
		)
		(property "Value" "1N5819S4(SOD-123)"
			(at 189.23 339.09 0)
			(effects
				(font
					(size 0.7874 0.7874)
				)
			)
		)
		(property "Footprint" "OLIMEX_Diodes-FP:SOD-123_1C-2A_KA"
			(at 180.34 340.36 90)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 180.34 340.36 90)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 180.34 340.36 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 180.34 340.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 180.34 340.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 180.34 340.36 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "3256ecb3-ad41-45f9-837d-443a5af9c78a")
		)
		(pin "2"
			(uuid "555e17fd-2e80-470a-b7ce-a431631b91c9")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "D9")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:C")
		(at 210.82 289.56 0)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000628b4292")
		(property "Reference" "C32"
			(at 213.36 288.29 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "1uF/10V/10%/X5R/C0603"
			(at 212.09 292.1 0)
			(effects
				(font
					(size 1.016 1.016)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:C_0603_5MIL_DWS"
			(at 211.7852 285.75 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 210.82 289.56 0)
			(effects
				(font
					(size 1.524 1.524)
				)
			)
		)
		(property "Description" ""
			(at 210.82 289.56 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "61dd2d9b-e507-4799-b681-878965be8a5e")
		)
		(pin "2"
			(uuid "0f21b09e-366c-4133-aa55-40cb00ceb408")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "C32")
					(unit 1)
				)
			)
		)
	)
	(symbol
		(lib_id "ESP32-EVB_Rev_K1:R")
		(at 203.2 275.59 90)
		(mirror x)
		(unit 1)
		(exclude_from_sim no)
		(in_bom yes)
		(on_board yes)
		(dnp no)
		(uuid "00000000-0000-0000-0000-0000628b71f6")
		(property "Reference" "R58"
			(at 200.66 274.32 90)
			(effects
				(font
					(size 1.27 1.27)
				)
				(justify left)
			)
		)
		(property "Value" "49.9R/1%/R0402"
			(at 200.66 276.86 90)
			(effects
				(font
					(size 0.9906 0.9906)
				)
				(justify left)
			)
		)
		(property "Footprint" "OLIMEX_RLC-FP:R_0402_5MIL_DWS"
			(at 204.978 275.59 0)
			(effects
				(font
					(size 0.762 0.762)
				)
				(hide yes)
			)
		)
		(property "Datasheet" ""
			(at 203.2 275.59 90)
			(effects
				(font
					(size 0.762 0.762)
				)
			)
		)
		(property "Description" ""
			(at 203.2 275.59 0)
			(effects
				(font
					(size 1.27 1.27)
				)
				(hide yes)
			)
		)
		(property "Fieldname 1" "Value 1"
			(at 203.2 275.59 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname2" "Value2"
			(at 203.2 275.59 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(property "Fieldname3" "Value3"
			(at 203.2 275.59 0)
			(effects
				(font
					(size 1.524 1.524)
				)
				(hide yes)
			)
		)
		(pin "1"
			(uuid "7ed79c43-1729-433f-957e-c03ebae3a58a")
		)
		(pin "2"
			(uuid "c2a319ed-12ce-4225-a434-e3c6e77a83eb")
		)
		(instances
			(project ""
				(path "/25974a83-530b-41f8-bec2-856ac522261d"
					(reference "R58")
					(unit 1)
				)
			)
		)
	)
	(sheet_instances
		(path "/"
			(page "1")
		)
	)
)
