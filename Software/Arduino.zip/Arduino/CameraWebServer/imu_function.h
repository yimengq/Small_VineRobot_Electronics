
#ifndef __IMU_FUNCTION_H__
#define __IMU_FUNCTION_H__

class imu_function{
    public:
    void init();

    void update();
};

#endif /* __IMU_FUNCTION_H__ */
















