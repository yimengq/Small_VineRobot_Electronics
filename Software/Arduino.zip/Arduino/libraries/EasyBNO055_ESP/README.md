# EasyBNO055_ESP
A library to make the BNO055 easy to use by adding an ESP32 thread to manage access. 
